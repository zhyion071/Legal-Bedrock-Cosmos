# Legal Bedrock Cosmos v1.3.12 (cape-catalogue update; device test pending)

Based on the user-confirmed working v1.3.5 native hook. v1.3.12 adds seven requested Bedrock Cosmos capes and thirteen Oxynix capes to the main Creator Capes catalogue and the corresponding creator pages. Existing GetPublishedItem fixtures are reused. The separate 100K Milestone Cape is not added. Previous user-requested removals remain absent, including One Vanilla from the Owned Capes row. Vanilla Capes count is 56 for 56 entries.

Ownership/entitlement metadata and the real Microsoft Marketplace inventory response are unchanged. No Android/media directory creation or persistent file logging is present.

## Build checks

- ARM64 Android build completed with NDK r29.
- JSON page payloads and generated embedded page arrays were checked.
- All 20 requested cape fixture IDs are present in the catalog and fixture map.
- Package archive integrity passed.

This cape-list change has not been verified on-device. Confirm the 20 requested capes are visible, previous removals remain absent, and live inventory/ownership is unchanged.


For v1.3.12, verify the Bedrock Cosmos (7) and Oxynix (13) groups appear as separate grid catalogues, with no duplicates remaining in the combined Creator Capes row.
