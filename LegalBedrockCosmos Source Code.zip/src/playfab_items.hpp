#pragma once
#include <string_view>
#include <unordered_map>

namespace cosmos {
static const std::unordered_map<std::string_view,std::string_view> kPlayfabItems = {
  {"1fe4a7b1-f44f-4a22-bcf8-c7f86e454a76", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1fe4a7b1-f44f-4a22-bcf8-c7f86e454a76",
      "Contents": [
        {
          "Id": "65979bfc-f208-4397-b4f6-3ee2bc0ea616",
          "Url": "https://capes.bedrock-cosmos.app/zips/1stBirthday_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d0567d45-f3e3-46b3-acde-7e692c4f35f7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"7660dda7-f417-4f66-96ec-d7a43e33b5e5", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "7660dda7-f417-4f66-96ec-d7a43e33b5e5",
      "Contents": [
        {
          "Id": "d62ec106-b68b-4b60-8a43-81b3685ea2c8",
          "Url": "https://capes.bedrock-cosmos.app/zips/4J_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "accf2343-5441-429d-9475-46ccedb01a77",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"7402ead0-ac59-4fd2-9f58-7e5b2d1ef412", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "7402ead0-ac59-4fd2-9f58-7e5b2d1ef412",
      "Contents": [
        {
          "Id": "b2dd5a81-daa7-4f2f-a38e-64d8e2c741c1",
          "Url": "https://capes.bedrock-cosmos.app/zips/Awesom_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "009fad7e-c10a-4ec9-a742-d6c15ca1daab",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"ae58c408-f09e-45c0-8dc5-e24ce9459997", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ae58c408-f09e-45c0-8dc5-e24ce9459997",
      "Contents": [
        {
          "Id": "9e54f93b-9365-45e8-b191-048b836a1b16",
          "Url": "https://capes.bedrock-cosmos.app/zips/Bacon_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "8d2486b9-486c-4c13-8b4c-011d7108ea1c",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"f2f9ca6c-13c5-4a96-b8b1-64bd5371b4b0", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f2f9ca6c-13c5-4a96-b8b1-64bd5371b4b0",
      "Contents": [
        {
          "Id": "5e2ad901-81ae-4150-a0cd-0fe637a41494",
          "Url": "https://capes.bedrock-cosmos.app/zips/Birthday_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "5e2ad901-81ae-4150-a0cd-0fe637a41494",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"314b1c57-c666-479b-b555-d1380b0b8654", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "314b1c57-c666-479b-b555-d1380b0b8654",
      "Contents": [
        {
          "Id": "ebe3641d-fb25-44af-aceb-2ce4e9583561",
          "Url": "https://capes.bedrock-cosmos.app/zips/Blonk_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "1f3a6312-435f-4c7e-9648-aeb6e55c2ed2",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"04e8aef9-4001-42a8-81e6-f851cc045b60", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "04e8aef9-4001-42a8-81e6-f851cc045b60",
      "Contents": [
        {
          "Id": "b6bc42c6-14bd-46eb-8809-a1a8f6ff88b9",
          "Url": "https://capes.bedrock-cosmos.app/zips/Blueprint_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b6bc42c6-14bd-46eb-8809-a1a8f6ff88b9",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"70783911-e090-4ada-a750-96405f0f7924", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "70783911-e090-4ada-a750-96405f0f7924",
      "Contents": [
        {
          "Id": "7f005c60-6223-497b-9805-5fbe5dca312a",
          "Url": "https://capes.bedrock-cosmos.app/zips/cheapsh0t_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a0dd8cfc-6db1-4dbe-9e90-cd6558b42922",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"40f25577-c1b8-4922-8678-6e916011c438", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "40f25577-c1b8-4922-8678-6e916011c438",
      "Contents": [
        {
          "Id": "930074fe-7dce-4c57-beed-83436b251468",
          "Url": "https://capes.bedrock-cosmos.app/zips/Christmas_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3e05bbb7-7ef3-4ec9-8a4b-705c7494d50c",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b3e48843-5db5-4a1d-8ba5-3603c2f3d402", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b3e48843-5db5-4a1d-8ba5-3603c2f3d402",
      "Contents": [
        {
          "Id": "d4bf12f4-8d04-4d89-b4c4-8b7840b12b12",
          "Url": "https://capes.bedrock-cosmos.app/zips/Cobalt_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "0fcbd4f0-ceb6-4c4c-8031-6a586fba3787",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"8f5c3ea3-0a85-4885-a27a-483f3bd8b535", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8f5c3ea3-0a85-4885-a27a-483f3bd8b535",
      "Contents": [
        {
          "Id": "fbf2d760-6733-46f1-95a5-d6a6a7d79e2d",
          "Url": "https://capes.bedrock-cosmos.app/zips/dannyBstyle_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d1421dbd-5716-4ec0-ab08-fa90fdc73647",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"279f387d-4054-4859-856f-533c4839d508", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "279f387d-4054-4859-856f-533c4839d508",
      "Contents": [
        {
          "Id": "2a37bafe-bdf1-4e10-ace3-dbf110ef708d",
          "Url": "https://capes.bedrock-cosmos.app/zips/FrogCape_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "1c03d90d-ef5f-4590-8e75-699676e772e3",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"44f33ecc-dee9-4120-837a-34aca6b993b2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "44f33ecc-dee9-4120-837a-34aca6b993b2",
      "Contents": [
        {
          "Id": "387442be-2859-4115-81aa-8b00d3d35191",
          "Url": "https://capes.bedrock-cosmos.app/zips/ICU_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "387442be-2859-4115-81aa-8b00d3d35191",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"535c755b-2346-4b47-9b5d-e8d33c1bce3a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "535c755b-2346-4b47-9b5d-e8d33c1bce3a",
      "Contents": [
        {
          "Id": "1ea3060e-e244-4b85-a86a-0330b1702847",
          "Url": "https://capes.bedrock-cosmos.app/zips/JulianClark_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "6aafb8af-32d1-4eb1-abb7-ee344bd536ff",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"5cd90c25-9006-418e-8552-2122869fe214", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "5cd90c25-9006-418e-8552-2122869fe214",
      "Contents": [
        {
          "Id": "050aa906-3a3e-4326-a5cc-d8002b3125f3",
          "Url": "https://capes.bedrock-cosmos.app/zips/MapMaker_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f51317cd-6917-4be8-9c31-79a56b5bb504",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"ecd5e398-4f4c-4df0-9167-63070821853c", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ecd5e398-4f4c-4df0-9167-63070821853c",
      "Contents": [
        {
          "Id": "be70d8f5-585b-41f4-b4bb-383b35364812",
          "Url": "https://capes.bedrock-cosmos.app/zips/MC_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "9d581238-9e6c-48ea-ac28-0ea317dd72d2",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"94e81811-ed4e-4d97-a2f0-a9e5d2f1b320", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "94e81811-ed4e-4d97-a2f0-a9e5d2f1b320",
      "Contents": [
        {
          "Id": "0bd847b5-2946-4048-8c53-593240b275c6",
          "Url": "https://capes.bedrock-cosmos.app/zips/Migrator_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b8e4dbd1-2875-407e-a397-4eb1977e8f4b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"91b8c70a-50cd-4b48-a0fa-ddbf160d2045", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "91b8c70a-50cd-4b48-a0fa-ddbf160d2045",
      "Contents": [
        {
          "Id": "2286fcf8-7add-4829-b2ce-c8e94ea2fe19",
          "Url": "https://capes.bedrock-cosmos.app/zips/MillionthSale_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "2286fcf8-7add-4829-b2ce-c8e94ea2fe19",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"e847fc66-b988-4065-bdc9-fa8fd17457b2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "e847fc66-b988-4065-bdc9-fa8fd17457b2",
      "Contents": [
        {
          "Id": "b4d53038-09d6-42b7-88a3-22b29b893b88",
          "Url": "https://capes.bedrock-cosmos.app/zips/Minecon2011_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b4d53038-09d6-42b7-88a3-22b29b893b88",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"6d520e39-e9d3-4d89-9b5c-01a2ebfd527b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "6d520e39-e9d3-4d89-9b5c-01a2ebfd527b",
      "Contents": [
        {
          "Id": "00ae51ce-d9cb-4d4a-bf9c-ab24b90eb93f",
          "Url": "https://capes.bedrock-cosmos.app/zips/Minecon2012_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "00ae51ce-d9cb-4d4a-bf9c-ab24b90eb93f",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"92fcae65-45fa-44e4-b39d-e586f0e9e710", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "92fcae65-45fa-44e4-b39d-e586f0e9e710",
      "Contents": [
        {
          "Id": "e701dbaa-fe9f-4d6a-920d-ee3f4b40102e",
          "Url": "https://capes.bedrock-cosmos.app/zips/Minecon2013_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e701dbaa-fe9f-4d6a-920d-ee3f4b40102e",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"aafefeee-7cca-4f19-9508-b949d1d26561", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "aafefeee-7cca-4f19-9508-b949d1d26561",
      "Contents": [
        {
          "Id": "61e8f038-e067-43d9-bd6e-0f8fa3bdf13b",
          "Url": "https://capes.bedrock-cosmos.app/zips/Minecon2015_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "61e8f038-e067-43d9-bd6e-0f8fa3bdf13b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"5a71fd20-dc29-448e-aa14-5bbca08f37bb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "5a71fd20-dc29-448e-aa14-5bbca08f37bb",
      "Contents": [
        {
          "Id": "bb3f8cd6-9a5b-47ad-b629-9352e140d3eb",
          "Url": "https://capes.bedrock-cosmos.app/zips/Minecon2016_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "bb3f8cd6-9a5b-47ad-b629-9352e140d3eb",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"0ed75751-d5a7-4331-b3ea-bb495566ce96", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "0ed75751-d5a7-4331-b3ea-bb495566ce96",
      "Contents": [
        {
          "Id": "f2abaf66-2212-4ed7-92f6-35d9e4d1abdc",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused1_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f2abaf66-2212-4ed7-92f6-35d9e4d1abdc",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"6c05c0a3-56f8-47bd-b2f3-2d7fe36771fd", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "6c05c0a3-56f8-47bd-b2f3-2d7fe36771fd",
      "Contents": [
        {
          "Id": "3a025630-9518-43e5-8891-6483baa4080f",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused2_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3a025630-9518-43e5-8891-6483baa4080f",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"ce769de4-4af0-40a0-90da-818053064716", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ce769de4-4af0-40a0-90da-818053064716",
      "Contents": [
        {
          "Id": "937108af-7807-46de-8179-f5806d85a912",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused3_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "937108af-7807-46de-8179-f5806d85a912",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"8c4f280e-aa41-41eb-b749-23c9729e2241", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8c4f280e-aa41-41eb-b749-23c9729e2241",
      "Contents": [
        {
          "Id": "17407bca-fca4-4331-a5c9-b08cc78bdf32",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused4_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "bae30e75-a7da-433f-a5cf-093da7296994",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"e185f8fc-6eff-4e8f-b6af-1b079d216bb4", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "e185f8fc-6eff-4e8f-b6af-1b079d216bb4",
      "Contents": [
        {
          "Id": "cee5a0f5-c95d-4259-b584-39faa5baf16b",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused5_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e2eda341-a651-479b-b132-c66c53bc55c1",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"febb7008-0617-46d6-9d35-21371902e442", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "febb7008-0617-46d6-9d35-21371902e442",
      "Contents": [
        {
          "Id": "0fa3d590-99bc-4a22-ae05-57d4870d0052",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused6_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e435afe2-f179-4eed-b9fa-40b5ee4fdb71",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"50846482-8988-422e-bdab-52f5757fe000", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "50846482-8988-422e-bdab-52f5757fe000",
      "Contents": [
        {
          "Id": "6b0f363c-b130-4acc-887c-21689087d5e6",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused7_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "1bc90141-5293-4c43-a1d6-0f8dcda6da3a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"66ffbd70-b6f9-4a80-91f2-a30abc93e3fb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "66ffbd70-b6f9-4a80-91f2-a30abc93e3fb",
      "Contents": [
        {
          "Id": "7ebf0ddc-585c-43a5-ab36-4424332a66c0",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused8_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "16d3f505-415e-4c81-ba7d-bc63b7412afa",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"f6b6563d-51ee-43d3-ac2e-28b54466568f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f6b6563d-51ee-43d3-ac2e-28b54466568f",
      "Contents": [
        {
          "Id": "967f476c-0f85-4b4a-b289-2808f89f5e8b",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused9_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "2679f81b-6981-4540-b941-7441b8b5ef45",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"1ff07805-5e3c-4f5d-b2b4-295a09b45dd9", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1ff07805-5e3c-4f5d-b2b4-295a09b45dd9",
      "Contents": [
        {
          "Id": "dc891bb7-6a80-4297-99ea-043f051d8a80",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused10_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b53df97a-ae89-4ca9-8728-5f8f1a5e49b1",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"0dfbb48b-ab90-45d5-8204-76190442ffd7", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "0dfbb48b-ab90-45d5-8204-76190442ffd7",
      "Contents": [
        {
          "Id": "70121141-337a-4a4f-aa87-3b6063301ad5",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused11_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e59ce1a4-b363-47f4-98b6-e7a900d0694e",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"189a439c-c652-4398-aab6-faf957f5c81f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "189a439c-c652-4398-aab6-faf957f5c81f",
      "Contents": [
        {
          "Id": "10e707d2-8d83-460d-9233-dbbc1d05f890",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused12_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e3567077-bb07-4483-8104-27b1f649294a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"da2c7113-a499-4356-9fc5-0c5c0a26ee09", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "da2c7113-a499-4356-9fc5-0c5c0a26ee09",
      "Contents": [
        {
          "Id": "fbad5a13-b220-4778-a3f0-2bb2ff1563af",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused13_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "c397d3a7-010c-4630-b55b-fc8d8bbcf40d",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"74f4afb2-5bc7-4eb0-ab49-8c04d9cbb16b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "74f4afb2-5bc7-4eb0-ab49-8c04d9cbb16b",
      "Contents": [
        {
          "Id": "602fe1ea-ec87-4fd0-812f-60cfb0c061dd",
          "Url": "https://capes.bedrock-cosmos.app/zips/MineconUnused14_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a50ee67a-d383-4c12-9fb9-dc68c05d5a54",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"3bea0bbb-d840-406c-9a58-5b3719c52c4d", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "3bea0bbb-d840-406c-9a58-5b3719c52c4d",
      "Contents": [
        {
          "Id": "2e28030a-e072-424f-a889-c62f129de6cf",
          "Url": "https://capes.bedrock-cosmos.app/zips/Moderator_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ae802169-98b0-41d0-a9d1-e82c28ad99e3",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"d1bad1ac-11b3-47d6-bc5c-353d088ccaf3", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "d1bad1ac-11b3-47d6-bc5c-353d088ccaf3",
      "Contents": [
        {
          "Id": "59eabc91-3998-46f2-8f6b-fd89ac6e4a1f",
          "Url": "https://capes.bedrock-cosmos.app/zips/Mojang_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3c24e2cb-e12f-4eca-aa03-998cf96404fb",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"218a8648-38ac-4cfb-a18c-438a75a46cef", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "218a8648-38ac-4cfb-a18c-438a75a46cef",
      "Contents": [
        {
          "Id": "5857463d-4945-44bc-ad4c-47d8f4f2cd49",
          "Url": "https://capes.bedrock-cosmos.app/zips/MojangOld_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a199b5f5-006e-47c6-a288-8f5b949938e4",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"9526bf0c-e80e-4ed1-bc63-65ee05a1c71d", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "9526bf0c-e80e-4ed1-bc63-65ee05a1c71d",
      "Contents": [
        {
          "Id": "926375d5-5e4e-4343-8b23-c5a28ba1db46",
          "Url": "https://capes.bedrock-cosmos.app/zips/MrMessiah_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "1777fbf9-1f88-4a59-a643-417a6230f310",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"a1503271-4400-4479-8fa4-a7cdd6ab94c2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a1503271-4400-4479-8fa4-a7cdd6ab94c2",
      "Contents": [
        {
          "Id": "9805de5c-09b5-4fb0-8d6c-23aaa7e1e9b4",
          "Url": "https://capes.bedrock-cosmos.app/zips/NewYears_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "66e6ad9c-d879-49b9-90ce-0e7f85576fed",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"c3bfe7f1-cf67-4a04-aba3-e2fa066cf406", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "c3bfe7f1-cf67-4a04-aba3-e2fa066cf406",
      "Contents": [
        {
          "Id": "5507706d-cbd9-4bc8-a25c-5e3ce1816489",
          "Url": "https://capes.bedrock-cosmos.app/zips/NoCircle_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "58f1dc89-a283-457f-9475-783063178957",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"c7204954-858b-47d8-a946-8d2dc6f391c8", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "c7204954-858b-47d8-a946-8d2dc6f391c8",
      "Contents": [
        {
          "Id": "52db91d1-2d40-4475-af83-0e304e46e2e5",
          "Url": "https://capes.bedrock-cosmos.app/zips/Nyan_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "1d5cef11-9565-4ef4-b77f-9c893801bd09",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b2cdb8a8-b746-4036-a56c-a6ab439a3514", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b2cdb8a8-b746-4036-a56c-a6ab439a3514",
      "Contents": [
        {
          "Id": "41eff50b-0401-42f4-a260-259fc244ed8e",
          "Url": "https://capes.bedrock-cosmos.app/zips/Oxeye_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "41eff50b-0401-42f4-a260-259fc244ed8e",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"212f1de0-8f17-4114-b865-bed262a947f4", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "212f1de0-8f17-4114-b865-bed262a947f4",
      "Contents": [
        {
          "Id": "4d19249b-81db-4a4d-959c-4cb9ae93ba6d",
          "Url": "https://capes.bedrock-cosmos.app/zips/Prismarine_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "59f7cdfa-d5fb-4919-a2eb-a70142216204",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"479fe5d3-8304-427a-8286-1440017a8a88", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "479fe5d3-8304-427a-8286-1440017a8a88",
      "Contents": [
        {
          "Id": "43a24ec8-8288-46ae-9a9f-b0170756c439",
          "Url": "https://capes.bedrock-cosmos.app/zips/ScrollsChamp_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "91424e59-ae9d-44f5-b950-ff429d3fa5fd",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"37215f88-88a7-4a39-8405-b9aa8add4437", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "37215f88-88a7-4a39-8405-b9aa8add4437",
      "Contents": [
        {
          "Id": "f718bb4e-1b8a-467f-a3dd-bd88c7df4a0e",
          "Url": "https://capes.bedrock-cosmos.app/zips/SizeM_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "785b04c6-e0e8-4a6c-ac97-59748840e3e7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"ecb8230e-9eb7-4122-a8d5-80864dc6aefd", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ecb8230e-9eb7-4122-a8d5-80864dc6aefd",
      "Contents": [
        {
          "Id": "0026b149-9916-451b-93ef-6957a41497e7",
          "Url": "https://capes.bedrock-cosmos.app/zips/SnailCape_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ae4fb219-4e9e-4797-ab2b-e246a8a9f69e",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"c1f94be2-365d-4481-936a-3bcbd4702a59", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "c1f94be2-365d-4481-936a-3bcbd4702a59",
      "Contents": [
        {
          "Id": "d3c7fe8b-ebdf-43f1-9c3b-c1c51e296ca1",
          "Url": "https://capes.bedrock-cosmos.app/zips/Squid_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "258cf666-8a30-459d-ad4a-11ebf46117de",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"e758a2c9-d8e0-49f8-a6d7-d10667daf2d5", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "e758a2c9-d8e0-49f8-a6d7-d10667daf2d5",
      "Contents": [
        {
          "Id": "105b6cae-6326-478b-9569-f0a0b89d102d",
          "Url": "https://capes.bedrock-cosmos.app/zips/Translator_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "7cf99cd2-db39-4b79-bb39-22dc6c474c28",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"a4b46b66-3789-4d6e-a7a1-7cc6ee199f03", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a4b46b66-3789-4d6e-a7a1-7cc6ee199f03",
      "Contents": [
        {
          "Id": "31a8a60c-d284-48a4-935e-b90165d81f3b",
          "Url": "https://capes.bedrock-cosmos.app/zips/TranslatorChinese_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "472e2a1a-c2e4-41e3-a3a9-e7c3c0361ff1",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"03ed5f77-cf53-4ad5-882a-f3e616d5f9e0", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "03ed5f77-cf53-4ad5-882a-f3e616d5f9e0",
      "Contents": [
        {
          "Id": "2b7ab0aa-8488-4f77-a9a6-06cb63e15a72",
          "Url": "https://capes.bedrock-cosmos.app/zips/Turtle_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e2bb8d18-c9d5-4e44-8a99-f6a44706b964",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"791e2aaf-62a5-4647-8ff7-478fab1177f7", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "791e2aaf-62a5-4647-8ff7-478fab1177f7",
      "Contents": [
        {
          "Id": "17d53330-32bb-456d-9f14-66b4c724e613",
          "Url": "https://capes.bedrock-cosmos.app/zips/Valentine_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "1ff89a25-6c68-406f-b5d6-77a4e8ef5bbc",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"ef0ebb20-72bc-449c-9c2f-022f7aa33459", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ef0ebb20-72bc-449c-9c2f-022f7aa33459",
      "Contents": [
        {
          "Id": "890d1eb0-9a45-4a92-afc8-2dcafb2b8701",
          "Url": "https://capes.bedrock-cosmos.app/zips/Veterinarian_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "25779297-2f5f-4928-af26-6d49fca0d6bc",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"c6ffe67c-10c8-41f8-b3b8-d599214d1130", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "c6ffe67c-10c8-41f8-b3b8-d599214d1130",
      "Contents": [
        {
          "Id": "f48d1042-b300-43e8-862a-fdb9e5b5b340",
          "Url": "https://capes.bedrock-cosmos.app/zips/Xbox_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "fc181119-3c7f-4e1a-ad48-7990f8fce7ac",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"e6ac6826-b590-4aaf-b87a-c4499d4283a1", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "e6ac6826-b590-4aaf-b87a-c4499d4283a1",
      "Contents": [
        {
          "Id": "2fff024f-bd7b-41b8-a1ac-9e6194341c8c",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/AmethystCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "14b678be-c843-40e8-b748-accfce84c2f4",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"a115555a-315d-4a0f-8437-78df54a3f653", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a115555a-315d-4a0f-8437-78df54a3f653",
      "Contents": [
        {
          "Id": "10cb1e55-961d-4f42-933d-d808ebbd3562",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/BirthdayDungeonsCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f7966e59-9cd9-4ca8-8dae-13766c9611c7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"cac8a80c-dfd5-4056-9af0-3bb549a9e8d3", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "cac8a80c-dfd5-4056-9af0-3bb549a9e8d3",
      "Contents": [
        {
          "Id": "71e24d98-b9e8-4539-bf9a-1646dc58f88d",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/CloudyClimbCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "371b2b70-b2f9-4b2b-b4f6-7dfda684df4f",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"d4e66f66-c47e-4020-8fdf-897432617d02", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "d4e66f66-c47e-4020-8fdf-897432617d02",
      "Contents": [
        {
          "Id": "8002f7a6-9f47-4962-a5ce-5c4de8c3b2dd",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/CloudyClimbTrailerCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "27f0c858-e165-4bc9-8598-142b26fe2010",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"703106e8-a075-4b96-9ab6-f93a42c5b54c", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "703106e8-a075-4b96-9ab6-f93a42c5b54c",
      "Contents": [
        {
          "Id": "3b546968-34a0-462d-bd52-c61cf0b8ea26",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeonsII/CorruptedCreeperCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons II",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "977936d8-5377-4e58-ac61-1f959f4d1c8a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"cae14f00-efc1-4be9-afcf-513a125a8e91", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "cae14f00-efc1-4be9-afcf-513a125a8e91",
      "Contents": [
        {
          "Id": "5b4fc9a5-635b-4213-8c41-90a3969be9cd",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/CowCrusaderCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "58dcdf0f-0699-4c49-a012-61291da0756a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"1f0b25db-b7bc-4080-b345-394a3f18c977", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1f0b25db-b7bc-4080-b345-394a3f18c977",
      "Contents": [
        {
          "Id": "5ad982b5-aec8-4de1-80d5-ed3d8289a2e4",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/DownpourCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d6e8ac80-5610-4886-86c7-8fec3e3619f4",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"615a566e-d44b-4de4-9d91-46fc20072141", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "615a566e-d44b-4de4-9d91-46fc20072141",
      "Contents": [
        {
          "Id": "44ca82b4-2ab1-4cba-86ae-8051aea9479b",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/FaunaFaireCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "636f57e0-9894-4fde-a52a-720cbfe65b2d",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"a82f16ff-2520-4024-b318-13aca62e6710", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a82f16ff-2520-4024-b318-13aca62e6710",
      "Contents": [
        {
          "Id": "566576f4-0d30-4a10-9c90-eeff342a124c",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/GiftWrapCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "39aabd06-c2e5-4c0f-8a4b-465f7f552df7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"6335945a-ce24-41e1-9401-66c2e4d25557", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "6335945a-ce24-41e1-9401-66c2e4d25557",
      "Contents": [
        {
          "Id": "ee9b58da-488a-445e-b794-6a694a7d48e8",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/GlowCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f7fc26e4-6b41-4f37-abea-d7a1656dc098",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"1da006d2-a91d-4677-9492-6ef57c6b7b35", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1da006d2-a91d-4677-9492-6ef57c6b7b35",
      "Contents": [
        {
          "Id": "ebe1657b-a527-47a4-9479-ddd752448e2d",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/GourdianCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3791acc0-ca2d-4565-b2ec-609844bb5e49",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"ee861fd0-95dd-4954-af6e-1962582facfb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ee861fd0-95dd-4954-af6e-1962582facfb",
      "Contents": [
        {
          "Id": "564ab4c0-a3eb-4b3f-9a3f-bbceedb98fe4",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/HammerCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "7e32bd07-c2a6-4355-a76d-9223e3fbf086",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"2de148de-3196-4dac-8e2a-a28e589da380", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "2de148de-3196-4dac-8e2a-a28e589da380",
      "Contents": [
        {
          "Id": "13c05457-b8a4-4758-bf1d-f02da9d3b113",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/HeroCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "efb8e959-a115-44a4-9cc5-eaa999e10e81",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"1a20c9bd-838b-4dad-b1b0-4e93a66b5fad", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1a20c9bd-838b-4dad-b1b0-4e93a66b5fad",
      "Contents": [
        {
          "Id": "1aac1ef7-efc7-4c23-9019-15e49ebe8cfb",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/IceologerCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ded51bbe-889a-4d63-9cb6-fe3745d226f0",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"372ef312-7f50-4e2b-a985-62cb832e4c55", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "372ef312-7f50-4e2b-a985-62cb832e4c55",
      "Contents": [
        {
          "Id": "8226d601-d994-4e3f-8090-a9a475a0273b",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/IronGolemCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "466837c1-a75b-40ea-97b1-7a9e7da15a9b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"4cd3e857-ccdc-4d38-86cc-a7df3863973a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4cd3e857-ccdc-4d38-86cc-a7df3863973a",
      "Contents": [
        {
          "Id": "75efa34e-8a36-4564-8b92-6c8a0eaf4ae1",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/LuminousNightCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d498e79e-91d2-4f4f-a51a-9bd8767e0caa",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"1bcf2c21-652e-4ae4-9af2-630968571130", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1bcf2c21-652e-4ae4-9af2-630968571130",
      "Contents": [
        {
          "Id": "6dd80702-e71a-4add-8d7e-845b78d1b11e",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/MysteryCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ba897dba-f47a-4940-9592-09a1414119fa",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"a04cbd2c-fc46-452a-ad9a-b6aaa24b6a87", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a04cbd2c-fc46-452a-ad9a-b6aaa24b6a87",
      "Contents": [
        {
          "Id": "7a039fed-307f-4c4b-bf67-a3a9efc34cc6",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/OminousCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "5f4cbce0-55c6-42c0-bd05-3c5f7fb1713b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"e0a2af8c-ee2f-4103-90d6-545c23c843eb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "e0a2af8c-ee2f-4103-90d6-545c23c843eb",
      "Contents": [
        {
          "Id": "dd5e67f9-83a7-471e-b78a-fc2cdbce691e",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/PhantomCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "7a37e8ac-0c7f-40b2-86c7-2c2fb3be303a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"a7eda0a7-5896-4e05-a01d-e03449567ecb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a7eda0a7-5896-4e05-a01d-e03449567ecb",
      "Contents": [
        {
          "Id": "ca36ba7c-c760-419c-992d-f47935f7d508",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/PrismCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a5f4cadf-7fa9-4483-862e-681255749ebe",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"6a07d42d-3e17-45b4-b712-0d6165e7c2d5", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "6a07d42d-3e17-45b4-b712-0d6165e7c2d5",
      "Contents": [
        {
          "Id": "088bc53f-0347-440a-8c16-3bcae96a562c",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/RedRoyalCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "64c2843c-8350-4586-b178-309b7f7fe9a1",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"47fb8bcd-9db1-4262-b1ad-c1c6bafdeaac", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "47fb8bcd-9db1-4262-b1ad-c1c6bafdeaac",
      "Contents": [
        {
          "Id": "4bf29b4b-1618-48b6-82ee-5535488adbda",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/SinisterCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "6acb12ab-16e7-4133-ac15-ea90b29d1a03",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"a22db560-6235-4171-a286-5f86f5077bff", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a22db560-6235-4171-a286-5f86f5077bff",
      "Contents": [
        {
          "Id": "ca8a8f01-e5b7-43ac-a171-083e73d39f81",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeonsII/SoulCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons II",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "15324383-6ccb-4fcd-a2f2-ba3bbfdd18b3",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"1a3f66b4-a66b-4a44-bb79-d795ca40bbf7", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1a3f66b4-a66b-4a44-bb79-d795ca40bbf7",
      "Contents": [
        {
          "Id": "1cd9bbb7-c2f7-4aae-81c8-ef83c3d3298a",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeons/TurtleShellCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "aa48eb4b-390b-4ebe-8185-8bff1bd89e6a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"435b2432-cea9-40cc-a488-995d78cded05", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "435b2432-cea9-40cc-a488-995d78cded05",
      "Contents": [
        {
          "Id": "2fdf71e9-f026-413e-8495-5246c83a9bcc",
          "Url": "https://capes.bedrock-cosmos.app/zips/MinecraftDungeonsII/TwistedCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft Dungeons II",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ed8b1cca-94b8-4019-9225-33de7f3d2b5a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"5bba5540-377b-4ec2-9633-4551c4e82e37", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "5bba5540-377b-4ec2-9633-4551c4e82e37",
      "Contents": [
        {
          "Id": "1bb54a51-7a3d-4793-85a2-c227aaf6c5d9",
          "Url": "https://capes.bedrock-cosmos.app/zips/AndroidCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "4a48472c-2256-41db-9b96-790276e84fc1",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"9fa8cacf-5aef-4415-b655-ab82df15656d", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "9fa8cacf-5aef-4415-b655-ab82df15656d",
      "Contents": [
        {
          "Id": "ce2a84e9-d5ee-4987-a65b-53a50c1e1f25",
          "Url": "https://capes.bedrock-cosmos.app/zips/BedNewCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Liefubledo",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "1d61e212-7588-4f81-aaf6-b06c0a3ece05",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"80a1968a-853e-4ca8-9c70-6de7ddb732b1", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "80a1968a-853e-4ca8-9c70-6de7ddb732b1",
      "Contents": [
        {
          "Id": "7e939005-fc6e-4235-a0ae-58225995a6b4",
          "Url": "https://capes.bedrock-cosmos.app/zips/BlockOfDiamond_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Liefubledo",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "40e2265d-8423-441a-8030-860216b297fd",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"505ae060-ec73-4d88-84b1-74de9b7c898f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "505ae060-ec73-4d88-84b1-74de9b7c898f",
      "Contents": [
        {
          "Id": "4a916323-02f3-4fbf-97f0-c604d78d7955",
          "Url": "https://capes.bedrock-cosmos.app/zips/BlockOfEmeraldCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Liefubledo",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "69ecf7fa-c883-4fe1-aa17-e165239e786b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"43ad7ce2-3c38-4174-9104-b7c95e242c5a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "43ad7ce2-3c38-4174-9104-b7c95e242c5a",
      "Contents": [
        {
          "Id": "4463281c-bc2d-46bf-ad8f-973db40cf2a1",
          "Url": "https://capes.bedrock-cosmos.app/zips/BlockOfGold_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Liefubledo",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "877388be-fb85-4ef3-bbc2-0298e39939d8",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"1b19a308-86cc-4fb0-9f62-683a30906dd5", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1b19a308-86cc-4fb0-9f62-683a30906dd5",
      "Contents": [
        {
          "Id": "23350adb-cc90-435a-8ebe-3db1c6885448",
          "Url": "https://capes.bedrock-cosmos.app/zips/BlockOfNetherite_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Spyynz",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e315fde7-af01-43c2-9a23-5881aa1b9f0b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"aae7860e-fc65-4dee-a261-5b31018a1aff", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "aae7860e-fc65-4dee-a261-5b31018a1aff",
      "Contents": [
        {
          "Id": "1a8515ce-30b3-4263-8cea-1a9b4f5576cf",
          "Url": "https://capes.bedrock-cosmos.app/zips/Breeze_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Actions & Stuff",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d36ece97-827f-4f80-bdf9-7fe665c08892",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"3a8a8a10-da0e-4622-962c-955c8e02385f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "3a8a8a10-da0e-4622-962c-955c8e02385f",
      "Contents": [
        {
          "Id": "8f19476c-a7ed-4dd0-82ec-1f15c5f57211",
          "Url": "https://capes.bedrock-cosmos.app/zips/BreezePurple_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Actions & Stuff",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "1439f8b0-14b5-4dbe-8f6b-45d0f8168f2c",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"7932e680-a9f0-45fa-b422-88ed7f1b2335", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "7932e680-a9f0-45fa-b422-88ed7f1b2335",
      "Contents": [
        {
          "Id": "6b4773c1-154c-4b83-922b-ca210f8a90ac",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreeperKing_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "!NerfModder",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "37530fbf-8188-4e3d-a8f2-14efec74dd33",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"45b6c356-0535-461d-a6cb-607af970ecb7", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "45b6c356-0535-461d-a6cb-607af970ecb7",
      "Contents": [
        {
          "Id": "4929272c-8144-4eda-baf0-9b84a24d554f",
          "Url": "https://capes.bedrock-cosmos.app/zips/CryingObsidian_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Mantle",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "6777cb90-f24a-4402-ae29-fb4c3b91e643",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"f60ca856-ba14-4602-a4a3-3e177d67210e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f60ca856-ba14-4602-a4a3-3e177d67210e",
      "Contents": [
        {
          "Id": "9ced392b-6d1a-4a1f-8ae9-8f4901e78cca",
          "Url": "https://capes.bedrock-cosmos.app/zips/CubeCraft_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "7a262e5f-8609-4873-8c64-bb00eee191a4",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"4a23b41a-508b-49b8-b9d3-8b165337332e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4a23b41a-508b-49b8-b9d3-8b165337332e",
      "Contents": [
        {
          "Id": "bc8acc1f-1e09-4e0e-899d-64ff523cc9b3",
          "Url": "https://capes.bedrock-cosmos.app/zips/Diamond_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "JakeMCPE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "8ae6aa2a-6592-474e-a721-4c265b2dc96d",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"680c6afa-ce03-4055-aa4b-e7085f02da9f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "680c6afa-ce03-4055-aa4b-e7085f02da9f",
      "Contents": [
        {
          "Id": "91085abb-7f0b-4e8e-93e1-6f5bf4d93815",
          "Url": "https://capes.bedrock-cosmos.app/zips/Dragon_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Unknown",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b06e43e3-6612-422f-b528-ea9fea18088e",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"8228887d-30bb-44b8-978a-22fc464ff037", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8228887d-30bb-44b8-978a-22fc464ff037",
      "Contents": [
        {
          "Id": "9c98382b-adc9-466b-957a-b61e7f4e4dd0",
          "Url": "https://capes.bedrock-cosmos.app/zips/EnchantingTable_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Allkatrez",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "7e6bd216-9ae2-4af3-8a7f-60c0844d443d",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"9f3a002b-b223-4647-9aa7-846ce7f5ffa4", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "9f3a002b-b223-4647-9aa7-846ce7f5ffa4",
      "Contents": [
        {
          "Id": "5741bbf6-da29-48e7-82fb-f712be515ed7",
          "Url": "https://capes.bedrock-cosmos.app/zips/EmeraldCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "JakeMCPE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "46d73d7b-08ac-4ad1-9df7-c1961b782366",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"8d8508a7-4a2e-44d8-8e5d-76b61639955d", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8d8508a7-4a2e-44d8-8e5d-76b61639955d",
      "Contents": [
        {
          "Id": "bcca61d4-295a-41e4-a327-3837862bfc39",
          "Url": "https://capes.bedrock-cosmos.app/zips/EnderPearl_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "JakeMCPE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "9fad0855-75c5-4a04-9aad-b5ef5a41e0b3",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"796e63d1-a146-4c63-b736-b9f0ce553ff2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "796e63d1-a146-4c63-b736-b9f0ce553ff2",
      "Contents": [
        {
          "Id": "3887d330-dd74-4b43-8e8d-3b823fe55e0a",
          "Url": "https://capes.bedrock-cosmos.app/zips/EyeOfEnder1_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "sebastian",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "934878f3-23b3-40bc-ba07-fef5bd59f17c",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"a36ea909-8876-46a8-bddb-c4116e63c9e6", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a36ea909-8876-46a8-bddb-c4116e63c9e6",
      "Contents": [
        {
          "Id": "c3cfc1f0-e835-47a9-9e64-2838a423cbe7",
          "Url": "https://capes.bedrock-cosmos.app/zips/FireCape1.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Spyynz",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e884dba6-c396-4149-9856-734dcf0e14c6",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"9d17ba55-cc4a-4e7e-aa41-83fa39e36ac9", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "9d17ba55-cc4a-4e7e-aa41-83fa39e36ac9",
      "Contents": [
        {
          "Id": "991fb21f-a0d7-471d-a557-ba5c90185e32",
          "Url": "https://capes.bedrock-cosmos.app/zips/GameBoy2_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Temple of Thoom",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "dc72fa4d-22f5-458f-bb50-cc74f1011e37",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"cccba53e-503a-4e11-8847-7a6676059bff", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "cccba53e-503a-4e11-8847-7a6676059bff",
      "Contents": [
        {
          "Id": "4f667fd0-3c6f-4b6e-bffa-9adb641935e4",
          "Url": "https://capes.bedrock-cosmos.app/zips/GildedBlackstone2_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Spyynz",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "8583cbe0-58ee-4217-bf61-55808e32d6c4",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"6c1ac305-7430-4313-8b90-7d6e0eb1af8e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "6c1ac305-7430-4313-8b90-7d6e0eb1af8e",
      "Contents": [
        {
          "Id": "2e94725f-cb16-4cd1-ae03-dacff5f726c0",
          "Url": "https://capes.bedrock-cosmos.app/zips/GlassNew_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Liefubledo",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "21f0f2d2-e21f-4ead-8faf-7c2dc49b6a2f",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"3aff5d54-a885-405c-9670-e794473ac3a7", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "3aff5d54-a885-405c-9670-e794473ac3a7",
      "Contents": [
        {
          "Id": "f72fb99f-04ff-455b-aaa6-6899bd63316a",
          "Url": "https://capes.bedrock-cosmos.app/zips/GoldenApple1_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "JakeMCPE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "9ead71b3-cec8-48e6-bd23-8bd92a5adb93",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"f4073563-8096-49a3-b590-9d1bc77a20c7", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f4073563-8096-49a3-b590-9d1bc77a20c7",
      "Contents": [
        {
          "Id": "12285057-6eca-4949-bc82-2876da0d41f4",
          "Url": "https://capes.bedrock-cosmos.app/zips/GuardianCape2.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Unknown",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "08d3b4bb-88ce-44c2-a52d-668baa386ba8",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"ae573c14-0b8b-4bac-bd27-8bf84116f4f2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ae573c14-0b8b-4bac-bd27-8bf84116f4f2",
      "Contents": [
        {
          "Id": "4be8bd60-81a6-4ca5-b275-dd77520b2137",
          "Url": "https://capes.bedrock-cosmos.app/zips/Hardcore_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Dubby Plays",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "1dcc2b9d-d41a-4b3c-a06c-e0931f7b179b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b88305b5-a7b6-48a0-bbf3-1d146a585265", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b88305b5-a7b6-48a0-bbf3-1d146a585265",
      "Contents": [
        {
          "Id": "8cc2759b-8c45-43b9-bb87-c073975e9744",
          "Url": "https://capes.bedrock-cosmos.app/zips/Hypixel_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "fc3fc3b8-1fe2-46f0-ac32-a337dbe21974",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"86c248d2-0615-40ff-afc1-e8d6a04435ed", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "86c248d2-0615-40ff-afc1-e8d6a04435ed",
      "Contents": [
        {
          "Id": "ef59b858-4c13-46ac-acee-8f87aa0ce49b",
          "Url": "https://capes.bedrock-cosmos.app/zips/MCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "SwagerOnline",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d4e2d718-227b-44a8-9bb5-30231b9e5d77",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"8b7e5613-3394-43a5-8655-022bf2be0d6f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8b7e5613-3394-43a5-8655-022bf2be0d6f",
      "Contents": [
        {
          "Id": "5dbc6aff-80d9-4994-a5b1-89b1150d37f4",
          "Url": "https://capes.bedrock-cosmos.app/zips/MelonCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "JakeMCPE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "40f03708-d95b-43a9-a9ba-885505c25cdb",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"4ca17959-173d-4ae0-ae15-d114ac23bb02", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4ca17959-173d-4ae0-ae15-d114ac23bb02",
      "Contents": [
        {
          "Id": "d2f28881-7480-49b4-9c54-e7f6064838cb",
          "Url": "https://capes.bedrock-cosmos.app/zips/Microsoft_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Dexeo",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "8980f130-5315-473b-b87d-0e12f0268a98",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"0e1d924c-9eb6-42d5-baeb-706335c268e2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "0e1d924c-9eb6-42d5-baeb-706335c268e2",
      "Contents": [
        {
          "Id": "a75e2b57-9794-4f63-8d88-f2ddf86b11f1",
          "Url": "https://capes.bedrock-cosmos.app/zips/NetherStar_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "TLauncher",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "908d4652-a2fe-4240-8191-8ea5867cfbd3",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"86dcf5d2-6a31-4a78-a0fb-53d5f798f641", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "86dcf5d2-6a31-4a78-a0fb-53d5f798f641",
      "Contents": [
        {
          "Id": "db98b4af-ceba-42b2-a39d-a15f10d3cb14",
          "Url": "https://capes.bedrock-cosmos.app/zips/OakDoorCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Liefubledo",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "96de2ab0-1ed2-47d0-9dab-6be1bd01d93d",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"01f86701-e166-4cff-97a5-e40dd192f3ec", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "01f86701-e166-4cff-97a5-e40dd192f3ec",
      "Contents": [
        {
          "Id": "fdb6b755-fa13-47e4-afff-5c400551390b",
          "Url": "https://capes.bedrock-cosmos.app/zips/OptiFine_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "OptiFine",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "76648755-f48e-4777-9ac8-c3f1c929c8aa",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"fb2245c6-dc9c-4be2-99f7-b1ad94fb41f3", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "fb2245c6-dc9c-4be2-99f7-b1ad94fb41f3",
      "Contents": [
        {
          "Id": "ab44620f-148d-4a95-8a21-c59df4574725",
          "Url": "https://capes.bedrock-cosmos.app/zips/OptiFine10thAnniversary_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "OptiFine",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b586a749-ee8c-4ffc-8b65-cc747c72b7be",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b01a36e6-6426-4585-8eba-6024bea40820", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b01a36e6-6426-4585-8eba-6024bea40820",
      "Contents": [
        {
          "Id": "980a56a8-3269-4cbe-9b36-8267decb795a",
          "Url": "https://capes.bedrock-cosmos.app/zips/Omniarchive_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Crackers0106",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ee0a67c7-27f7-4ec7-b3e1-dbf58b04a296",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"8d59e86b-138c-4308-8ccc-7f1f26695b03", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8d59e86b-138c-4308-8ccc-7f1f26695b03",
      "Contents": [
        {
          "Id": "1dec37a8-eb6d-4d9b-bd6c-1a7402603804",
          "Url": "https://capes.bedrock-cosmos.app/zips/Paper_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "RanchyCeaser",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "7f5f6dd2-6d4a-4c49-bfb0-7be0abc48c7b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"7ef3e8b3-50a6-4f94-9de3-9c50a011a7be", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "7ef3e8b3-50a6-4f94-9de3-9c50a011a7be",
      "Contents": [
        {
          "Id": "33c4fed9-8132-436f-b68d-646f0536800e",
          "Url": "https://capes.bedrock-cosmos.app/zips/PhantomWings_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "RanchyCeaser",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a4dc1ed3-029d-47c8-9f66-729a865b8805",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"27076531-21e4-4f5a-9e2e-0c6047edb317", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "27076531-21e4-4f5a-9e2e-0c6047edb317",
      "Contents": [
        {
          "Id": "f50f9949-decc-4f8e-a16d-758ab74d9345",
          "Url": "https://capes.bedrock-cosmos.app/zips/PokeBallCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Avalanche_Ali",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "fb2f936c-c0c5-44c9-867b-a5b7d9d2f33d",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"c313e412-c582-4e9a-bd9d-aee981565a72", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "c313e412-c582-4e9a-bd9d-aee981565a72",
      "Contents": [
        {
          "Id": "1972e784-2314-4530-8a43-7783d0f955cd",
          "Url": "https://capes.bedrock-cosmos.app/zips/PotatoCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "JakeMCPE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "12d6d5b9-b982-4a03-8275-d08fbd393f8f",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"449308f3-1f33-4b92-ae94-f7fb198e2c01", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "449308f3-1f33-4b92-ae94-f7fb198e2c01",
      "Contents": [
        {
          "Id": "96160092-e354-439d-88d3-690f518ddf3f",
          "Url": "https://capes.bedrock-cosmos.app/zips/Pumpkin_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "smartvong",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "6d5d875e-36ed-41f9-ad3d-a89a765b0e2d",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"f8a54840-f633-4597-abdd-41f6c9a86f37", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f8a54840-f633-4597-abdd-41f6c9a86f37",
      "Contents": [
        {
          "Id": "9a3db2ac-45b5-4d6e-b9f6-a66ce6b68547",
          "Url": "https://capes.bedrock-cosmos.app/zips/SlimeCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "MinecraftCapes",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "47545ffd-4714-4750-83ae-f03963f828ca",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"007b46cc-421c-4ee3-8c7a-a2b63b8582e8", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "007b46cc-421c-4ee3-8c7a-a2b63b8582e8",
      "Contents": [
        {
          "Id": "e2908675-e487-4585-8191-cb0fc493e34c",
          "Url": "https://capes.bedrock-cosmos.app/zips/SoulFireCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Spyynz",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "1c16efba-4fce-4ecb-8091-d2ce9589782f",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"dabf1c6d-e561-4dc4-bafd-636e8a6c4e95", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "dabf1c6d-e561-4dc4-bafd-636e8a6c4e95",
      "Contents": [
        {
          "Id": "2abda6fc-f21b-46d4-8e25-c43951d94256",
          "Url": "https://capes.bedrock-cosmos.app/zips/SpaceInvadersCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Avalanche_Ali",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "10a3fc26-1f70-4c45-8297-363647d9e5fa",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"64f80879-ff7c-4490-81f8-f081d2dc1bb5", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "64f80879-ff7c-4490-81f8-f081d2dc1bb5",
      "Contents": [
        {
          "Id": "60fe1fc0-5c5a-45c3-b50b-2f17722752ed",
          "Url": "https://capes.bedrock-cosmos.app/zips/SquidCape2.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "MinecraftCapes",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "fc0c86da-e012-4b75-b37f-0bd0ff6ed997",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"4ca9116f-0e34-4ec3-ae1b-203cc31a6540", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4ca9116f-0e34-4ec3-ae1b-203cc31a6540",
      "Contents": [
        {
          "Id": "2e2a8de5-ee9c-4e6c-a291-58bc99a26a97",
          "Url": "https://capes.bedrock-cosmos.app/zips/Switch_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "-DaniL",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f7d18eef-db47-46a2-af06-bc561c0c68b2",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"4b63517d-d430-4162-8eb4-74886973a92e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4b63517d-d430-4162-8eb4-74886973a92e",
      "Contents": [
        {
          "Id": "8c2e546f-d348-482e-9881-ce9737927592",
          "Url": "https://capes.bedrock-cosmos.app/zips/Sword_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "JakeMCPE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "c17dc244-d394-4972-b1de-521d68d78a69",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b224c73e-80cd-4874-a4a2-b31e6e1b1f55", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b224c73e-80cd-4874-a4a2-b31e6e1b1f55",
      "Contents": [
        {
          "Id": "cf82e2e8-e67a-4cfc-a7e3-d73713d74267",
          "Url": "https://capes.bedrock-cosmos.app/zips/TheHive_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "floormint",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "8f75269e-87b6-4d57-b196-673195e1e141",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"503017f7-c1e4-4e34-81d6-fc980f28f416", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "503017f7-c1e4-4e34-81d6-fc980f28f416",
      "Contents": [
        {
          "Id": "c634d0e8-5de3-42b3-80fe-f24ecf76e34f",
          "Url": "https://capes.bedrock-cosmos.app/zips/TotemOfUndying_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "MinecraftCapes",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ccf37ab6-da70-418e-b7b0-27a1f735dc1c",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"380043d3-41a4-4f07-b682-03449244d0e8", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "380043d3-41a4-4f07-b682-03449244d0e8",
      "Contents": [
        {
          "Id": "060888d3-e1ce-48e6-b8f8-d4bf2c6036f5",
          "Url": "https://capes.bedrock-cosmos.app/zips/YouTube1_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "ItsOasis",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "2449991a-b9aa-411e-84aa-a4280e8803d8",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"94b3e845-5721-4969-b66a-b8f7128bfbb0", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "94b3e845-5721-4969-b66a-b8f7128bfbb0",
      "Contents": [
        {
          "Id": "6fbd64c8-4796-4b68-ab8b-16d088e1c86f",
          "Url": "https://capes.bedrock-cosmos.app/zips/BionicBen_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e9ffe72b-2d98-4e55-ad77-c0d06ba42ec7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"fa44ffcf-6c60-45f4-b959-296faa9895d4", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "fa44ffcf-6c60-45f4-b959-296faa9895d4",
      "Contents": [
        {
          "Id": "9855fec9-6dab-45fc-a49a-6eb749442b9a",
          "Url": "https://capes.bedrock-cosmos.app/zips/BadPing_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "61a1506e-1b1a-4973-9585-8f07b60f22c9",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"29b830ac-19c0-463f-a9e1-4811c290d19e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "29b830ac-19c0-463f-a9e1-4811c290d19e",
      "Contents": [
        {
          "Id": "7459732c-c44d-46c9-aca6-34e3652205fb",
          "Url": "https://capes.bedrock-cosmos.app/zips/BionicBenClassic_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "0026d531-de7d-4e1c-943c-31cb42673ba1",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"cae8049a-57f5-48c9-bfed-7ad77ea8d727", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "cae8049a-57f5-48c9-bfed-7ad77ea8d727",
      "Contents": [
        {
          "Id": "8e9a2a84-5931-4c4a-8e83-0da3c1ea2902",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/BionicBen/BirdCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "9c481374-38f3-4ba6-bd72-ed8cae95a672",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"6acb51d1-dfe1-435e-803f-425f959b9382", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "6acb51d1-dfe1-435e-803f-425f959b9382",
      "Contents": [
        {
          "Id": "ee80ee8c-1be3-4d24-acfe-7fd7a192ea89",
          "Url": "https://capes.bedrock-cosmos.app/zips/Bread_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d7e1503a-f518-4fdb-8a46-636213d8e131",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"9616be9d-eca6-4d5d-aae7-fce58530a9f5", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "9616be9d-eca6-4d5d-aae7-fce58530a9f5",
      "Contents": [
        {
          "Id": "faa83b76-ef7e-48d6-a0a6-720848e4a114",
          "Url": "https://capes.bedrock-cosmos.app/zips/GoodPing_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "1ee7c325-5383-49e7-9846-df6561b9362a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"77fc588f-be6f-4def-8ab6-26ac46901897", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "77fc588f-be6f-4def-8ab6-26ac46901897",
      "Contents": [
        {
          "Id": "3aefd6a3-34ab-4d3a-9685-e665a23da1c1",
          "Url": "https://capes.bedrock-cosmos.app/zips/MediumPing_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a03288f1-26d7-4f21-9ca5-5529b3a86935",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"288d1363-a07b-4c29-916f-d2aa07748730", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "288d1363-a07b-4c29-916f-d2aa07748730",
      "Contents": [
        {
          "Id": "336be672-8a4a-46b4-92e5-c1377ecc474f",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/BionicBen/NeonCreeperCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "dc9495d9-d3d2-40be-93dd-ced205632a9b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"1472a239-f11c-4462-a302-59bc9df01a8b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1472a239-f11c-4462-a302-59bc9df01a8b",
      "Contents": [
        {
          "Id": "23a60f01-4372-49fa-abd7-46000f51dbc8",
          "Url": "https://capes.bedrock-cosmos.app/zips/Scythe_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "9ef4cea7-c477-48e2-85d8-c5834d5f2696",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"420d9136-8916-4253-bcd1-ad6a45c983cc", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "420d9136-8916-4253-bcd1-ad6a45c983cc",
      "Contents": [
        {
          "Id": "3533b56d-9643-42b5-85b4-5e985d329d35",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/BionicBen/SunsetCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "106b446b-faf1-40fd-a9ec-e9b5cd5ca19d",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"e09f5be3-e610-4f4f-9477-2e68a5034e38", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "e09f5be3-e610-4f4f-9477-2e68a5034e38",
      "Contents": [
        {
          "Id": "88781c93-380b-4af7-9a6b-981c217e3c8f",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/DL0ZE/DL0ZECape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "DL0ZE - CLICK HERE FOR MORE CAPES",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "80a97f0f-206e-4004-8fbc-7350d20b1176",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"212ebbf7-ee8f-4de0-bf67-4290c5cf6bd9", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "212ebbf7-ee8f-4de0-bf67-4290c5cf6bd9",
      "Contents": [
        {
          "Id": "6837dfec-f647-4d08-a7d5-0f5598f098ba",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/DL0ZE/BurgerCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "DL0ZE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "afec16c5-7731-45de-9845-ccfd488682e7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"1bd4e3ce-fb7b-4842-b1a7-e20468061967", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1bd4e3ce-fb7b-4842-b1a7-e20468061967",
      "Contents": [
        {
          "Id": "20d8cb3d-3d74-4c1c-afca-80a947f1c5b6",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/DL0ZE/CakeCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "DL0ZE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "c8db717a-26dc-4578-8f20-607f03b7b9bd",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"ecb7f519-cd5c-4ec3-8ceb-4c01873c68b1", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ecb7f519-cd5c-4ec3-8ceb-4c01873c68b1",
      "Contents": [
        {
          "Id": "90512558-ac39-4e30-bb44-3f37a28ce49e",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/DL0ZE/CraftingTableCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "DL0ZE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d2dde4e1-777a-49e3-b613-58f609e990a7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"88231694-f32b-462a-b288-2d88b439593f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "88231694-f32b-462a-b288-2d88b439593f",
      "Contents": [
        {
          "Id": "c952b763-f1e3-48d7-bf2c-2def875a8af3",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/DL0ZE/CrescentCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "DL0ZE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "dab51931-2cd9-4e72-8f16-01e89848b0bf",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"0d204940-7e98-4907-863c-1980f776659d", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "0d204940-7e98-4907-863c-1980f776659d",
      "Contents": [
        {
          "Id": "0f0f6711-dd50-421c-a93d-4c1ea8181067",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/DL0ZE/ElfCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "DL0ZE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "be1c7a6e-4827-4d8b-bdf3-3396b9af89c8",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"ea1fc944-c910-4eee-a745-f3e147ce5fac", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ea1fc944-c910-4eee-a745-f3e147ce5fac",
      "Contents": [
        {
          "Id": "1b2e4977-585e-469e-afe7-329207053292",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/DL0ZE/MoonlightCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "DL0ZE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "97111fa7-2e5e-48e7-8681-ccbe25dd6220",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"2e428c54-eccd-4d71-a71a-3362533decfd", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "2e428c54-eccd-4d71-a71a-3362533decfd",
      "Contents": [
        {
          "Id": "2d0e8037-6b3c-4428-a09d-2077f87c5e12",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/DL0ZE/PiratePillagerCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "DL0ZE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d550b6d6-f3c2-4fb0-977a-067f01ce9a9d",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"974c4527-a242-4349-a237-24d1be65ef6a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "974c4527-a242-4349-a237-24d1be65ef6a",
      "Contents": [
        {
          "Id": "840e5eca-46dc-482b-b536-f84949ddfcff",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/DL0ZE/SantaCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "DL0ZE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ae53a7bc-4cf8-4700-bbc5-73570ad1ef0d",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"a307660a-f491-4e95-8866-ac87dec0ee2e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a307660a-f491-4e95-8866-ac87dec0ee2e",
      "Contents": [
        {
          "Id": "877b93f9-7f85-48f9-9ffc-c62aae87927b",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/DL0ZE/WitchCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "DL0ZE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e229aa3e-8c26-4937-91d8-4c5639b4a29c",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"f3d65adc-08d9-4cc3-91a0-f933293b0549", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f3d65adc-08d9-4cc3-91a0-f933293b0549",
      "Contents": [
        {
          "Id": "c1890d46-4265-4d48-b03c-047492af3e3a",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/DL0ZE/WitherCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "DL0ZE",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d7ee267e-9023-4de5-915b-e602c5afe8cd",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"720e267e-ef85-4a29-a1b9-066a0c00901e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "720e267e-ef85-4a29-a1b9-066a0c00901e",
      "Contents": [
        {
          "Id": "c6bced46-53fa-427f-a680-0839332c7621",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/NAC/NACCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "NAC",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e2b788be-8ce7-49ec-ab23-45d2478fb220",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"cb4d8a68-f97d-40b5-b11e-59294826a0cc", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "cb4d8a68-f97d-40b5-b11e-59294826a0cc",
      "Contents": [
        {
          "Id": "cf0d2cc4-d06d-4fa4-ab64-b6e8d3240aaf",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/NAC/MCCAquaAxolotlsCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "NAC",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "186473ca-ae1f-4361-9e69-50644eaa0a68",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"f838ccc1-a8d2-4bf5-b820-2cbee6d6c7a6", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f838ccc1-a8d2-4bf5-b820-2cbee6d6c7a6",
      "Contents": [
        {
          "Id": "e0bd9934-4065-4bd6-b73b-ecfff38eb2a7",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/NAC/MCCBlueBatsCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "NAC",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "80cb534a-a1b2-4eee-b975-477bc7541365",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"acf80f4c-f232-4608-aecf-7e9807bb9d4e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "acf80f4c-f232-4608-aecf-7e9807bb9d4e",
      "Contents": [
        {
          "Id": "88bf6b8b-cc49-4198-b0ab-e3a4c9fbbf4d",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/NAC/MCCCyanCoyotesCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "NAC",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "12664480-30d5-48e1-bc53-433c2914f245",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"299d4eb2-645a-4929-af4c-9cc80b9d0745", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "299d4eb2-645a-4929-af4c-9cc80b9d0745",
      "Contents": [
        {
          "Id": "f01ac21e-5d13-414e-815c-d7eb97e453f3",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/NAC/MCCGreenGeckosCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "NAC",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b4c3511f-9fd2-447e-a5a0-cd0fa73bce6e",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"3b553920-305e-4b7b-8496-feacb2a0440b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "3b553920-305e-4b7b-8496-feacb2a0440b",
      "Contents": [
        {
          "Id": "4e565748-a687-4ca7-80e3-e7e5d79aeb19",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/NAC/MCCLimeLlamasCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "NAC",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "7b08aafe-a133-4867-a189-87724996465b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"cc2cd21c-407f-4bc5-858e-adcc7f4bb6db", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "cc2cd21c-407f-4bc5-858e-adcc7f4bb6db",
      "Contents": [
        {
          "Id": "3e7ddbf4-c99c-48c9-9a55-8665a9bcd2ef",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/NAC/MCCOrangeOcelotsCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "NAC",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "22e33fb2-0620-4872-b3b0-ad7a956a1f33",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"bf37ce64-ce9a-441a-a8f6-2be5fa08c282", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "bf37ce64-ce9a-441a-a8f6-2be5fa08c282",
      "Contents": [
        {
          "Id": "656946d2-95c4-46a1-820a-603ee6511345",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/NAC/MCCPinkParrotsCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "NAC",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "8d89444c-fa62-4a2c-8206-42aaaa980ae1",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"0bedf938-e537-453c-93d9-bfd63fa1fbe6", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "0bedf938-e537-453c-93d9-bfd63fa1fbe6",
      "Contents": [
        {
          "Id": "3591cea2-4223-4a3c-9d4f-554f5abea79b",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/NAC/MCCPurplePandasCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "NAC",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "494fb1fb-4979-475a-b92c-610419da7b48",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"02885b68-3289-4e06-afe5-205a88d372e2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "02885b68-3289-4e06-afe5-205a88d372e2",
      "Contents": [
        {
          "Id": "40195d49-b48d-4eee-ba15-47ab19afed52",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/NAC/MCCRedRabbitsCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "NAC",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "37f68b29-8bee-4535-a88b-f7879d504616",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"5299cc99-f1e9-4e28-b4e4-ac47a82d4c8f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "5299cc99-f1e9-4e28-b4e4-ac47a82d4c8f",
      "Contents": [
        {
          "Id": "a67f7a02-8265-4646-83ca-7497da7488ad",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/NAC/MCCYellowYaksCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "NAC",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e3be4ec3-849c-47d5-8071-72dde16fda09",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"88b7ad01-d26b-4b03-aee4-d0f15db6181b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "88b7ad01-d26b-4b03-aee4-d0f15db6181b",
      "Contents": [
        {
          "Id": "a534212c-8c98-424a-89a6-d50d19e78ebc",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/SabilityCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "59517c87-a04c-4076-9940-ef6d1cc8d535",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"9ebb516e-b275-4652-a1e1-c66452d45227", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "9ebb516e-b275-4652-a1e1-c66452d45227",
      "Contents": [
        {
          "Id": "5d27b29e-2b8e-450e-9046-b0191bb9067b",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/BedrockViewerCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "73627146-6aeb-41f2-8503-5fd4d2b829b7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"f95a3c09-b964-49f4-8bff-68f4c419d4c9", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f95a3c09-b964-49f4-8bff-68f4c419d4c9",
      "Contents": [
        {
          "Id": "2ff8f563-dc5a-4417-99a7-039ad6641cac",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/BlackHoleCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "20a40965-3705-4899-88a5-1d0244c8343b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"b0458d60-382e-4b45-b9df-5098f1fc4dfa", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b0458d60-382e-4b45-b9df-5098f1fc4dfa",
      "Contents": [
        {
          "Id": "790b7e38-207c-4c2f-8530-e2fa1655950f",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/CamoCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "dde0e0cc-428a-4d82-974c-30cebdb81eb2",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"be7d1076-4fd0-48eb-b7a3-309738e9ca51", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "be7d1076-4fd0-48eb-b7a3-309738e9ca51",
      "Contents": [
        {
          "Id": "31597f1e-a6b1-4ebf-ab3a-a07a070e145d",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/ChalkboardCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d62224bf-74c7-46d8-8a86-b3075ccbd4e7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"b00db69c-c9e4-434b-a1ce-b634f337b044", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b00db69c-c9e4-434b-a1ce-b634f337b044",
      "Contents": [
        {
          "Id": "90caf16d-8974-4557-adca-e2fd44fcd218",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/CodCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "6eef95ea-d4f4-43c4-b40b-5eb545e5bdd9",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"30f99b01-fecf-44dd-be61-54d2bd6c3ce2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "30f99b01-fecf-44dd-be61-54d2bd6c3ce2",
      "Contents": [
        {
          "Id": "f05e408c-2fa4-403f-af67-d40fba1852a7",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/ElementalEarthCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "6db1d7bf-5073-49fd-9a9f-eaa2ee009eea",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"ffe6af1f-7f35-4f38-b100-05355411a68a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ffe6af1f-7f35-4f38-b100-05355411a68a",
      "Contents": [
        {
          "Id": "6e1ffbd6-cf6a-4064-a421-d2318a69ec15",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/ElementalFireCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f1efa233-baa1-4e27-8365-fd7ba7d43124",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"53168159-664d-4233-97f0-719e4d1295bb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "53168159-664d-4233-97f0-719e4d1295bb",
      "Contents": [
        {
          "Id": "8cc45ad5-719f-4fdb-9f2f-103eae4ad1a5",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/ElementalWaterCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "626943b6-b736-4543-a773-d096e8d6caa7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"68f1ff9b-d021-4f31-ae50-d040eaf7fe44", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "68f1ff9b-d021-4f31-ae50-d040eaf7fe44",
      "Contents": [
        {
          "Id": "966c2266-42e2-4818-a77e-f3d75c1ef250",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/ElementalWindCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ff2f9f62-6ee7-47dd-ad76-12fefff1e2fc",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"efbbb230-9cdd-49ac-9103-1c305eecefac", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "efbbb230-9cdd-49ac-9103-1c305eecefac",
      "Contents": [
        {
          "Id": "5d56d1dc-8291-4a76-9f4e-b3f2919b8729",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/GoldenCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "bafc5009-f02b-4d6f-aa59-33b492ed7fb0",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"d9ddbf1f-6dca-4327-a3cf-b2f243335959", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "d9ddbf1f-6dca-4327-a3cf-b2f243335959",
      "Contents": [
        {
          "Id": "7349c9dc-4506-4a0f-967f-924edf5212c5",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/SabilityCakeCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "2fe3bde9-b445-44f0-8ce8-3780ce484cd6",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"4cf60f66-8ee3-4a6f-b42b-b01db055ba61", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4cf60f66-8ee3-4a6f-b42b-b01db055ba61",
      "Contents": [
        {
          "Id": "36ecdf61-7b78-42c0-9298-3eed119e6be3",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/SabilityCookieCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e82ac627-414a-46b8-a2bf-42784091e77d",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"b31df7dd-631c-47d6-9ddc-03f2a03c44ec", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b31df7dd-631c-47d6-9ddc-03f2a03c44ec",
      "Contents": [
        {
          "Id": "e6d16f6a-2532-4958-82cf-eabb4b43cef3",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/SabilityDiscordCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d4092352-74a7-4c45-95c8-c79cbbbcdaee",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"d726d93c-3d26-40d6-872d-c125281c6c73", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "d726d93c-3d26-40d6-872d-c125281c6c73",
      "Contents": [
        {
          "Id": "76c7020b-eaba-4e02-b0c6-52661d831b3e",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/SabilityGhastCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "10a5bcc1-288a-4274-bfe5-d7448506d25f",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"209d39aa-c197-4e6a-9452-17e2960e5d76", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "209d39aa-c197-4e6a-9452-17e2960e5d76",
      "Contents": [
        {
          "Id": "ceeb8d92-f1e7-4d92-bcf2-6d81e39f0d7f",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/SabilityMCPEDLCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "63540c72-844b-471d-8035-2b3c8f8c8888",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"d25169b8-cf46-4e58-a3a1-918a90c165c8", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "d25169b8-cf46-4e58-a3a1-918a90c165c8",
      "Contents": [
        {
          "Id": "9aaf7694-e7e7-4e21-8198-a928306455d0",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/SulfurCubeCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3b5b107f-8301-4afb-8a24-aec1ba0f4d79",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"f1c2e968-6a50-494a-a969-875d0150b87a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f1c2e968-6a50-494a-a969-875d0150b87a",
      "Contents": [
        {
          "Id": "8e2562a1-0eb5-4e0e-916d-0109196aef73",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Sability/USBChargerBlockCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Sability",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "43cf2a24-b5bc-4f87-a7ec-0e62c5557a64",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"b178226d-1fe8-45bd-b2a2-b527be0f90cf", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b178226d-1fe8-45bd-b2a2-b527be0f90cf",
      "Contents": [
        {
          "Id": "0e578f65-dacc-4333-a427-c8933040abdc",
          "Url": "https://capes.bedrock-cosmos.app/zips/Stars_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Stars",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "463651ee-d90c-44e2-934e-d9382f905d20",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b8657da9-d315-462f-9c0f-0dbb00fc208f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b8657da9-d315-462f-9c0f-0dbb00fc208f",
      "Contents": [
        {
          "Id": "54705284-0103-4bb7-9668-3109dca25d01",
          "Url": "https://capes.bedrock-cosmos.app/zips/Blossom_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Stars",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "6b0caa79-8a04-4f85-ad11-14e67d5a1916",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"33ea3751-eaac-4139-95d2-f9d4978cb039", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "33ea3751-eaac-4139-95d2-f9d4978cb039",
      "Contents": [
        {
          "Id": "05c74b3f-3d3f-468a-a42b-caabdcefb6b2",
          "Url": "https://capes.bedrock-cosmos.app/zips/Snowy_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Stars",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "004c3be3-57e7-40a5-8876-94d7935f10c0",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"cdc530a3-b427-4368-9cb9-5fa816a64b89", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "cdc530a3-b427-4368-9cb9-5fa816a64b89",
      "Contents": [
        {
          "Id": "7e23a1ef-8d30-4c39-8be9-6d32f1861eaf",
          "Url": "https://capes.bedrock-cosmos.app/zips/Sunflower_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Stars",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f0a0ccbb-2c4b-427e-9ea9-088ffad055ec",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"f49fca50-7aec-4e7d-8d41-627ba15b1c16", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f49fca50-7aec-4e7d-8d41-627ba15b1c16",
      "Contents": [
        {
          "Id": "6cca59de-75f7-4c58-b6e4-8a6e75940b78",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/WizardryCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ec335cc2-01dc-407e-8cc4-fec7851c749a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"ed93dc89-0ca0-429b-a011-a30fc7502c2d", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ed93dc89-0ca0-429b-a011-a30fc7502c2d",
      "Contents": [
        {
          "Id": "9add48ec-0de7-4935-beef-93cd05557c58",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/AutumnMapleCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "800756a3-83e2-4b74-afc4-39dbe228d2e6",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"a29ed67d-33ff-4126-8eef-815aa12c5bec", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a29ed67d-33ff-4126-8eef-815aa12c5bec",
      "Contents": [
        {
          "Id": "7161f1a3-6bda-40bd-b102-fef987f40eb0",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/BeachSunsetCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "df12a0fe-07d1-48fa-b926-04d65b2485be",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"bc2c4de7-4703-4d38-8996-a81060d638a9", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "bc2c4de7-4703-4d38-8996-a81060d638a9",
      "Contents": [
        {
          "Id": "d6a9687d-3594-4deb-9ca0-7180b231e28c",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/CoralReefCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3a48a29d-3a25-41ce-afb3-db15405fa5fd",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"380a8a73-0f14-4747-b7b3-07febc968706", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "380a8a73-0f14-4747-b7b3-07febc968706",
      "Contents": [
        {
          "Id": "ce4f58c8-4feb-455d-8db6-a178568c5f56",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/DesertDuskCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "68070d6a-ca07-46fb-980c-ea45b4554064",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"992ee3eb-d073-4953-9e1e-879aec1b6154", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "992ee3eb-d073-4953-9e1e-879aec1b6154",
      "Contents": [
        {
          "Id": "05cbed32-6e4b-4153-bf18-e7159db223f8",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/EmberVolcanoCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "6f8480d4-eb87-40b4-9409-f3108bb9dbe0",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"957395fa-f898-4c31-a3b3-8717eef69586", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "957395fa-f898-4c31-a3b3-8717eef69586",
      "Contents": [
        {
          "Id": "6c79e3fb-4cac-41d0-ba52-4157613b830c",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/GlowShroomCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "faa59b7c-9a1e-4a5d-9dac-8b916238d459",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"59bf18b7-17c1-4b6d-94fd-8bec303a06fc", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "59bf18b7-17c1-4b6d-94fd-8bec303a06fc",
      "Contents": [
        {
          "Id": "c6e5246b-cac3-49b5-9350-7eeed68b41ed",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/JellyfishCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "7f8232a8-9454-401a-8304-49140cfecb7e",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"b78b4eff-698a-4e45-b8a9-218b0b38e23c", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b78b4eff-698a-4e45-b8a9-218b0b38e23c",
      "Contents": [
        {
          "Id": "550dd1fc-3f2c-43b9-8762-ca8f46494dba",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/LighthouseCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b84320c8-bf56-4344-bf67-d69b43a600e8",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"4a9dd3db-cb76-4907-b31e-ebd3b7acb603", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4a9dd3db-cb76-4907-b31e-ebd3b7acb603",
      "Contents": [
        {
          "Id": "cb5427bd-5948-4008-b5fc-03b242820851",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/MilkyWayCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "03c78494-64ca-4504-8982-1dc3edae70bf",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"829d2a65-bbb4-49c3-9d94-e9a13082c529", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "829d2a65-bbb4-49c3-9d94-e9a13082c529",
      "Contents": [
        {
          "Id": "59ad71dc-851d-487d-810d-7802cdd4e674",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/NorthernLightsCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "8468e19e-e434-4ffb-8941-21355f34bcf7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"6f17bb3a-f634-4e88-9213-acb4bd6e4bca", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "6f17bb3a-f634-4e88-9213-acb4bd6e4bca",
      "Contents": [
        {
          "Id": "3f6efba0-3d69-46b6-a406-0499e141082a",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/OceanWaveCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "8d839277-0a5c-4690-af12-b24fa3c2f288",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"4aa119f4-b89b-4df7-be02-500b1f71e115", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4aa119f4-b89b-4df7-be02-500b1f71e115",
      "Contents": [
        {
          "Id": "97062662-f052-4b90-94a4-d337885f5e05",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/SnowyPeakCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d6cdeac4-628c-4ce4-8d90-b501d237c168",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"6f42d39e-c982-4e4f-b1aa-5a7062dda07f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "6f42d39e-c982-4e4f-b1aa-5a7062dda07f",
      "Contents": [
        {
          "Id": "bf7170e7-2037-4630-84e6-00e8850489d1",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/ToriiGateCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3fb96d37-4413-48fb-a9a3-84c7170378fa",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"8003b504-d210-45cc-9123-c7492936f035", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8003b504-d210-45cc-9123-c7492936f035",
      "Contents": [
        {
          "Id": "86c657ab-2719-42ef-8ff9-9f71cb4a20ff",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/WisteriaCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "91beef3c-3a3d-4f4a-a5bc-d334d7cd1515",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"ffaa6c40-77d1-4321-b678-a9d925ff719b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ffaa6c40-77d1-4321-b678-a9d925ff719b",
      "Contents": [
        {
          "Id": "ae0e72d1-6bea-448d-81bc-43fa0c3dbbad",
          "Url": "https://capes.bedrock-cosmos.app/zips/CreatorCapes/Wizardry/WizardryBedrockCosmosCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Wizardry",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "772b7f3e-b368-4dff-b5e0-97964e7c436c",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"09f9b23e-8d9c-4ff5-8c11-9c5d3f405df0", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "09f9b23e-8d9c-4ff5-8c11-9c5d3f405df0",
      "Contents": [
        {
          "Id": "4994ab93-69e1-41c5-9b28-83b100ca33b1",
          "Url": "https://capes.bedrock-cosmos.app/zips/EnderDragon_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "1st Birthday Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "57de006e-457a-47e9-a837-186a57d3ee4b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b4a07965-1cb3-48b3-930a-2f03579fef4a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b4a07965-1cb3-48b3-930a-2f03579fef4a",
      "Contents": [
        {
          "Id": "a43dde43-706c-44fa-9d24-025ab466ed78",
          "Url": "https://capes.bedrock-cosmos.app/zips/Jens_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "3rd Birthday Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "848eb65a-4026-4ef4-9b38-cc856eba82ce",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"e02b1b6b-4474-4ce5-966b-a90569adb87b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "e02b1b6b-4474-4ce5-966b-a90569adb87b",
      "Contents": [
        {
          "Id": "d5d3c630-a929-4fc8-815c-9786d3b70b84",
          "Url": "https://capes.bedrock-cosmos.app/zips/HuntressWizard_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Adventure Time Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "50e2fd64-7867-418c-8777-3187e703b215",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b98cf866-ef6b-457a-a5f2-9c5fc2ae68f6", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b98cf866-ef6b-457a-a5f2-9c5fc2ae68f6",
      "Contents": [
        {
          "Id": "54bdab7b-b6e5-4f1c-bf7d-b3aa6046823a",
          "Url": "https://capes.bedrock-cosmos.app/zips/TheLich_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Adventure Time Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "50993c77-1d88-410b-85e9-89689fc16250",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"d848cddd-bd33-4eb2-8efb-bff3246fe0eb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "d848cddd-bd33-4eb2-8efb-bff3246fe0eb",
      "Contents": [
        {
          "Id": "51c488de-57d8-4cdb-a3c4-776bff9c0f72",
          "Url": "https://capes.bedrock-cosmos.app/zips/SpartanMan_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Battle & Beasts Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ab405175-ad31-4795-ad56-14110d0e343e",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"4af67132-64f7-486e-827f-a9afe35a3996", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4af67132-64f7-486e-827f-a9afe35a3996",
      "Contents": [
        {
          "Id": "3c6451cb-3f7d-4367-85c7-c73da2a48fbc",
          "Url": "https://capes.bedrock-cosmos.app/zips/SpartanWoman_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Battle & Beasts Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b5f0e60c-46ec-4b01-b4eb-38a7b0c47e70",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"d30cca64-fa61-4a36-9b00-c5f30690ffec", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "d30cca64-fa61-4a36-9b00-c5f30690ffec",
      "Contents": [
        {
          "Id": "1e84f9c0-e3ca-4314-b03a-235dbe194690",
          "Url": "https://capes.bedrock-cosmos.app/zips/ArabianMan_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Battle & Beasts 2 Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "dd273c2b-ced5-487e-be8e-db1bcfe249b8",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"8a7bb9e3-eb68-4566-99ef-f5aba1ebcc99", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8a7bb9e3-eb68-4566-99ef-f5aba1ebcc99",
      "Contents": [
        {
          "Id": "1faf51ca-d240-4541-b9ec-f365e90ad472",
          "Url": "https://capes.bedrock-cosmos.app/zips/MaoriMan_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Battle & Beasts 2 Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ce81428d-5b67-414c-b949-7f91a710533b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"9d84a147-ed96-4cbc-b0cc-ee769c57748c", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "9d84a147-ed96-4cbc-b0cc-ee769c57748c",
      "Contents": [
        {
          "Id": "7bba621f-8523-4367-bdd5-49bf8618c1be",
          "Url": "https://capes.bedrock-cosmos.app/zips/IceLord_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Doctor Who Skins Volume I",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "58ed252f-1454-4efb-b1c6-c89e8df75bf8",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"1327c3a1-2457-4583-b9c9-f2f296542710", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1327c3a1-2457-4583-b9c9-f2f296542710",
      "Contents": [
        {
          "Id": "2d8a17e9-5e8f-4650-bb2b-2b3dfb53221e",
          "Url": "https://capes.bedrock-cosmos.app/zips/Liz10_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Doctor Who Skins Volume I",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f197f30e-dcff-4892-90cc-f16f6f47bb67",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"c11a4d20-9f52-4e59-9df1-7e233914d882", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "c11a4d20-9f52-4e59-9df1-7e233914d882",
      "Contents": [
        {
          "Id": "816f3239-e8b2-4df4-bc5e-f205a9a2405d",
          "Url": "https://capes.bedrock-cosmos.app/zips/Sycorax_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Doctor Who Skins Volume II",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3e3e39ca-cf69-4438-9e39-485547bb77b5",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"aeecb6a5-37a2-4ffd-a654-507faacac4db", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "aeecb6a5-37a2-4ffd-a654-507faacac4db",
      "Contents": [
        {
          "Id": "9852a421-ffe2-4d53-ba09-4a3986edea60",
          "Url": "https://capes.bedrock-cosmos.app/zips/TheThirdDoctor_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Doctor Who Skins Volume II",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3cc3f562-5a2d-4347-aa46-9aa92cea9c11",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"5545dbaa-d97f-44a6-8299-53159197b4c3", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "5545dbaa-d97f-44a6-8299-53159197b4c3",
      "Contents": [
        {
          "Id": "66c43d5a-4671-4e60-b74f-68dfdf3cb3fa",
          "Url": "https://capes.bedrock-cosmos.app/zips/Apollo_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "1d726764-8e43-490c-bc7d-1f1f5e3a1458",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b5fd0669-e5da-4f7b-8344-4d2f09ed08fc", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b5fd0669-e5da-4f7b-8344-4d2f09ed08fc",
      "Contents": [
        {
          "Id": "8b4a814e-848b-4d5c-be1a-9f62575676b2",
          "Url": "https://capes.bedrock-cosmos.app/zips/Artemis_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "866ce4a3-5611-418e-9de5-2b18fb1dcd66",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"fc4da888-ca7d-468d-8ba8-7224b7bb40dc", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "fc4da888-ca7d-468d-8ba8-7224b7bb40dc",
      "Contents": [
        {
          "Id": "79e5d11a-e930-4c3a-b13f-e5ce316cba43",
          "Url": "https://capes.bedrock-cosmos.app/zips/Atlanta_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "fe8c7839-0dfd-4d09-8a28-8601a7676c0c",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"16a1b29c-736e-4f06-b343-adcfa5e1905f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "16a1b29c-736e-4f06-b343-adcfa5e1905f",
      "Contents": [
        {
          "Id": "52fc1a5b-8997-4aeb-9639-4b32935157e2",
          "Url": "https://capes.bedrock-cosmos.app/zips/Athena_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "372b47ed-45aa-429f-a588-7a4031fe624f",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"9ba0258f-defe-46e4-90d9-5bc71f851d0f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "9ba0258f-defe-46e4-90d9-5bc71f851d0f",
      "Contents": [
        {
          "Id": "6afe1553-fd7c-411e-b23c-38186529afc2",
          "Url": "https://capes.bedrock-cosmos.app/zips/Cadmus_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3d71a070-c7ff-477e-8574-9a631058d10c",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"0ed6237e-b4ee-4812-8aa8-1dda9243cca9", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "0ed6237e-b4ee-4812-8aa8-1dda9243cca9",
      "Contents": [
        {
          "Id": "8d421f1f-3ebb-49b9-bae0-21776935315f",
          "Url": "https://capes.bedrock-cosmos.app/zips/Dryad_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f1853a5e-6e00-4c9e-b536-82cb3d8842cf",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"eb84b79b-5eb2-495f-9c29-a2a41c782280", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "eb84b79b-5eb2-495f-9c29-a2a41c782280",
      "Contents": [
        {
          "Id": "576c3b06-175d-4593-9d87-99de75470ad3",
          "Url": "https://capes.bedrock-cosmos.app/zips/Erinyes_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "94cf58e5-f55d-40d2-ad61-259ae563a47c",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b178525f-a466-43d4-b241-a8611bc7e66e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b178525f-a466-43d4-b241-a8611bc7e66e",
      "Contents": [
        {
          "Id": "0bb5ad0e-df04-4c43-a61a-c6a92676bb9a",
          "Url": "https://capes.bedrock-cosmos.app/zips/Hades_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "fcd1c934-0da4-4343-9c74-ac2382644627",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"a0ca27b0-3e20-4740-b42b-79354f0b4158", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a0ca27b0-3e20-4740-b42b-79354f0b4158",
      "Contents": [
        {
          "Id": "badc7939-ee1f-4dfd-9ef5-3ab55929f7b5",
          "Url": "https://capes.bedrock-cosmos.app/zips/Hephaestus_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "75acd8f7-91a2-408c-a1a5-e8cb7ef974c7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"a6657526-6dba-494d-b308-5e5cca8ad414", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a6657526-6dba-494d-b308-5e5cca8ad414",
      "Contents": [
        {
          "Id": "b7389461-c374-44ed-95d6-b6d62e8af27a",
          "Url": "https://capes.bedrock-cosmos.app/zips/Heracles_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "92338e84-29bd-4ee9-9df3-3229d5ffeaf3",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"cd3790a2-2497-41d3-93f2-15cedb4fc4f0", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "cd3790a2-2497-41d3-93f2-15cedb4fc4f0",
      "Contents": [
        {
          "Id": "e371fd66-6dff-49de-b909-5a541ecbbb33",
          "Url": "https://capes.bedrock-cosmos.app/zips/Perseus_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "9d3434fb-96f7-4dfb-8fe2-c3c6c82a8354",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"69022d1e-3714-4801-b601-96c688f8c465", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "69022d1e-3714-4801-b601-96c688f8c465",
      "Contents": [
        {
          "Id": "4954b842-21a4-41f0-b3a7-dd1f2444e5c2",
          "Url": "https://capes.bedrock-cosmos.app/zips/Poseidon_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b7281317-cf7f-4a4d-ae0a-5c7b627d2a06",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"4bc567ba-76ec-4879-9c0c-981b63e035a6", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4bc567ba-76ec-4879-9c0c-981b63e035a6",
      "Contents": [
        {
          "Id": "97330cbf-daf3-44dc-8f20-fd14fbce2cef",
          "Url": "https://capes.bedrock-cosmos.app/zips/Prometheus_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "5003f98b-8753-445b-831d-d3c7fc92616a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"e50c0b8f-c9a7-409e-8308-050e01ecf6a3", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "e50c0b8f-c9a7-409e-8308-050e01ecf6a3",
      "Contents": [
        {
          "Id": "cfd9e8d0-cb3a-4b4b-92d7-34098286b3ee",
          "Url": "https://capes.bedrock-cosmos.app/zips/Spartoi_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "c2d6541f-0eaa-4359-bf9b-23c13adf7c41",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"af5dff18-9079-4112-aa0f-c4a8d7eee407", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "af5dff18-9079-4112-aa0f-c4a8d7eee407",
      "Contents": [
        {
          "Id": "74d84016-004d-4678-b259-eab27f9b98bd",
          "Url": "https://capes.bedrock-cosmos.app/zips/Zeus_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "0ebd4234-facc-448c-9eb2-5c3cf75fa5e2",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"a3532b58-84d4-46f6-bbdc-d69b33f33215", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a3532b58-84d4-46f6-bbdc-d69b33f33215",
      "Contents": [
        {
          "Id": "a4366b9d-648e-4c9b-88d1-7351d5b319b7",
          "Url": "https://capes.bedrock-cosmos.app/zips/Argonaut2_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "875b6ea3-d220-45d6-b4a3-ed8a4606697e",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"1b87ade8-89c1-4a31-b8c5-ffefec108ef1", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1b87ade8-89c1-4a31-b8c5-ffefec108ef1",
      "Contents": [
        {
          "Id": "ce5ebf21-3a68-4664-8a9e-de16293f8c77",
          "Url": "https://capes.bedrock-cosmos.app/zips/UnusedFlame_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Greek Mythology Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "44f4cdb4-322d-41b0-b2fb-f6c3a3e79429",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"fe62dada-d163-4aa3-96e3-e75533ff4810", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "fe62dada-d163-4aa3-96e3-e75533ff4810",
      "Contents": [
        {
          "Id": "3a3dea37-f4dd-48c6-9a00-1ea3d18c3f9c",
          "Url": "https://capes.bedrock-cosmos.app/zips/CaptainZombie_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Halloween Charity Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b0263bf5-d91a-47ea-9ac0-190a272de0b5",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"d2368d34-eb2a-408c-b10b-44526c8db77c", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "d2368d34-eb2a-408c-b10b-44526c8db77c",
      "Contents": [
        {
          "Id": "9bcba07d-d2e3-47f0-9a02-6705dfb82b75",
          "Url": "https://capes.bedrock-cosmos.app/zips/HeadlessHorseman_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Halloween Charity Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "38ecc6b8-4132-4b7e-a1dc-95ccdc629a81",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"ce68e327-e923-436c-9082-0002e35dec58", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ce68e327-e923-436c-9082-0002e35dec58",
      "Contents": [
        {
          "Id": "79e923eb-9e34-45b3-bcce-5bc3f2844c7e",
          "Url": "https://capes.bedrock-cosmos.app/zips/BrideOfFrankenstein_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Halloween Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a4b2b9f2-daf3-43e2-9932-01c3200bf5e8",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"7240188f-2a70-47f5-9a90-cf59979068f8", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "7240188f-2a70-47f5-9a90-cf59979068f8",
      "Contents": [
        {
          "Id": "f29d6f5b-78df-4b54-908a-9355a1c9996c",
          "Url": "https://capes.bedrock-cosmos.app/zips/Devil_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Halloween Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "795a848b-7e03-4306-8d44-c2a8f996d22f",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"e6856cbc-8e90-4dd2-b923-7731a42b20a5", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "e6856cbc-8e90-4dd2-b923-7731a42b20a5",
      "Contents": [
        {
          "Id": "1a8c083c-4835-42ae-af8c-11bc3c6b5204",
          "Url": "https://capes.bedrock-cosmos.app/zips/Dracula_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Halloween Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "fc9d897f-f0fa-4bd6-a78f-313b82d7b5c4",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"24b6e7e9-3d7b-4b11-9b16-c31ddcc86c6d", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "24b6e7e9-3d7b-4b11-9b16-c31ddcc86c6d",
      "Contents": [
        {
          "Id": "dcb8b6e1-3911-4ee6-921c-14b39d1dfabb",
          "Url": "https://capes.bedrock-cosmos.app/zips/EvilWizard_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Halloween Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "9162ace0-a67b-401c-821b-51cb599db4a2",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"2cf7058d-7983-4391-b2d4-19e4bbb0a193", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "2cf7058d-7983-4391-b2d4-19e4bbb0a193",
      "Contents": [
        {
          "Id": "7a0323a4-91ee-465a-a31d-f92a450382d9",
          "Url": "https://capes.bedrock-cosmos.app/zips/MamanBrigitte_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Halloween Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d51e0fef-3cec-4526-91e5-23be00572bca",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"758f609a-08d7-475b-a51b-8e5969a551a1", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "758f609a-08d7-475b-a51b-8e5969a551a1",
      "Contents": [
        {
          "Id": "65f944ea-9b94-43a8-a9c6-6f209911a70f",
          "Url": "https://capes.bedrock-cosmos.app/zips/GrimReaper_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Halloween Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3d4c2f0a-8480-485c-9f1d-d18944af38ec",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"d6a699e7-34cc-420b-90d6-b91b1982a1ec", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "d6a699e7-34cc-420b-90d6-b91b1982a1ec",
      "Contents": [
        {
          "Id": "89974215-86bc-40a5-b8f8-0b955cb1548b",
          "Url": "https://capes.bedrock-cosmos.app/zips/WickedWitch_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Halloween Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f5e722e9-83c5-4af3-87a1-c1454db6d8c1",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"0f06b4ce-1551-47e4-87d9-fe2457e24550", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "0f06b4ce-1551-47e4-87d9-fe2457e24550",
      "Contents": [
        {
          "Id": "b98b59b5-6f70-42c5-b021-2088ea4b531d",
          "Url": "https://capes.bedrock-cosmos.app/zips/Drone_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Master Chief Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "6c08e33f-e75f-43fe-b22a-4c78aeb3e4f9",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"378ea401-3dc4-43a6-878f-bd6f7d7745d2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "378ea401-3dc4-43a6-878f-bd6f7d7745d2",
      "Contents": [
        {
          "Id": "c8db9671-0e23-4031-b06c-51c6572df35c",
          "Url": "https://capes.bedrock-cosmos.app/zips/BrideSackgirl_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "LittleBigPlanet™ Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "60f8732f-c80d-4dd3-9973-ac2aebb9fabb",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"398dad88-b181-4a5f-b3d4-9cced549eaa5", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "398dad88-b181-4a5f-b3d4-9cced549eaa5",
      "Contents": [
        {
          "Id": "23d1f260-43ba-4927-9610-3b12ff48b424",
          "Url": "https://capes.bedrock-cosmos.app/zips/DragonSackboy_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "LittleBigPlanet™ Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b972c6d6-2ee5-496e-8c8c-5f2b555d4bf9",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"34213a3e-5747-4d86-a8cd-bb131dbc0bf6", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "34213a3e-5747-4d86-a8cd-bb131dbc0bf6",
      "Contents": [
        {
          "Id": "73c4303d-7246-4db6-a124-3fc4537e2bd9",
          "Url": "https://capes.bedrock-cosmos.app/zips/FairySackgirl_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "LittleBigPlanet™ Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ba9f5497-cf10-44a6-bb9b-11914004a209",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"11e6b451-9601-4580-9c59-840def60f762", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "11e6b451-9601-4580-9c59-840def60f762",
      "Contents": [
        {
          "Id": "651b0d58-6651-4da5-8ad2-fdb2ac1b0ebb",
          "Url": "https://capes.bedrock-cosmos.app/zips/TheNewton_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "LittleBigPlanet™ Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "bf262d5b-8203-411f-8d86-5ed3c3c13642",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"87f6a791-179c-4849-aeab-fb8b370ce203", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "87f6a791-179c-4849-aeab-fb8b370ce203",
      "Contents": [
        {
          "Id": "45d15706-3ddd-493e-80b1-e16a17019a5e",
          "Url": "https://capes.bedrock-cosmos.app/zips/PinkyBuflooms_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "LittleBigPlanet™ Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "21b54b70-1ca2-475a-8cdb-cec6346dd6a5",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"be747c5d-d1d4-41cc-a0ee-1fa364f3eae4", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "be747c5d-d1d4-41cc-a0ee-1fa364f3eae4",
      "Contents": [
        {
          "Id": "a94f0069-a1a9-4871-93ee-b2a6f4a51d60",
          "Url": "https://capes.bedrock-cosmos.app/zips/BlackPanther_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Avengers Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "681ab912-f814-4a56-8e4a-b7559db341df",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"4372a4b9-4347-4bf8-ba71-68d8237087a2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4372a4b9-4347-4bf8-ba71-68d8237087a2",
      "Contents": [
        {
          "Id": "446404f4-3555-40f6-be34-d7cc314d6068",
          "Url": "https://capes.bedrock-cosmos.app/zips/CaptainAmerica_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Avengers Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a8c0c92d-d3e9-48df-b8a4-80f91ebd42e7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"a19286be-c17f-4e88-aeea-cb2bec2fb047", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a19286be-c17f-4e88-aeea-cb2bec2fb047",
      "Contents": [
        {
          "Id": "133aea60-bf11-4ac2-82d5-e9706564721c",
          "Url": "https://capes.bedrock-cosmos.app/zips/Falcon_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Avengers Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "6858786f-0c94-44c3-8be6-de46d124c3a5",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b7817050-11a8-431f-ad0f-78bfad184939", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b7817050-11a8-431f-ad0f-78bfad184939",
      "Contents": [
        {
          "Id": "4275a55d-2686-4c89-bca7-d3c772c709db",
          "Url": "https://capes.bedrock-cosmos.app/zips/Loki_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Avengers Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "fa36aaae-32b0-49b0-92f2-59c340f13e29",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"8ef94505-b1c5-40ab-8c9b-83a060475ea5", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8ef94505-b1c5-40ab-8c9b-83a060475ea5",
      "Contents": [
        {
          "Id": "5596c731-6efd-406f-918f-d70c8f8ef049",
          "Url": "https://capes.bedrock-cosmos.app/zips/MoonKnight_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Avengers Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3f861730-a9c5-44e3-8e82-c982e62b6c09",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"e32fba53-9b31-4377-90f5-362d6f02b603", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "e32fba53-9b31-4377-90f5-362d6f02b603",
      "Contents": [
        {
          "Id": "0034a291-58b8-4752-beae-1d644ff511cd",
          "Url": "https://capes.bedrock-cosmos.app/zips/Taskmaster_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Avengers Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "ff2f4a96-19f5-4380-ba4b-554eecbc96c8",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"fe035e3d-1339-4bcd-aa09-40f3bb777ce3", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "fe035e3d-1339-4bcd-aa09-40f3bb777ce3",
      "Contents": [
        {
          "Id": "4a131161-bb7c-4618-92a5-a393b454047a",
          "Url": "https://capes.bedrock-cosmos.app/zips/Thor_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Avengers Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "44bff6c7-2ced-4492-81d2-3fca358f5507",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"f5c8d822-081a-4eaa-87d1-740388b6fcfc", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f5c8d822-081a-4eaa-87d1-740388b6fcfc",
      "Contents": [
        {
          "Id": "2066f77d-8a79-484e-8a43-47b8ae57bd7c",
          "Url": "https://capes.bedrock-cosmos.app/zips/Vision_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Avengers Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "757df9ca-abfb-40f9-93cf-e7287a5b240a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"730f596e-9ceb-4467-9fc5-f5a0b98150e3", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "730f596e-9ceb-4467-9fc5-f5a0b98150e3",
      "Contents": [
        {
          "Id": "49977dc2-0d4e-4f95-aa06-60f7db936eb5",
          "Url": "https://capes.bedrock-cosmos.app/zips/Wasp_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Avengers Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "27a7a04c-31c4-4332-8eca-4f4f1616a17b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"717c8fc3-b3fb-40b1-93e1-759e28e59cd3", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "717c8fc3-b3fb-40b1-93e1-759e28e59cd3",
      "Contents": [
        {
          "Id": "ef3527ce-f3bb-4271-a8b4-61c1a4dc550c",
          "Url": "https://capes.bedrock-cosmos.app/zips/AdamWarlock_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Guardians of the Galaxy Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f9eee07a-fa83-4d86-878b-f52a6fefdad4",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"aaed1892-49e7-4d6d-b831-478e3430cedd", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "aaed1892-49e7-4d6d-b831-478e3430cedd",
      "Contents": [
        {
          "Id": "be16c819-6e7c-4dd7-83d0-3a6bce7e16dc",
          "Url": "https://capes.bedrock-cosmos.app/zips/Angela_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Guardians of the Galaxy Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "610897f5-0abd-452a-a11c-b31030a36ac9",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"f7be084c-4b08-4c7c-8e4c-7aeac5b39361", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f7be084c-4b08-4c7c-8e4c-7aeac5b39361",
      "Contents": [
        {
          "Id": "79a5a141-eda9-4daa-badd-4fdb72cc7c63",
          "Url": "https://capes.bedrock-cosmos.app/zips/Quasar_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Guardians of the Galaxy Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e6245233-6a30-4d16-9bcb-f9159ac06863",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"3196d4be-7694-4079-9aff-038fae17c646", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "3196d4be-7694-4079-9aff-038fae17c646",
      "Contents": [
        {
          "Id": "30641f0a-c4e1-4b00-81c5-1d4079cb62cf",
          "Url": "https://capes.bedrock-cosmos.app/zips/RonanTheAccuser_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Guardians of the Galaxy Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a2a29a1e-a0fa-43a7-887d-82965b402ef5",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"3ac993e0-666d-41dc-a4c5-73a61aeaf4a7", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "3ac993e0-666d-41dc-a4c5-73a61aeaf4a7",
      "Contents": [
        {
          "Id": "d0641540-b401-413f-bfbb-c74d1d04f2ed",
          "Url": "https://capes.bedrock-cosmos.app/zips/TheCollector_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Guardians of the Galaxy Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "81afd016-e9ff-4d36-b170-43fd93b6aa3a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"83fd88f7-2661-48eb-b0dd-19ca46d7fd27", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "83fd88f7-2661-48eb-b0dd-19ca46d7fd27",
      "Contents": [
        {
          "Id": "c73b2f03-8206-4c04-a673-a938114fe173",
          "Url": "https://capes.bedrock-cosmos.app/zips/Wraith_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Guardians of the Galaxy Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "0bb5e522-ed3e-4b44-a4eb-40bed26489ba",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"1f3efb52-985c-41d6-bba3-84c82c8cd7d3", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1f3efb52-985c-41d6-bba3-84c82c8cd7d3",
      "Contents": [
        {
          "Id": "d2800095-8015-4c56-8f00-468a6ad352e5",
          "Url": "https://capes.bedrock-cosmos.app/zips/Kraven_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Spider-Man Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "67b693ec-c9b7-4612-ab32-08ab00d6ba20",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"1302fcaa-9de1-49eb-b9cd-a41f7c44a2d2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1302fcaa-9de1-49eb-b9cd-a41f7c44a2d2",
      "Contents": [
        {
          "Id": "83b2a228-6991-46e5-b79c-c32f50c89ab1",
          "Url": "https://capes.bedrock-cosmos.app/zips/Menace_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Spider-Man Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "48b0c40a-18b7-4649-b7a8-fc8337d2e8f7",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"2c0f3e81-90cc-4530-8f74-d357356e9a34", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "2c0f3e81-90cc-4530-8f74-d357356e9a34",
      "Contents": [
        {
          "Id": "6ea871f0-f754-45e9-acba-f5b0e7efd983",
          "Url": "https://capes.bedrock-cosmos.app/zips/Morbius_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Spider-Man Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "c4e2e985-4d0f-4450-99d3-e5b9a32bf1e9",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"efc102f0-3258-430e-adc4-c3d438c81889", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "efc102f0-3258-430e-adc4-c3d438c81889",
      "Contents": [
        {
          "Id": "30c6efc2-d64f-41bb-8127-e9b15160aec6",
          "Url": "https://capes.bedrock-cosmos.app/zips/Mysterio_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Spider-Man Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "20b98f87-f955-405f-9693-cafce2a25008",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"84013056-d26a-41de-a670-4d2c8b0dd8ac", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "84013056-d26a-41de-a670-4d2c8b0dd8ac",
      "Contents": [
        {
          "Id": "807a5176-f993-4bda-bb8c-f3a647644c84",
          "Url": "https://capes.bedrock-cosmos.app/zips/SpiderMan2099_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Spider-Man Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "8a82e868-0a15-4454-9eb8-345323d7dc2a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"444b313f-e84d-4598-b68f-897aca55b51f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "444b313f-e84d-4598-b68f-897aca55b51f",
      "Contents": [
        {
          "Id": "56f199c8-98f9-4587-80f4-629a137fbf41",
          "Url": "https://capes.bedrock-cosmos.app/zips/Vulture_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Marvel Spider-Man Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a188ea68-c075-4ddb-825f-14046c26eeea",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"630b51f3-19ea-46cd-9b8b-6c9e69457ccc", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "630b51f3-19ea-46cd-9b8b-6c9e69457ccc",
      "Contents": [
        {
          "Id": "8de69deb-59e3-406a-b108-3386750d681f",
          "Url": "https://capes.bedrock-cosmos.app/zips/RedRobedFigure_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Skin Pack 2",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e6fb940d-f4a0-49eb-b503-de200896909e",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"df15593e-30c2-470f-8559-afc6aebd3dd0", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "df15593e-30c2-470f-8559-afc6aebd3dd0",
      "Contents": [
        {
          "Id": "012e9566-0a05-495e-8cc5-a3279932ec75",
          "Url": "https://capes.bedrock-cosmos.app/zips/WhiteRobedFigure_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Skin Pack 2",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "645f2030-af28-4681-9588-9b3ebee025d3",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b3011c06-6997-4ece-9d4f-5044d4308d73", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b3011c06-6997-4ece-9d4f-5044d4308d73",
      "Contents": [
        {
          "Id": "c56a45d7-e2de-4e2e-a678-bb0dda0f8904",
          "Url": "https://capes.bedrock-cosmos.app/zips/Jak_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Skin Pack 3",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a35fbbc1-d2f7-4481-8a4b-69656e37652b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"c1974f5f-c852-4ad7-83dd-2d9bf5f740cf", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "c1974f5f-c852-4ad7-83dd-2d9bf5f740cf",
      "Contents": [
        {
          "Id": "b65cd99d-0443-4f73-87f7-ec4a6e2f20d2",
          "Url": "https://capes.bedrock-cosmos.app/zips/Ezio_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Skin Pack 4",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a32a3688-abe6-410c-a77f-50889aa3b1b3",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"45117ce7-6ffe-4d0d-85dc-842c4b386214", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "45117ce7-6ffe-4d0d-85dc-842c4b386214",
      "Contents": [
        {
          "Id": "2dcd502a-97f6-44c9-8cbe-6356e55817c8",
          "Url": "https://capes.bedrock-cosmos.app/zips/Knight1_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Skin Pack 4",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "abc25263-fcae-416e-b371-91eeb089dbe9",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"9f775505-639e-4a97-bb31-9c3208cf497f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "9f775505-639e-4a97-bb31-9c3208cf497f",
      "Contents": [
        {
          "Id": "00068673-39b8-4f15-b120-9111890baae3",
          "Url": "https://capes.bedrock-cosmos.app/zips/Knight2_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Skin Pack 4",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "17272d14-85c8-4710-b9aa-3c4f05b83f79",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"2bb26719-b784-4cea-83f6-5ed210c4ff90", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "2bb26719-b784-4cea-83f6-5ed210c4ff90",
      "Contents": [
        {
          "Id": "cf0c27ad-76dc-4cc8-806e-4918b7c586cd",
          "Url": "https://capes.bedrock-cosmos.app/zips/Knight3_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Skin Pack 4",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f0f32a99-49c0-4aa1-b43d-17e938c76bca",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"34d1c7e8-0dcc-43f8-a7a2-1e093482c9ca", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "34d1c7e8-0dcc-43f8-a7a2-1e093482c9ca",
      "Contents": [
        {
          "Id": "5f19897b-b259-4a7f-b42f-ad0429558f06",
          "Url": "https://capes.bedrock-cosmos.app/zips/Knight4_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Skin Pack 4",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "a812e130-ce71-4e48-bee3-0bb8a54fd602",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"4f5a1bda-d544-486e-a430-0d3e1551e73b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4f5a1bda-d544-486e-a430-0d3e1551e73b",
      "Contents": [
        {
          "Id": "b3f7a8ed-38ab-4da8-a712-519097c88a6a",
          "Url": "https://capes.bedrock-cosmos.app/zips/ShieldyBlockerson_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Skin Pack 6",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "c9d6debb-c787-4bbf-a847-20a1c9a5bcba",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"c7f7b843-846c-49c8-bd55-06534e48deb2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "c7f7b843-846c-49c8-bd55-06534e48deb2",
      "Contents": [
        {
          "Id": "efcd2737-8c6b-4d08-86ed-863f1e96a58d",
          "Url": "https://capes.bedrock-cosmos.app/zips/Nazir_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Dragonborn Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "033eed6c-dbd4-472a-b944-c85fb1ad0418",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"265937c0-d99d-449d-8c1e-244b5ea1571e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "265937c0-d99d-449d-8c1e-244b5ea1571e",
      "Contents": [
        {
          "Id": "ed7de7ab-ebf7-41d3-961b-e2049a439bf6",
          "Url": "https://capes.bedrock-cosmos.app/zips/VampireLord_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Dragonborn Mash-up",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "091da699-c78f-45c8-b168-e20911bda334",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"8ac65528-ed62-4495-aa47-b453b3320916", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8ac65528-ed62-4495-aa47-b453b3320916",
      "Contents": [
        {
          "Id": "aa51a29f-0c31-46cd-92bd-d19c130842ec",
          "Url": "https://capes.bedrock-cosmos.app/zips/LandoCalrission_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Star Wars Classic Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "fefa8058-d207-4f99-9325-63d089038d67",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"3ad68359-a28f-4fd1-bd37-f00b7e4f1b4a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "3ad68359-a28f-4fd1-bd37-f00b7e4f1b4a",
      "Contents": [
        {
          "Id": "14ef85f8-a3db-4cce-9419-1a72f89d724c",
          "Url": "https://capes.bedrock-cosmos.app/zips/Yoda_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Star Wars Classic Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "429a9191-e7c1-4dbe-bafb-9e915941be9b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"6c6df40b-c150-493d-848d-39627c3f48a0", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "6c6df40b-c150-493d-848d-39627c3f48a0",
      "Contents": [
        {
          "Id": "8372281f-e356-45a8-b256-0427d4fab0a7",
          "Url": "https://capes.bedrock-cosmos.app/zips/BossNass_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Star Wars Prequel Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "266c496d-189d-4476-9fb0-55c45f9de7ba",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"dbfab819-3a56-4ee4-8688-6a3e5065136f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "dbfab819-3a56-4ee4-8688-6a3e5065136f",
      "Contents": [
        {
          "Id": "956421d3-49b7-4daf-9e44-57191f48e94e",
          "Url": "https://capes.bedrock-cosmos.app/zips/CountDooku_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Star Wars Prequel Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "f5248800-5ab2-4a62-b75d-11a0d5418302",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"75d5497d-4ab9-4e43-924e-108500285082", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "75d5497d-4ab9-4e43-924e-108500285082",
      "Contents": [
        {
          "Id": "505a1518-b793-42e5-a414-34b19f95c943",
          "Url": "https://capes.bedrock-cosmos.app/zips/GeneralGrievous_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Star Wars Prequel Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "c0970fd8-575e-4e11-831e-6ee9dc466752",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"e9638da5-88db-4a0d-b682-912742e43895", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "e9638da5-88db-4a0d-b682-912742e43895",
      "Contents": [
        {
          "Id": "96b8dc5f-5950-49f1-b296-4e7bf88631fe",
          "Url": "https://capes.bedrock-cosmos.app/zips/MasAmedda_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Star Wars Prequel Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "b58039c5-9589-4b3c-a7f1-71ec09e8e28e",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"2f4020a5-027f-4680-838c-0439bcecee90", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "2f4020a5-027f-4680-838c-0439bcecee90",
      "Contents": [
        {
          "Id": "56865dba-8190-413e-b99f-f59a4bffbacf",
          "Url": "https://capes.bedrock-cosmos.app/zips/SenatorPadmeAmidala_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Star Wars Prequel Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "8964afa2-0f6d-43e5-b570-2ce39189f159",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"49ced7b9-c18e-46e0-a955-fe9d521783b8", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "49ced7b9-c18e-46e0-a955-fe9d521783b8",
      "Contents": [
        {
          "Id": "d116ae9a-6bfd-4d2a-ac99-4fb45af7d15d",
          "Url": "https://capes.bedrock-cosmos.app/zips/SenatorPalpatine_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Star Wars Prequel Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "08b1a220-1906-44eb-8627-0d67fc785264",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"670f3827-b260-47a7-96e5-96b1fe02ce77", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "670f3827-b260-47a7-96e5-96b1fe02ce77",
      "Contents": [
        {
          "Id": "6b844c89-59d9-4caa-9143-1a5b76909d37",
          "Url": "https://capes.bedrock-cosmos.app/zips/PoggleTheLesser_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Star Wars Prequel Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "656e8b58-d5f1-41be-93c4-63d994ad02ef",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"12fba8b3-ed4d-4e91-9eea-56d3e5f35cfe", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "12fba8b3-ed4d-4e91-9eea-56d3e5f35cfe",
      "Contents": [
        {
          "Id": "a4980c64-f04d-4fa3-97a7-7e1290836bbf",
          "Url": "https://capes.bedrock-cosmos.app/zips/UnusedWings_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Star Wars Prequel Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "df497cd9-4537-42b2-bcc3-26a79246b972",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"f3a358d0-d3d8-42b2-b01b-47aa2533754c", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f3a358d0-d3d8-42b2-b01b-47aa2533754c",
      "Contents": [
        {
          "Id": "b2322207-6c80-4d6a-b0be-58a61075ccbd",
          "Url": "https://capes.bedrock-cosmos.app/zips/SherriAndTerri_cape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "The Simpsons Skin Pack",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "27656373-793b-4ae9-97ab-279686f319b8",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"0e377825-9488-4496-b75a-21de4b008b0a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "0e377825-9488-4496-b75a-21de4b008b0a",
      "Contents": [
        {
          "Id": "8a0ade43-c2b4-44b1-abcb-58de6a7ecc45",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/TinyTakeoverCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "3ddf71f3-8eb2-4491-9b48-cd1c8bf6f465",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"6344711f-031f-4a4b-a186-1a0293bef194", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "6344711f-031f-4a4b-a186-1a0293bef194",
      "Contents": [
        {
          "Id": "aa6e6a91-46d3-4f55-baab-5f7a69f986fc",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/WildflowerCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "6c6e36e6-d28e-4eac-bdcb-34db5f652b1e",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"852bea8b-3645-4ef8-959b-b0dd23285e24", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "852bea8b-3645-4ef8-959b-b0dd23285e24",
      "Contents": [
        {
          "Id": "01e23ae8-40a1-49bd-bf2c-308c11a5d965",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/EssentialCubeCraftCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "abdf8792-936b-4a97-bd84-375cb90e43ab",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"cae495c4-7242-4504-a107-e4566fb8dc0d", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "cae495c4-7242-4504-a107-e4566fb8dc0d",
      "Contents": [
        {
          "Id": "29855f52-1ddd-4b3a-ab6e-98fc81408eb1",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/TrialCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "8c5cf4ee-7df9-4b5f-b623-d4c876762df1",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"8cd0c142-1562-4212-9c27-c38f2ef0f325", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8cd0c142-1562-4212-9c27-c38f2ef0f325",
      "Contents": [
        {
          "Id": "2e52be11-cd91-4b7e-be0c-c73b95c08808",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/EssentialDiscordCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "04ef3712-d5ad-4a5e-b172-98e3b3ab427a",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"c3ee626e-91a6-4a8b-8d49-fd0f6ab2ba65", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "c3ee626e-91a6-4a8b-8d49-fd0f6ab2ba65",
      "Contents": [
        {
          "Id": "3d206a91-99ea-48de-8a4e-b35b2cd608e1",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/NautilusCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "147e5fa7-22a2-48b9-bb26-c62dec84fd18",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"49b293c9-c0b7-4100-a760-17d213e9417e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "49b293c9-c0b7-4100-a760-17d213e9417e",
      "Contents": [
        {
          "Id": "d04e2614-03c5-4173-98d9-4077018f6a18",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/NautilusZombieCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "c00b714d-3209-46a5-8dc3-a01b978a4790",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"8cd61655-67ca-42e8-bffa-84edfc68c3fb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8cd61655-67ca-42e8-bffa-84edfc68c3fb",
      "Contents": [
        {
          "Id": "e87066c3-02bd-4494-bbed-dc99b47f8c97",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/CopperGolemCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "c8b19ce8-557e-42bf-a452-bab3739b64ca",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"2c018d95-d44d-4b6b-b8a1-7135411ef257", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "2c018d95-d44d-4b6b-b8a1-7135411ef257",
      "Contents": [
        {
          "Id": "862f2c97-0761-46a3-ba62-313d4c2b638e",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/CopperGolemExposedCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "bc79bee1-477d-49c1-9582-65a1223877ba",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"def17786-1e66-44ee-aace-6f7ce7037dc0", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "def17786-1e66-44ee-aace-6f7ce7037dc0",
      "Contents": [
        {
          "Id": "2bb157de-4366-410f-8db8-4573244bd835",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/CopperGolemWeatheredCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "bbe12dde-1cd2-4639-9ec9-f19d78e47485",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"1e20accc-ce9d-49ff-b9fd-88dff3f8ee98", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1e20accc-ce9d-49ff-b9fd-88dff3f8ee98",
      "Contents": [
        {
          "Id": "4d332e49-4b0f-4ffe-b51b-49bdc3d01c71",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/CopperGolemOxidizedCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "9097cdc1-8b4b-4975-8b68-1c22ce1a86d3",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"dee1ead7-6f6c-45d7-b647-5e733ef90a5b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "dee1ead7-6f6c-45d7-b647-5e733ef90a5b",
      "Contents": [
        {
          "Id": "ec222e94-1261-4a16-a125-ce697953660d",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/SkyCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "faa132bf-4f94-45d0-afbd-e92aac77479b",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"2be802db-df1a-403c-a8e5-a83d09e6f539", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "2be802db-df1a-403c-a8e5-a83d09e6f539",
      "Contents": [
        {
          "Id": "be142253-9883-44e3-9623-980f98c212c4",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/BlossomCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "c28a0e7f-35ba-4dee-a784-49fe521b0992",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"1ef8a9ed-7bae-432c-bd86-953269ca0531", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1ef8a9ed-7bae-432c-bd86-953269ca0531",
      "Contents": [
        {
          "Id": "45bef993-a02c-4b19-8320-25f639fa0a8a",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/CreakingCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "6dd88cec-2d57-491f-ba4d-d9c2f41798e4",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"8fb07868-d2e7-4b06-84f8-fc38e4f6cd9a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8fb07868-d2e7-4b06-84f8-fc38e4f6cd9a",
      "Contents": [
        {
          "Id": "d96c3f1e-f76f-4d6c-a81b-35f66ab15524",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/SnifferCape.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "41dfccaa-706b-4b6f-8d10-9d8be954d066",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"95a65048-d96d-4061-8c4c-8dfb3343ea6c", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "95a65048-d96d-4061-8c4c-8dfb3343ea6c",
      "Contents": [
        {
          "Id": "4a46dd60-6900-497c-afbc-e257f0410e2d",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/EssentialPrideCape1.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "e3e13cc6-a1cf-4839-96af-5f50686e76d9",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"48d3ae91-5066-40f1-83f6-0a9d56166eff", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "48d3ae91-5066-40f1-83f6-0a9d56166eff",
      "Contents": [
        {
          "Id": "c8b64a18-163c-418f-ba9d-698d0ea9d628",
          "Url": "https://capes.bedrock-cosmos.app/zips/Essential/EssentialPrideCape2.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.16.0",
          "Type": "personabinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Essential",
        "originalCreatorId": "9926cc22-2eb0-4bd4-a39d-76c8082a1c58",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "persona_piece",
            "uuid": "d4bcd439-d36f-4c30-b1e1-c7c4d02fa6f5",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"8e78a44d-0c1f-4ce2-826b-8bbc555012de", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "SourceEntity": {
        "Id": "B63A0803D3653643",
        "Type": "namespace",
        "TypeString": "namespace"
      },
      "SourceEntityKey": {
        "Id": "B63A0803D3653643",
        "Type": "namespace",
        "TypeString": "namespace"
      },
      "Id": "8e78a44d-0c1f-4ce2-826b-8bbc555012de",
      "Type": "bundle",
      "AlternateIds": [
        {
          "Type": "FriendlyId",
          "Value": "ebd5c3b4-eef1-408d-b483-e4b2bd5add12"
        }
      ],
      "FriendlyId": "ebd5c3b4-eef1-408d-b483-e4b2bd5add12",
      "Title": {
        "NEUTRAL": "1st Birthday Skin Pack",
        "bg-BG": "Пакет скинове за първия рожден ден",
        "cs-CZ": "1. narozeninová sada skinů",
        "da-DK": "1-års fødselsdagsskinpakke",
        "de-DE": "Skinpaket 1. Geburtstag",
        "el-GR": "Πακέτο εμφανίσεων 1ων γενεθλίων",
        "en-GB": "1st Birthday Skin Pack",
        "en-US": "1st Birthday Skin Pack",
        "es-ES": "Pack de aspecto del 1.er aniversario",
        "es-MX": "Pack de aspecto del 1.er aniversario",
        "fi-FI": "1. synttäriolemuspaketti",
        "fr-CA": "Pack de skins 1er anniversaire",
        "fr-FR": "Pack de skins 1er anniversaire",
        "hu-HU": "1. születésnapi felületcsomag",
        "id-ID": "Paket Skin Ulang Tahun Pertama",
        "it-IT": "Pacchetto skin 1° compleanno",
        "ja-JP": "1 周年記念スキンパック",
        "ko-KR": "1주년 기념 스킨 팩",
        "nb-NO": "Skallpakke til 1-årsdagen",
        "nl-NL": "Skinpakket eerste verjaardag",
        "pl-PL": "Zestaw skórek na pierwsze urodziny",
        "pt-BR": "1º Pacote de Capas de Aniversário",
        "pt-PT": "Pack de Skins – 1.º Aniversário",
        "ru-RU": "Набор скинов «Первая годовщина»",
        "sk-SK": "Balíček vzhľadov k 1. narodeninám",
        "sv-SE": "Ettårsdagspaket",
        "tr-TR": "1. Doğum Günü Dış Görünüş Paketi",
        "uk-UA": "Пакет скінів \"1-й день народження\"",
        "zh-CN": "一周年生日皮肤包",
        "zh-TW": "一週年外觀套件",
        "neutral": "1st Birthday Skin Pack"
      },
      "Description": {
        "NEUTRAL": "Join the Minecraft party now!",
        "bg-BG": "Присъединете се към празненството на Minecraft сега!",
        "cs-CZ": "Přidejte se k oslavám Minecraftu!",
        "da-DK": "Kom med til Minecraft-festen nu!",
        "de-DE": "Komm auf die Minecraft-Party!",
        "el-GR": "Έλα τώρα στο πάρτι του Minecraft!",
        "en-GB": "Join the Minecraft party now!",
        "en-US": "Join the Minecraft party now!",
        "es-ES": "¡Únete ya a la fiesta de Minecraft!",
        "es-MX": "¡Únete a la fiesta de Minecraft!",
        "fi-FI": "Liity nyt Minecraft-juhliin!",
        "fr-CA": "Entrez dans la fête Minecraft dès maintenant!",
        "fr-FR": "Vous êtes invités à la fête Minecraft !",
        "hu-HU": "Csatlakozz most a Minecraft-partihoz!",
        "id-ID": "Bergabunglah dengan pesta Minecraft sekarang!",
        "it-IT": "Unisciti ora al party di Minecraft!",
        "ja-JP": "Minecraft のパーティーに今すぐ参加しよう！",
        "ko-KR": "지금 Minecraft 파티에 참여하세요!",
        "nb-NO": "Bil med på Minecraft-festen nå!",
        "nl-NL": "Doe mee met het Minecraft-feest!",
        "pl-PL": "Weź udział w minecraftowej imprezie!",
        "pt-BR": "Entre na festa do Minecraft já!",
        "pt-PT": "Junta-te já à festa Minecraft!",
        "ru-RU": "Присоединяйтесь к вечеринке Minecraft прямо сейчас!",
        "sk-SK": "Pripojte sa k večierku v hre Minecraft!",
        "sv-SE": "Häng med på Minecraft-kalaset nu!",
        "tr-TR": "Minecraft partisine hemen katılın!",
        "uk-UA": "Долучайтеся до свята в Minecraft!",
        "zh-CN": "立刻加入《我的世界》派对吧！",
        "zh-TW": "立即加入 Minecraft 派對！",
        "neutral": "Join the Minecraft party now!"
      },
      "Keywords": {
        "NEUTRAL": {
          "Values": ["Skin", "Festival", "Survival"]
        },
        "bg-BG": {
          "Values": ["Скин", "Фестивал", "Оцеляване"]
        },
        "cs-CZ": {
          "Values": ["Skin", "Festival", "Hry o přežití"]
        },
        "da-DK": {
          "Values": ["Skin", "Festival", "Overlevelse"]
        },
        "de-DE": {
          "Values": ["Skin", "Fest", "Survival"]
        },
        "el-GR": {
          "Values": ["Εμφάνιση", "Φεστιβάλ", "Επιβίωση"]
        },
        "en-GB": {
          "Values": ["Skin", "Festival", "Survival"]
        },
        "en-US": {
          "Values": ["Skin", "Festival", "Survival"]
        },
        "es-ES": {
          "Values": ["Piel", "Festival", "Supervivencia"]
        },
        "es-MX": {
          "Values": ["Aspecto", "Festival", "Supervivencia"]
        },
        "fi-FI": {
          "Values": ["Olemus", "Festivaali", "Selviytyminen"]
        },
        "fr-CA": {
          "Values": ["Skin", "Festival", "Survie"]
        },
        "fr-FR": {
          "Values": ["Skin", "Festival", "Survie"]
        },
        "hu-HU": {
          "Values": ["Felület", "Fesztivál", "Túlélés"]
        },
        "id-ID": {
          "Values": ["Skin", "Festival", "Bertahan Hidup"]
        },
        "it-IT": {
          "Values": ["Skin", "Festival", "Sopravvivenza"]
        },
        "ja-JP": {
          "Values": ["スキン", "祭り", "サバイバル"]
        },
        "ko-KR": {
          "Values": ["스킨", "축제", "서바이벌"]
        },
        "nb-NO": {
          "Values": ["Skall", "Festival", "Overlevelse"]
        },
        "nl-NL": {
          "Values": ["Skin", "Festival", "Survival"]
        },
        "pl-PL": {
          "Values": ["Skórka", "Festiwal", "Przetrwanie"]
        },
        "pt-BR": {
          "Values": ["Capa", "Festival", "Sobrevivência"]
        },
        "pt-PT": {
          "Values": ["Skin", "Festival", "Sobrevivência"]
        },
        "ru-RU": {
          "Values": ["Скин", "Фестиваль", "Выживание"]
        },
        "sk-SK": {
          "Values": ["Vzhľad", "Festival", "Prežitie"]
        },
        "sv-SE": {
          "Values": ["Utseende", "Festival", "Överlevnad"]
        },
        "tr-TR": {
          "Values": ["Dış Görünüş", "Şenlik", "Hayatta Kalma"]
        },
        "uk-UA": {
          "Values": ["Скін", "Фестиваль", "Виживання"]
        },
        "zh-CN": {
          "Values": ["皮肤", "节日", "生存"]
        },
        "zh-TW": {
          "Values": ["膚色", "節慶", "生存"]
        },
        "neutral": {
          "Values": ["Skin", "Festival", "Survival"]
        }
      },
      "ContentType": "MarketplaceDurableCatalog_V1.2",
      "CreatorEntityKey": {
        "Id": "301F442C3B63DC20",
        "Type": "master_player_account",
        "TypeString": "master_player_account"
      },
      "CreatorEntity": {
        "Id": "301F442C3B63DC20",
        "Type": "master_player_account",
        "TypeString": "master_player_account"
      },
      "IsStackable": false,
      "Platforms": [
        "android.amazonappstore",
        "android.googleplay",
        "b.store",
        "ios.store",
        "nx.store",
        "oculus.store.gearvr",
        "oculus.store.rift",
        "uwp.store",
        "uwp.store.mobile",
        "xboxone.store",
        "title.bedrockvanilla",
        "title.earth"
      ],
      "Tags": [
        "8e78a44d-0c1f-4ce2-826b-8bbc555012de",
        "202539ce-e6c5-40b5-a4a1-4296277d18f6",
        "skinpack",
        "has_skinpack",
        "tag.limited",
        "tag.skin",
        "tag.festival",
        "genre.survival",
        "1P"
      ],
      "CreationDate": "2018-07-31T20:55:01.99Z",
      "LastModifiedDate": "2023-08-10T03:32:11.7Z",
      "StartDate": "2017-09-12T15:00:00Z",
      "Contents": [
        {
          "Id": "e59f7dcb-c993-4514-85e8-2d5fbcc8741b",
          "Url": "https://cdn.bedrockcosmos.app/uss/20253/1stBirthday.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "Images": [
        {
          "Id": "b3292e60-9898-4813-869c-40b301b5ac0a",
          "Tag": "Thumbnail",
          "Type": "Thumbnail",
          "Url": "https://bedrock-cosmos.app/thumbnails/1stBirthdayRestored_thumbnail.jpg"
        }
      ],
      "ItemReferences": [
        {
          "Id": "d5e9ac7f-8c6c-4f47-97ec-3d9defc4f480",
          "Amount": 1
        }
      ],
      "Price": {
        "Prices": [
          {
            "Amounts": [
              {
                "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                "Amount": 0
              }
            ]
          },
          {
            "Amounts": [
              {
                "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                "Amount": 0
              }
            ]
          }
        ],
        "RealPrices": []
      },
      "PriceOptions": {
        "Prices": [
          {
            "Amounts": [
              {
                "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                "Amount": 0
              }
            ]
          },
          {
            "Amounts": [
              {
                "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                "Amount": 0
              }
            ]
          }
        ],
        "RealPrices": []
      },
      "Rating": {
        "Average": 4.7,
        "TotalCount": 524364,
        "Count5Star": 461054,
        "Count4Star": 28387,
        "Count3Star": 12450,
        "Count2Star": 5171,
        "Count1Star": 17302
      },
      "DeepLinks": [],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "price": 0,
        "purchasable": true,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "202539ce-e6c5-40b5-a4a1-4296277d18f6",
            "version": "3.1.26"
          }
        ],
        "skinPack": {
          "count": 22
        },
        "publicChangelog": {
          "neutral": "",
          "en-US": "",
          "bg-BG": "",
          "cs-CZ": "",
          "da-DK": "",
          "de-DE": "",
          "el-GR": "",
          "en-GB": "",
          "es-ES": "",
          "es-MX": "",
          "fi-FI": "",
          "fr-CA": "",
          "fr-FR": "",
          "hu-HU": "",
          "id-ID": "",
          "it-IT": "",
          "ja-JP": "",
          "ko-KR": "",
          "nb-NO": "",
          "nl-NL": "",
          "pl-PL": "",
          "pt-BR": "",
          "pt-PT": "",
          "ru-RU": "",
          "sk-SK": "",
          "sv-SE": "",
          "tr-TR": "",
          "uk-UA": "",
          "zh-CN": "",
          "zh-TW": ""
        },
        "lastUpdated": "1.16.210"
      },
      "ETag": "\"1000b6e8-0000-0800-0000-6906c62d0000\""
    }
  }
}
)COSMOS"},
  {"02b54955-9b4d-40cb-9b73-360d23cf1b9e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "02b54955-9b4d-40cb-9b73-360d23cf1b9e",
      "Contents": [
        {
          "Id": "1dc9046a-bae8-48d2-9ccf-9c9b51ce0062",
          "Url": "https://cdn.bedrockcosmos.app/uss/e8237/2ndBirthdaySkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "e823767b-7337-49da-aaef-de616d2c2c3a",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"770196c2-718f-43ef-94d6-8e53a7b5b0af", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "770196c2-718f-43ef-94d6-8e53a7b5b0af",
      "Contents": [
        {
          "Id": "c69a7b69-98d4-4cad-a112-f66ddaf75033",
          "Url": "https://cdn.bedrockcosmos.app/uss/d532b/2ndBirthday.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.10",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "d532b9b3-eddc-4f98-96fc-5fe5e227c426",
            "version": "3.1.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"603d6be1-7745-4ad8-8af3-908ad017500f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "603d6be1-7745-4ad8-8af3-908ad017500f",
      "Contents": [
        {
          "Id": "aed620be-727f-43b4-8dde-0292f89365cd",
          "Url": "https://cdn.bedrockcosmos.app/uss/e4d58/3rdBirthdaySkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "e4d586b5-ab6f-4fd5-82d5-6158a755e012",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"a2a7ad5c-f55e-44ff-9f70-a5ae1db821b4", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a2a7ad5c-f55e-44ff-9f70-a5ae1db821b4",
      "Contents": [
        {
          "Id": "81b54c03-4bd4-4ebd-bf86-6c2f235a4431",
          "Url": "https://cdn.bedrockcosmos.app/uss/659b5/4thBirthdaySkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "659b5fdb-3260-47ff-9aeb-41818d74acdd",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"cc1e1b86-1863-4c1c-9103-b82b2b70a74b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "cc1e1b86-1863-4c1c-9103-b82b2b70a74b",
      "Contents": [
        {
          "Id": "787ab79c-9cbd-4f90-9030-2217595edc8e",
          "Url": "https://cdn.bedrockcosmos.app/uss/433cb/5thBirthdaySkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "433cbba0-1c00-48e8-94ef-59cfc38da4ca",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b3b50166-5612-4ff1-8f03-9af0b01cb4da", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b3b50166-5612-4ff1-8f03-9af0b01cb4da",
      "Contents": [
        {
          "Id": "3ce64ce3-56a1-41a0-aa42-26f4ed41e997",
          "Url": "https://cdn.bedrockcosmos.app/uss/4972c/FoundersCapeSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.10",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "4972c4c7-6eac-4e4c-b2d0-822b590b6fa7",
            "version": "3.11.26"
          },
          {
            "type": "persona_piece",
            "uuid": "1b99b77c-3caa-4aaa-8f79-f79f053e586f",
            "version": "1.0.1"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"7dae6bfe-e92b-403e-842e-d8d75e329644", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "7dae6bfe-e92b-403e-842e-d8d75e329644",
      "Contents": [
        {
          "Id": "a3f382b3-c684-4f1c-8759-dedb83853e21",
          "Url": "https://cdn.bedrockcosmos.app/uss/42ae6/Minecon2015SkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "42ae66b4-d3db-49be-8dd8-207a0cade6d8",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"20b4d681-df67-420c-aff3-07673bb44d07", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "20b4d681-df67-420c-aff3-07673bb44d07",
      "Contents": [
        {
          "Id": "349c67c5-83de-4db2-bbbe-e63ecbbc907c",
          "Url": "https://cdn.bedrockcosmos.app/uss/838bd/MINECON2016SkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "838bdb6b-bf30-42ca-a4d8-e35865fba8e2",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"29ce2f54-be6e-4748-b63e-335d6fa8a9d0", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "29ce2f54-be6e-4748-b63e-335d6fa8a9d0",
      "Contents": [
        {
          "Id": "6f35813d-e4d5-4717-b735-0e51c40ef04f",
          "Url": "https://cdn.bedrockcosmos.app/uss/6c37b/CoralCraftersSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.4.1",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "6c37b8c1-ff20-4bf6-a20c-5045aa2d3f57",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"5b13cb52-e2bf-438c-97f2-1105c54929d9", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "5b13cb52-e2bf-438c-97f2-1105c54929d9",
      "Contents": [
        {
          "Id": "91551b69-a8ab-447a-b0b6-693e9086eae3",
          "Url": "https://cdn.bedrockcosmos.app/uss/91551/HalloweenCharitySkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "MinecraftHidden",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "91551b69-a8ab-447a-b0b6-693e9086eae3",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"0d8ce926-257f-4297-b585-05d1f88e782a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "0d8ce926-257f-4297-b585-05d1f88e782a",
      "Contents": [
        {
          "Id": "59e17bba-bf02-4ea9-9ab4-9236bcb2a08e",
          "Url": "https://cdn.bedrockcosmos.app/uss/a618c/PawsandClawsCosplayPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.8.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "a618ca05-77ba-4afb-bb9a-8fdb413219ab",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"358a8710-bcf4-4cd7-ae86-a63ffec500c8", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "358a8710-bcf4-4cd7-ae86-a63ffec500c8",
      "Contents": [
        {
          "Id": "5fe3e01c-609b-497e-b17e-342b83281369",
          "Url": "https://cdn.bedrockcosmos.app/uss/5fe3e/SummerOfArcadeSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "MinecraftHidden",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "5fe3e01c-609b-497e-b17e-342b83281369",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"60a2047b-fe99-4a1d-9ccf-79d6a9b63adb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "60a2047b-fe99-4a1d-9ccf-79d6a9b63adb",
      "Contents": [
        {
          "Id": "e58fb8eb-0e70-4c89-9f60-e7a4a72f9061",
          "Url": "https://cdn.bedrockcosmos.app/uss/759ae/DoctorWho1.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "e58fb8eb-0e70-4c89-9f60-e7a4a72f9061",
            "version": "1.0.6"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"c65b1919-df90-4c9b-b3d5-a59c7d7a3979", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "c65b1919-df90-4c9b-b3d5-a59c7d7a3979",
      "Contents": [
        {
          "Id": "83ba3582-970f-4100-b8cc-277a10217b13",
          "Url": "https://cdn.bedrockcosmos.app/uss/0e53b/DoctorWho2.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "83ba3582-970f-4100-b8cc-277a10217b13",
            "version": "1.0.6"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"0c77040a-abb6-4938-963d-5a8e9872c85c", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "0c77040a-abb6-4938-963d-5a8e9872c85c",
      "Contents": [
        {
          "Id": "778acf48-34f8-4a7e-b0db-e95fbf5ee7f3",
          "Url": "https://cdn.bedrockcosmos.app/uss/70777/EarthSkin.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.10",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "70777aa6-5949-4529-947f-2fcdbc94c3cb",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"01d22780-c8c6-421d-a5cf-c615a398c480", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "01d22780-c8c6-421d-a5cf-c615a398c480",
      "Contents": [
        {
          "Id": "791adaf3-b6df-4938-9617-9cfe92d61999",
          "Url": "https://cdn.bedrockcosmos.app/uss/ac391/PrivateMumboJumboAndGrianSkins.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.13.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "ac3914ce-f321-4b13-89bf-5a74990242c8",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"62c68fd4-3075-40ed-8b7b-15dcc7b667ff", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "62c68fd4-3075-40ed-8b7b-15dcc7b667ff",
      "Contents": [
        {
          "Id": "d44ba892-7378-4fcd-a3f1-72de53675d24",
          "Url": "https://cdn.bedrockcosmos.app/uss/d44ba/Festive.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "d44ba892-7378-4fcd-a3f1-72de53675d24",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"920a3a5c-b344-42a8-bf23-021b0d315239", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "920a3a5c-b344-42a8-bf23-021b0d315239",
      "Contents": [
        {
          "Id": "f465c445-7ac7-4f6d-8e25-eeefb6b4672f",
          "Url": "https://cdn.bedrockcosmos.app/uss/6d6f4/BrodysGiveCampaignSkin.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.13.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "6d6f40da-6b0a-47f1-a82a-b23721c6140b",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"83722c79-a25d-4448-a853-3a4b0fdd99d5", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "83722c79-a25d-4448-a853-3a4b0fdd99d5",
      "Contents": [
        {
          "Id": "a4834ace-7f3f-456e-8305-709f0da41a60",
          "Url": "https://cdn.bedrockcosmos.app/uss/136fe/ClairesGiveCampaignSkin.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.13.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "136fe27d-4eb3-4564-8c9b-b4130ffbdd3c",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"e205acc9-2c5a-430f-8576-d87c5ba67db4", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "e205acc9-2c5a-430f-8576-d87c5ba67db4",
      "Contents": [
        {
          "Id": "7d369c64-cead-47fc-ab73-67db73032ad4",
          "Url": "https://cdn.bedrockcosmos.app/uss/a9396/JoslynsGiveCampaignSkin.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.13.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "a9396dff-9629-43fa-b7f7-4e885ab258fd",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"633422ca-cdc9-44c8-a25d-a43fb2d76bc7", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "633422ca-cdc9-44c8-a25d-a43fb2d76bc7",
      "Contents": [
        {
          "Id": "f25a86c8-0f0d-403a-ac8a-85ee1c1638f9",
          "Url": "https://cdn.bedrockcosmos.app/uss/a7657/LucysGiveCampaignSkin.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.13.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "a7657028-94cf-4d70-a421-42b64c18ad27",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"32c1ef67-3cb2-4094-bd0d-92eb55b5ad75", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "32c1ef67-3cb2-4094-bd0d-92eb55b5ad75",
      "Contents": [
        {
          "Id": "f066b5d3-bf21-4abe-9d5d-30541826a1c5",
          "Url": "https://xforgeassets002.xboxlive.com/pf-namespace-b63a0803d3653643/f066b5d3-bf21-4abe-9d5d-30541826a1c5/primary.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "resourcebinary"
        },
        {
          "Id": "0e5b6035-62cb-4fc5-a6a7-39a6ba7de9a9",
          "Url": "https://cdn.bedrockcosmos.app/uss/f2c9e/GreekMythology.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": true,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "f2c9ef8d-690b-41df-9682-d85225774b77",
            "version": "3.3.26"
          },
          {
            "type": "resourcepack",
            "uuid": "98330b0a-2c79-4d30-b9c8-136098340edc",
            "version": "1.0.79"
          },
          {
            "type": "worldtemplate",
            "uuid": "e8ad3b41-ddd3-4247-907b-090419cdb7ca",
            "version": "1.0.79"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b89ef5de-78ad-4a48-b8a5-f12065286e7d", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b89ef5de-78ad-4a48-b8a5-f12065286e7d",
      "Contents": [
        {
          "Id": "f68fb058-0dbf-406d-9025-fec84e9fd411",
          "Url": "https://cdn.bedrockcosmos.app/uss/39fa1/LegacySkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "39fa1d65-b3ca-4726-b9e0-f3d2a404e5a4",
            "version": "4.14.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"38fdf771-febb-4b6f-a162-c42850817d95", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "38fdf771-febb-4b6f-a162-c42850817d95",
      "Contents": [
        {
          "Id": "4f61ff6e-c280-4054-9f35-63be12dd55e5",
          "Url": "https://cdn.bedrockcosmos.app/uss/0232d/LEGORMinecraftTMDragonSlayer.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.4.1",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "0232dca2-f67e-40d7-9f32-3e836cce9e88",
            "version": "2.26.2026"
          }
        ],
        "skinPack": { "count": 1 }
      }
    }
  }
}
)COSMOS"},
  {"4d7590d6-8f7f-4f53-989a-2df76b6b015b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4d7590d6-8f7f-4f53-989a-2df76b6b015b",
      "Contents": [
        {
          "Id": "f27647ee-9530-4431-aa5b-7a0ddaf2f489",
          "Url": "https://xforgeassets002.xboxlive.com/pf-namespace-b63a0803d3653643/f27647ee-9530-4431-aa5b-7a0ddaf2f489/primary.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.10",
          "Tags": [],
          "Type": "resourcebinary"
        },
        {
          "Id": "75aea90f-7b0b-4539-a6d4-7fe023636b18",
          "Url": "https://cdn.bedrockcosmos.app/uss/0f2e0/LittleBigPlanet.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.10",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "price": 990,
        "purchasable": true,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "0f2e08ee-8ef2-4521-b03d-9f89c907c70e",
            "version": "3.3.26"
          },
          {
            "type": "resourcepack",
            "uuid": "abfcab1a-19fe-4564-b4ed-ffbda4a77690",
            "version": "1.0.75"
          },
          {
            "type": "worldtemplate",
            "uuid": "1dde574b-2b4d-48e6-951e-d135093bcdc9",
            "version": "1.0.75"
          }
        ],
        "skinPack": {
          "count": 38
        },
        "videoUrl": "https://www.youtube.com/watch?v=cJgl_0JVMpc",
        "hardwareMemoryTier": 0
      }
    }
  }
})COSMOS"},
  {"1fc32dd0-b399-4255-a4c7-e6e262a40ab6", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1fc32dd0-b399-4255-a4c7-e6e262a40ab6",
      "Contents": [
        {
          "Id": "7f4ba1a2-43dd-45b1-aa3f-0b3ca2ebd5c8",
          "Url": "https://cdn.bedrockcosmos.app/uss/7f4ba/MarioM.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "resourcebinary"
        },
        {
          "Id": "47ca6989-81db-404b-a9f1-f3391258b8a2",
          "Url": "https://cdn.bedrockcosmos.app/uss/47ca6/Mario.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "price": -1,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "47ca6989-81db-404b-a9f1-f3391258b8a2",
            "version": "1.1.6"
          },
          {
            "type": "resourcepack",
            "uuid": "7f4ba1a2-43dd-45b1-aa3f-0b3ca2ebd5c8",
            "version": "1.1.6"
          },
          {
            "type": "worldtemplate",
            "uuid": "c5e0d6e9-29b7-3b04-9408-032cc8a386c6",
            "version": "1.1.6"
          }
        ],
        "skinPack": {
          "count": 40
        },
        "videoUrl": "https://www.youtube.com/watch?v=sNcVYOPw6r0",
        "hardwareMemoryTier": 0
      }
    }
  }
}
)COSMOS"},
  {"2766095f-b2c0-4237-911f-e18a30fb0928", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "2766095f-b2c0-4237-911f-e18a30fb0928",
      "Contents": [
        {
          "Id": "a4f9a363-2f7c-4957-868c-2ce848a09688",
          "Url": "https://cdn.bedrockcosmos.app/uss/083c0/MarvelAvengersSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "083c0c90-cd38-46ad-a473-881f2a7cc069",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"1213b670-c82f-4e28-baf2-9f0d88954c9a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1213b670-c82f-4e28-baf2-9f0d88954c9a",
      "Contents": [
        {
          "Id": "d8209b3d-e7f5-412d-81df-0fc4bf97e896",
          "Url": "https://cdn.bedrockcosmos.app/uss/1d3e8/MarvelGuardiansoftheGalaxySkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "1d3e88a9-617c-45a8-83ba-b4abef5fda4e",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b79f57ee-ef4f-4e01-bc03-20f5aa21bc26", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b79f57ee-ef4f-4e01-bc03-20f5aa21bc26",
      "Contents": [
        {
          "Id": "d93bdfa0-ba2d-402d-9760-b87e8206dc5e",
          "Url": "https://cdn.bedrockcosmos.app/uss/8eba8/MarvelSpiderManSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "8eba8968-4ad4-446c-8717-36c38cae0edb",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"4ad937a2-bf33-4390-93e3-62198b58f9ff", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4ad937a2-bf33-4390-93e3-62198b58f9ff",
      "Contents": [
        {
          "Id": "5bd2a5b2-8189-442f-b20b-8393d989ac0a",
          "Url": "https://cdn.bedrockcosmos.app/uss/98500/MightyMorphinPowerRangers.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "98500e08-627e-4f46-a4d3-705a01f6f110",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"d1e7ecae-b422-40a2-8037-cf24571f901c", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "d1e7ecae-b422-40a2-8037-cf24571f901c",
      "Contents": [
        {
          "Id": "f73518e4-10b6-4eaa-a088-7b246483694e",
          "Url": "https://cdn.bedrockcosmos.app/uss/f7351/SkinPack1Classic.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "f73518e4-10b6-4eaa-a088-7b246483694e",
            "version": "3.20.2026"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"40fbf08d-390d-480c-9213-afb3886915eb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "40fbf08d-390d-480c-9213-afb3886915eb",
      "Contents": [
        {
          "Id": "d78aa7a2-9680-417c-97da-01c9cfbf0c4b",
          "Url": "https://cdn.bedrockcosmos.app/uss/d78aa/SkinPack2.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "d78aa7a2-9680-417c-97da-01c9cfbf0c4b",
            "version": "3.20.2026"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"586448fd-d6ce-4bdf-9f1b-8e3f65b6bb95", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "d1e7ecae-b422-40a2-8037-cf24571f901c",
      "Contents": [
        {
          "Id": "f73518e4-10b6-4eaa-a088-7b246483694e",
          "Url": "https://cdn.bedrockcosmos.app/uss/d53c5/SkinPack2Classic.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "d53c598e-3ea8-48d5-80e2-3ae9fc08e527",
            "version": "3.20.2026"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"36b8bc1a-10a1-4405-adc1-c93086dcb317", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "36b8bc1a-10a1-4405-adc1-c93086dcb317",
      "Contents": [
        {
          "Id": "640f444e-0d59-4d9a-9502-d64658a9b51b",
          "Url": "https://cdn.bedrockcosmos.app/uss/640f4/SkinPack3.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "640f444e-0d59-4d9a-9502-d64658a9b51b",
            "version": "3.20.2026"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"297ef7fb-debf-40a5-aea7-4e7acf141c59", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "297ef7fb-debf-40a5-aea7-4e7acf141c59",
      "Contents": [
        {
          "Id": "5371bde5-04bb-4195-8305-67dd24194f7b",
          "Url": "https://cdn.bedrockcosmos.app/uss/5371b/SkinPack3Classic.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "5371bde5-04bb-4195-8305-67dd24194f7b",
            "version": "3.20.2026"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"2f60a7a0-8010-49b1-8b57-851ac41f34cf", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "2f60a7a0-8010-49b1-8b57-851ac41f34cf",
      "Contents": [
        {
          "Id": "55fa75f0-1635-485f-9586-1bdd0cb6a255",
          "Url": "https://cdn.bedrockcosmos.app/uss/55fa7/SkinPack4.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "55fa75f0-1635-485f-9586-1bdd0cb6a255",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"80c85890-dad7-4d3a-b2ef-60071327b7cf", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "80c85890-dad7-4d3a-b2ef-60071327b7cf",
      "Contents": [
        {
          "Id": "cc59b688-7cfb-4fa0-a76e-84aa55b92cae",
          "Url": "https://cdn.bedrockcosmos.app/uss/cc59b/SkinPack5.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "cc59b688-7cfb-4fa0-a76e-84aa55b92cae",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"4c61b1f5-2bbc-492f-8a2a-1f3b813c4113", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "4c61b1f5-2bbc-492f-8a2a-1f3b813c4113",
      "Contents": [
        {
          "Id": "0037a29f-876e-4709-8bb8-a388738e6f51",
          "Url": "https://cdn.bedrockcosmos.app/uss/0037a/SkinPack6.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "originalCreatorId": "2535448579972708",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "0037a29f-876e-4709-8bb8-a388738e6f51",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"f60ed293-2f4c-46e5-92b3-922a95df2dd6", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f60ed293-2f4c-46e5-92b3-922a95df2dd6",
      "Contents": [
        {
          "Id": "014f4b10-a47c-4aac-951c-8e01bd8e6a88",
          "Url": "https://cdn.bedrockcosmos.app/uss/93b45/StrangerThingsSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.3",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "93b450c2-910f-4915-894d-444dde7a3306",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"39ddc16e-e398-4c71-b562-75b2ac5b1319", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "39ddc16e-e398-4c71-b562-75b2ac5b1319",
      "Contents": [
        {
          "Id": "b01ca240-dab6-47b3-995b-5d2e2562fab5",
          "Url": "https://cdn.bedrockcosmos.app/uss/4f4a0/TheSimpsonsSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Minecraft",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "4f4a0dfa-6e3a-4a2b-bad1-eb84b1b76ee9",
            "version": "3.11.26"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b1026ea3-1c85-492d-aa01-21a1d51829fe", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b1026ea3-1c85-492d-aa01-21a1d51829fe",
      "Contents": [
        {
          "Id": "4c7836bf-ea15-46ec-9868-33fe9b455631",
          "Url": "https://cdn.bedrock-cosmos.app/uss/4c783/AlleisSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Alleis Elis",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "4c7836bf-ea15-46ec-9868-33fe9b455631",
            "version": "1.3.8"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"8713ccc6-b61f-4d3a-9719-02b4c670967d", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "8713ccc6-b61f-4d3a-9719-02b4c670967d",
      "Contents": [
        {
          "Id": "262c9840-c332-48d2-b62f-6c19ad0f7aa6",
          "Url": "https://cdn.bedrock-cosmos.app/uss/262c9/AlleisSlopPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Alleis Elis",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "262c9840-c332-48d2-b62f-6c19ad0f7aa6",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"ee2e819d-323d-4245-b2a5-b679ae961402", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ee2e819d-323d-4245-b2a5-b679ae961402",
      "Contents": [
        {
          "Id": "60d6c1f6-ba2c-4086-ae92-bb46f90f3b74",
          "Url": "https://cdn.bedrock-cosmos.app/uss/60d6c/VariousGirls.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Alleis Elis",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "60d6c1f6-ba2c-4086-ae92-bb46f90f3b74",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"1dafe8e5-aacc-4518-98ed-f6ce66bfba80", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "1dafe8e5-aacc-4518-98ed-f6ce66bfba80",
      "Contents": [
        {
          "Id": "342df268-636d-4f2b-a971-8350eb4fc440",
          "Url": "https://cdn.bedrock-cosmos.app/uss/342df/6thBirthdaySkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "342df268-636d-4f2b-a971-8350eb4fc440",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"aa0b65fd-8cfe-43dc-a7c0-c306757fe1a3", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "aa0b65fd-8cfe-43dc-a7c0-c306757fe1a3",
      "Contents": [
        {
          "Id": "aa5e26c6-9032-487e-9ed5-a6b99d68ba98",
          "Url": "https://cdn.bedrock-cosmos.app/uss/aa5e2/Deadmau5SkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "aa5e26c6-9032-487e-9ed5-a6b99d68ba98",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"aa8a18de-f2b0-40be-bc70-c4cd9dd6ae62", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "aa8a18de-f2b0-40be-bc70-c4cd9dd6ae62",
      "Contents": [
        {
          "Id": "248868b1-e260-4434-b56b-b41a48f57b91",
          "Url": "https://cdn.bedrock-cosmos.app/uss/24886/BionicBenSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "248868b1-e260-4434-b56b-b41a48f57b91",
            "version": "1.0.2"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"0ce8d2eb-d178-4ae9-8060-00fd9714c93b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "0ce8d2eb-d178-4ae9-8060-00fd9714c93b",
      "Contents": [
        {
          "Id": "a8822913-5c64-4a73-bf8b-b1713a4434b2",
          "Url": "https://cdn.bedrock-cosmos.app/uss/a8822/ProjectStarSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "BionicBen",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "a8822913-5c64-4a73-bf8b-b1713a4434b2",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"22688cde-3822-4bd8-9638-625713ba4dfd", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "22688cde-3822-4bd8-9638-625713ba4dfd",
      "Contents": [
        {
          "Id": "51bb5ca4-77b9-4e9d-8c90-992b61d94c0d",
          "Url": "https://cdn.bedrock-cosmos.app/uss/51bb5/EMC1.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Exports",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "51bb5ca4-77b9-4e9d-8c90-992b61d94c0d",
            "version": "1.0.0"
          }
        ],
        "videoUrl": "https://www.youtube.com/watch?v=jDdXPw8ehZY"
      }
    }
  }
}
)COSMOS"},
  {"a045e0ba-b58e-44d5-b463-e8968f28ae99", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a045e0ba-b58e-44d5-b463-e8968f28ae99",
      "Contents": [
        {
          "Id": "6d111aff-3c61-4e8c-a0b3-5da38332430c",
          "Url": "https://cdn.bedrock-cosmos.app/uss/6d111/EMC2.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Exports",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "6d111aff-3c61-4e8c-a0b3-5da38332430c",
            "version": "1.0.0"
          }
        ],
        "videoUrl": "https://www.youtube.com/watch?v=cgrhwL2inRw"
      }
    }
  }
}
)COSMOS"},
  {"2d43de6c-6846-4cdc-a43b-55f8627b7b01", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "2d43de6c-6846-4cdc-a43b-55f8627b7b01",
      "Contents": [
        {
          "Id": "0484ef22-b675-4468-b58d-699890b377b1",
          "Url": "https://cdn.bedrock-cosmos.app/uss/0484e/EMC3.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Exports",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "0484ef22-b675-4468-b58d-699890b377b1",
            "version": "1.0.0"
          }
        ],
        "videoUrl": "https://www.youtube.com/watch?v=ZmeyYheOC_k"
      }
    }
  }
}
)COSMOS"},
  {"d1c19132-0b7d-453d-b39b-5b06a5fb30f9", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "d1c19132-0b7d-453d-b39b-5b06a5fb30f9",
      "Contents": [
        {
          "Id": "2291990c-6b7a-42d8-ad13-c1b490b9e1f6",
          "Url": "https://cdn.bedrock-cosmos.app/uss/22919/EMC4.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Exports",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "2291990c-6b7a-42d8-ad13-c1b490b9e1f6",
            "version": "1.0.0"
          }
        ],
        "videoUrl": "https://www.youtube.com/watch?v=eL5Sg009y0c"
      }
    }
  }
}
)COSMOS"},
  {"a2a191a7-ad0d-4802-a990-975538c7489f", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "a2a191a7-ad0d-4802-a990-975538c7489f",
      "Contents": [
        {
          "Id": "1ea3fef7-eea7-4413-ac90-13e053ea4cea",
          "Url": "https://cdn.bedrock-cosmos.app/uss/1ea3f/EMC5.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Exports",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "1ea3fef7-eea7-4413-ac90-13e053ea4cea",
            "version": "1.0.0"
          }
        ],
        "videoUrl": "https://www.youtube.com/watch?v=5QzSKjJZYdY"
      }
    }
  }
}
)COSMOS"},
  {"7a92c69c-d1c8-4c00-b3a2-cd9c7e650148", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "7a92c69c-d1c8-4c00-b3a2-cd9c7e650148",
      "Contents": [
        {
          "Id": "ff1018de-be33-4ce9-a131-f94d0c2abb2e",
          "Url": "https://cdn.bedrock-cosmos.app/uss/ff101/EMC6.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Exports",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "ff1018de-be33-4ce9-a131-f94d0c2abb2e",
            "version": "1.0.0"
          }
        ],
        "videoUrl": "https://www.youtube.com/watch?v=f7fROv6DC9Q"
      }
    }
  }
}
)COSMOS"},
  {"dfc5ace1-fd1c-414c-8b1f-ec34e1bf7ba8", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "dfc5ace1-fd1c-414c-8b1f-ec34e1bf7ba8",
      "Contents": [
        {
          "Id": "b6733994-4772-41a1-9dfb-c445d24048c7",
          "Url": "https://cdn.bedrock-cosmos.app/uss/b6733/EMC7.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Exports",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "b6733994-4772-41a1-9dfb-c445d24048c7",
            "version": "1.0.0"
          }
        ],
        "videoUrl": "https://www.youtube.com/watch?v=HAq6dFby9vg"
      }
    }
  }
}
)COSMOS"},
  {"0b18e5e0-9b6f-452b-9e89-1d3a9f6f95be", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "0b18e5e0-9b6f-452b-9e89-1d3a9f6f95be",
      "Contents": [
        {
          "Id": "cd99e175-5498-4edf-8bb2-ab29cbfc00b9",
          "Url": "https://cdn.bedrock-cosmos.app/uss/cd99e/EMC8.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Exports",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "cd99e175-5498-4edf-8bb2-ab29cbfc00b9",
            "version": "1.0.0"
          }
        ],
        "videoUrl": "https://www.youtube.com/watch?v=mb1r-t64Fjw"
      }
    }
  }
}
)COSMOS"},
  {"fc4de45c-9d1c-4909-87be-6e3366a857ba", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "fc4de45c-9d1c-4909-87be-6e3366a857ba",
      "Contents": [
        {
          "Id": "5fe7c32b-fd56-44ba-b2a1-a549cccc17fd",
          "Url": "https://cdn.bedrock-cosmos.app/uss/5fe7c/EMC9.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Exports",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "5fe7c32b-fd56-44ba-b2a1-a549cccc17fd",
            "version": "1.0.0"
          }
        ],
        "videoUrl": "https://www.youtube.com/watch?v=j2Djo_VPous"
      }
    }
  }
})COSMOS"},
  {"43132398-078d-4a7f-b6b9-5ae469f1e727", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "43132398-078d-4a7f-b6b9-5ae469f1e727",
      "Contents": [
        {
          "Id": "8d4eb2f0-d468-4e64-a485-06e948caed48",
          "Url": "https://cdn.bedrock-cosmos.app/uss/8d4eb/CasualKnightsSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Mono",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "8d4eb2f0-d468-4e64-a485-06e948caed48",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"74694ab4-178f-4c60-a0dd-96ec4627390e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "74694ab4-178f-4c60-a0dd-96ec4627390e",
      "Contents": [
        {
          "Id": "d3fabdf1-3e91-4903-ac95-db2b2d752f8e",
          "Url": "https://cdn.bedrock-cosmos.app/uss/d3fab/SRGsVoxelSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "SRG64",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "d3fabdf1-3e91-4903-ac95-db2b2d752f8e",
            "version": "1.3.1"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"b20dc966-1071-4845-a7a0-b0d2acb253ce", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b20dc966-1071-4845-a7a0-b0d2acb253ce",
      "Contents": [
        {
          "Id": "f978adc0-729f-406d-bc0c-08cfbf5f9c30",
          "Url": "https://cdn.bedrock-cosmos.app/uss/f978a/LEGOMinecraftSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "YEH",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "f978adc0-729f-406d-bc0c-08cfbf5f9c30",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
  {"17c404b3-3979-49a3-93cb-3f53e2e33eb6", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "17c404b3-3979-49a3-93cb-3f53e2e33eb6",
      "Contents": [
        {
          "Id": "2f8d9fb8-c3c9-47d5-8460-e15da1a528fb",
          "Url": "https://cdn.bedrock-cosmos.app/uss/2f8d9/YEH4D.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "YEH",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "2f8d9fb8-c3c9-47d5-8460-e15da1a528fb",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"86e6a53f-6ae6-4109-935a-72f877194c02", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "86e6a53f-6ae6-4109-935a-72f877194c02",
      "Contents": [
        {
          "Id": "73d78fb2-9cd7-43bb-8f60-899f654761e1",
          "Url": "https://cdn.bedrock-cosmos.app/uss/73d78/YEH5D.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "YEH",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "73d78fb2-9cd7-43bb-8f60-899f654761e1",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"b96ad5fb-f58c-4a92-bbbc-44bb9244e732", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "b96ad5fb-f58c-4a92-bbbc-44bb9244e732",
      "Contents": [
        {
          "Id": "ec24d5bb-c72d-4ca7-a684-4de5be42e126",
          "Url": "https://cdn.bedrock-cosmos.app/uss/ec24d/BlackHole.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "ZeroMISTER JA",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "ec24d5bb-c72d-4ca7-a684-4de5be42e126",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"dedd7dce-a317-4786-930f-9c2357d25d82", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "dedd7dce-a317-4786-930f-9c2357d25d82",
      "Contents": [
        {
          "Id": "a7952402-135e-4f5d-abea-5b738904e2c4",
          "Url": "https://cdn.bedrock-cosmos.app/uss/a7952/DetectiveConanSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "ZeroMISTER JA",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "a7952402-135e-4f5d-abea-5b738904e2c4",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"ae90416f-1942-4c2b-a675-8d947fc53cf1", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "ae90416f-1942-4c2b-a675-8d947fc53cf1",
      "Contents": [
        {
          "Id": "7489dfb0-f606-41fc-9bfb-c7ef396d8358",
          "Url": "https://cdn.bedrock-cosmos.app/uss/7489d/Doraemon.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "ZeroMISTER JA",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "7489dfb0-f606-41fc-9bfb-c7ef396d8358",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"7197503c-817f-4c5d-b570-67b2758d707b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "7197503c-817f-4c5d-b570-67b2758d707b",
      "Contents": [
        {
          "Id": "b53d0382-a1e0-4707-9dd2-92ccae001033",
          "Url": "https://cdn.bedrock-cosmos.app/uss/b53d0/HotelTransylvaniaSkinPack.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "ZeroMISTER JA",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "b53d0382-a1e0-4707-9dd2-92ccae001033",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"f6303374-6ab5-4079-baa0-6200189aa6a2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "f6303374-6ab5-4079-baa0-6200189aa6a2",
      "Contents": [
        {
          "Id": "863a125c-4fd6-413d-8f82-a3ab232e69ec",
          "Url": "https://cdn.bedrock-cosmos.app/uss/863a1/NeonGenesisEvangelion.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "skinbinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "ZeroMISTER JA",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "skinpack",
            "uuid": "863a125c-4fd6-413d-8f82-a3ab232e69ec",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
}
)COSMOS"},
  {"be094038-1e9b-42ca-b849-7c6345f2be50", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Item": {
      "Id": "be094038-1e9b-42ca-b849-7c6345f2be50",
      "Contents": [
        {
          "Id": "7b5cac88-d90d-483f-8e4e-e4e1aaa47787",
          "Url": "https://cdn.bedrock-cosmos.app/uss/7b5ca/CapePhysics.zip",
          "MaxClientVersion": "65535.65535.65535",
          "MinClientVersion": "1.2.0",
          "Tags": [],
          "Type": "resourcebinary"
        }
      ],
      "DisplayProperties": {
        "creatorName": "Xatalyst",
        "purchasable": false,
        "packIdentity": [
          {
            "type": "resources",
            "uuid": "7b5cac88-d90d-483f-8e4e-e4e1aaa47787",
            "version": "1.0.0"
          }
        ]
      }
    }
  }
})COSMOS"},
};
}
