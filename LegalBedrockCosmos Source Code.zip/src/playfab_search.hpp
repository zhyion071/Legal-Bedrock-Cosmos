#pragma once
#include <string_view>
#include <unordered_map>
namespace cosmos {
static const std::unordered_map<std::string_view,std::string_view> kPlayfabSearch = {
  {"e823767b-7337-49da-aaef-de616d2c2c3a", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "02b54955-9b4d-40cb-9b73-360d23cf1b9e",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "ea5746d0-2434-4a52-9026-7de28579f76b"
          }
        ],
        "Title": {
          "en-US": "2nd Birthday Skin Pack",
          "NEUTRAL": "2nd Birthday Skin Pack",
          "neutral": "2nd Birthday Skin Pack"
        },
        "Description": {
          "en-US": "Minecraft is growing up, time to celebrate together our 2nd Birthday!",
          "NEUTRAL": "Minecraft is growing up, time to celebrate together our 2nd Birthday!",
          "neutral": "Minecraft is growing up, time to celebrate together our 2nd Birthday!"
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Party Based RPG", "Funny"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Party Based RPG", "Funny"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Party Based RPG", "Funny"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "ios.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "nx.store",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla"
        ],
        "Tags": [
          "02b54955-9b4d-40cb-9b73-360d23cf1b9e",
          "e823767b-7337-49da-aaef-de616d2c2c3a",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.survival",
          "tag.skin",
          "tag.party_based_rpg",
          "tag.funny",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:55:11.162Z",
        "LastModifiedDate": "2023-08-09T16:10:37.521Z",
        "Contents": [],
        "Images": [
          {
            "Id": "905ed25d-92af-4c1b-8059-a22f3553b26b",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/pf-title-b63a0803d3653643-20ca2/905ed25d-92af-4c1b-8059-a22f3553b26b/2ndBirthday_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "a8861471-10ae-4039-884d-b150a4980ff2",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.7,
          "TotalCount": 26544,
          "Count5Star": 23043,
          "Count4Star": 1464,
          "Count3Star": 804,
          "Count2Star": 318,
          "Count1Star": 915
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "ea5746d0-2434-4a52-9026-7de28579f76b",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "e823767b-7337-49da-aaef-de616d2c2c3a",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 25
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "lastUpdated": "1.14.30"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"d532b9b3-eddc-4f98-96fc-5fe5e227c426", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "770196c2-718f-43ef-94d6-8e53a7b5b0af",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "4af11277-e068-4e74-b0d9-ad3460397a5c"
          }
        ],
        "Title": {
          "en-US": "2nd Birthday Skin Pack - 2015",
          "NEUTRAL": "2nd Birthday Skin Pack - 2015",
          "neutral": "2nd Birthday Skin Pack - 2015"
        },
        "Description": {
          "en-US": "Minecraft is growing up, time to celebrate together our 2nd Birthday!\r\nOnly available for Minecraft on PlayStation 4 (2019).",
          "NEUTRAL": "Minecraft is growing up, time to celebrate together our 2nd Birthday!\r\nOnly available for Minecraft on PlayStation 4 (2019).",
          "neutral": "Minecraft is growing up, time to celebrate together our 2nd Birthday!\r\nOnly available for Minecraft on PlayStation 4 (2019)."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Holiday"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Holiday"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Holiday"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["b.store", "title.bedrockvanilla"],
        "Tags": [
          "770196c2-718f-43ef-94d6-8e53a7b5b0af",
          "d532b9b3-eddc-4f98-96fc-5fe5e227c426",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.survival",
          "tag.skin",
          "tag.holiday",
          "1P"
        ],
        "CreationDate": "2019-12-10T17:47:04.166Z",
        "LastModifiedDate": "2024-10-16T01:32:02.324Z",
        "Contents": [],
        "Images": [
          {
            "Id": "2cb9d7f6-6b3d-445e-a323-d28522959a95",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/pf-title-b63a0803d3653643-20ca2/2cb9d7f6-6b3d-445e-a323-d28522959a95/Skinpack_2ndBirthday_Sony_thumbnail_800x450.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "d9caea4e-2149-4249-925c-9ab216046eca",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.6,
          "TotalCount": 10503,
          "Count5Star": 8759,
          "Count4Star": 665,
          "Count3Star": 351,
          "Count2Star": 120,
          "Count1Star": 608
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "4af11277-e068-4e74-b0d9-ad3460397a5c",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "d532b9b3-eddc-4f98-96fc-5fe5e227c426",
              "version": "3.1.26"
            }
          ],
          "skinPack": {
            "count": 24
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "lastUpdated": "1.14.30"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"e4d586b5-ab6f-4fd5-82d5-6158a755e012", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "603d6be1-7745-4ad8-8af3-908ad017500f",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "3dc35289-664e-4793-9924-bd8617e3fa93"
          }
        ],
        "Title": {
          "en-US": "3rd Birthday Skin Pack",
          "NEUTRAL": "3rd Birthday Skin Pack",
          "neutral": "3rd Birthday Skin Pack"
        },
        "Description": {
          "en-US": "Celebrate Minecraft’s 3rd Birthday on Xbox with the original Minecraft developers! Find their personal skins in this free celebration pack.",
          "NEUTRAL": "Celebrate Minecraft’s 3rd Birthday on Xbox with the original Minecraft developers! Find their personal skins in this free celebration pack.",
          "neutral": "Celebrate Minecraft’s 3rd Birthday on Xbox with the original Minecraft developers! Find their personal skins in this free celebration pack."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Holiday"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Holiday"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Holiday"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "603d6be1-7745-4ad8-8af3-908ad017500f",
          "e4d586b5-ab6f-4fd5-82d5-6158a755e012",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.survival",
          "tag.skin",
          "tag.holiday",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:55:21.538Z",
        "LastModifiedDate": "2023-08-09T23:56:39.261Z",
        "Contents": [],
        "Images": [
          {
            "Id": "a1389533-0d61-486d-9f7e-6f7b92d00c80",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/pf-title-b63a0803d3653643-20ca2/a1389533-0d61-486d-9f7e-6f7b92d00c80/3rdBirthday_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "dc9781cd-dd2a-468c-b217-94308339f2b6",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.6,
          "TotalCount": 3511,
          "Count5Star": 2893,
          "Count4Star": 240,
          "Count3Star": 173,
          "Count2Star": 50,
          "Count1Star": 155
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "3dc35289-664e-4793-9924-bd8617e3fa93",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "e4d586b5-ab6f-4fd5-82d5-6158a755e012",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 19
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "lastUpdated": "1.14.30"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"659b5fdb-3260-47ff-9aeb-41818d74acdd", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "a2a7ad5c-f55e-44ff-9f70-a5ae1db821b4",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "05103b4d-d4fc-4c80-a37f-332ee6ddbb7e"
          }
        ],
        "Title": {
          "en-US": "4th Birthday Skin Pack",
          "NEUTRAL": "4th Birthday Skin Pack",
          "neutral": "4th Birthday Skin Pack"
        },
        "Description": {
          "en-US": "Dress up for the party with this new, free skin pack and celebrate together the 4th Minecraft birthday!",
          "NEUTRAL": "Dress up for the party with this new, free skin pack and celebrate together the 4th Minecraft birthday!",
          "neutral": "Dress up for the party with this new, free skin pack and celebrate together the 4th Minecraft birthday!"
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Holiday"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Holiday"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Holiday"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "a2a7ad5c-f55e-44ff-9f70-a5ae1db821b4",
          "659b5fdb-3260-47ff-9aeb-41818d74acdd",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.survival",
          "tag.skin",
          "tag.holiday",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:55:32.774Z",
        "LastModifiedDate": "2023-08-10T05:16:19.666Z",
        "Contents": [],
        "Images": [
          {
            "Id": "3e7257e1-c31c-477b-88c3-af3d75840a0a",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/3e7257e1-c31c-477b-88c3-af3d75840a0a/4thBirthday_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "01ab9849-4cdd-4ca5-8ff6-662d04f525ad",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.5,
          "TotalCount": 6346,
          "Count5Star": 5047,
          "Count4Star": 510,
          "Count3Star": 314,
          "Count2Star": 112,
          "Count1Star": 363
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "05103b4d-d4fc-4c80-a37f-332ee6ddbb7e",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "659b5fdb-3260-47ff-9aeb-41818d74acdd",
              "version": "3.11.26"
            }
          ],
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "lastUpdated": "1.14.3"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"433cbba0-1c00-48e8-94ef-59cfc38da4ca", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "cc1e1b86-1863-4c1c-9103-b82b2b70a74b",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "d350f5b8-931b-407e-b223-9ac5391ff0f5"
          }
        ],
        "Title": {
          "en-US": "5th Birthday Skin Pack",
          "NEUTRAL": "5th Birthday Skin Pack",
          "neutral": "5th Birthday Skin Pack"
        },
        "Description": {
          "en-US": "Join the celebrations for the 5th birthday of Minecraft with this new, free skin pack featuring the one and only 4J Studios development team! Party on!",
          "NEUTRAL": "Join the celebrations for the 5th birthday of Minecraft with this new, free skin pack featuring the one and only 4J Studios development team! Party on!",
          "neutral": "Join the celebrations for the 5th birthday of Minecraft with this new, free skin pack featuring the one and only 4J Studios development team! Party on!"
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Holiday"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Holiday"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Holiday"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "cc1e1b86-1863-4c1c-9103-b82b2b70a74b",
          "433cbba0-1c00-48e8-94ef-59cfc38da4ca",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.survival",
          "tag.skin",
          "tag.holiday",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:55:43.448Z",
        "LastModifiedDate": "2023-08-10T08:52:29.006Z",
        "Contents": [],
        "Images": [
          {
            "Id": "3b4bd08e-e337-46e9-9243-5679d2086a3d",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/3b4bd08e-e337-46e9-9243-5679d2086a3d/5thBirthday_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "c0ae65b8-5a9a-4620-8682-2b8116029da9",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.4,
          "TotalCount": 3045,
          "Count5Star": 2301,
          "Count4Star": 268,
          "Count3Star": 196,
          "Count2Star": 87,
          "Count1Star": 193
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "d350f5b8-931b-407e-b223-9ac5391ff0f5",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "433cbba0-1c00-48e8-94ef-59cfc38da4ca",
              "version": "3.11.26"
            }
          ],
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "lastUpdated": "1.14.30"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"1f581bc6-11c0-4a77-b0fa-91b7ca2636a0", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "57dfb793-29cb-4faf-acd9-bc0200ad108c",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "01f80125-52fd-4e3d-ba8f-f26745c86557"
          }
        ],
        "Title": {
          "en-US": "Biome Settlers Skin Pack 1",
          "NEUTRAL": "Biome Settlers Skin Pack 1",
          "neutral": "Biome Settlers Skin Pack 1"
        },
        "Description": {
          "en-US": "Dress as a native of the Tundra, Forest, or Desert!\r\n\r\nBedrock Cosmos Note: Due to this skin pack being recently delisted, these skins are not currently available for use if you have not previously purchased/redeemed them on your Minecraft account.",
          "NEUTRAL": "Dress as a native of the Tundra, Forest, or Desert!\r\n\r\nBedrock Cosmos Note: Due to this skin pack being recently delisted, these skins are not currently available for use if you have not previously purchased/redeemed them on your Minecraft account.",
          "neutral": "Dress as a native of the Tundra, Forest, or Desert!\r\n\r\nBedrock Cosmos Note: Due to this skin pack being recently delisted, these skins are not currently available for use if you have not previously purchased/redeemed them on your Minecraft account."
        },
        "Keywords": {
          "en-US": {
            "Values": []
          },
          "NEUTRAL": {
            "Values": []
          },
          "neutral": {
            "Values": []
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "ios.store",
          "oculus.store.rift",
          "oculus.store.gearvr",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "nx.store",
          "b.store",
          "title.bedrockvanilla"
        ],
        "Tags": [
          "57dfb793-29cb-4faf-acd9-bc0200ad108c",
          "1f581bc6-11c0-4a77-b0fa-91b7ca2636a0",
          "hidden_offer",
          "1P",
          "skinpack",
          "has_skinpack"
        ],
        "CreationDate": "2018-07-31T20:56:26.372Z",
        "LastModifiedDate": "2026-01-23T21:16:23.984Z",
        "Contents": [],
        "Images": [
          {
            "Id": "6efcb705-d8b3-4c5d-bf09-72bac525c92c",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/6efcb705-d8b3-4c5d-bf09-72bac525c92c/BiomeSettlers1_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "2f18e07b-55a0-47d5-8459-ebaa632d18e7",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.4,
          "TotalCount": 278187,
          "Count5Star": 211870,
          "Count4Star": 23683,
          "Count3Star": 14804,
          "Count2Star": 6118,
          "Count1Star": 21712
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "01f80125-52fd-4e3d-ba8f-f26745c86557",
          "originalCreatorId": "2535448579972708",
          "price": 490,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "1f581bc6-11c0-4a77-b0fa-91b7ca2636a0",
              "version": "1.0.4"
            }
          ],
          "skinPack": {
            "count": 24
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "hardwareMemoryTier": 0
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"d55a3dda-b482-4ff6-bf30-3d2ba9324c19", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "420ce26e-f6a7-4420-8067-8cf2965a39d6",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "4bafcddc-1a84-4de4-a165-528edff7cd64"
          }
        ],
        "Title": {
          "en-US": "Strangers - Biome Settlers 3",
          "NEUTRAL": "Strangers - Biome Settlers 3",
          "neutral": "Strangers - Biome Settlers 3"
        },
        "Description": {
          "en-US": "Get this pack and make your home in distant lands or ocean depths!\r\n\r\nBedrock Cosmos Note: Due to this skin pack being recently delisted, these skins are not currently available for use if you have not previously purchased/redeemed them on your Minecraft account.",
          "NEUTRAL": "Get this pack and make your home in distant lands or ocean depths!\r\n\r\nBedrock Cosmos Note: Due to this skin pack being recently delisted, these skins are not currently available for use if you have not previously purchased/redeemed them on your Minecraft account.",
          "neutral": "Get this pack and make your home in distant lands or ocean depths!\r\n\r\nBedrock Cosmos Note: Due to this skin pack being recently delisted, these skins are not currently available for use if you have not previously purchased/redeemed them on your Minecraft account."
        },
        "Keywords": {
          "en-US": {
            "Values": []
          },
          "NEUTRAL": {
            "Values": []
          },
          "neutral": {
            "Values": []
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "ios.store",
          "oculus.store.rift",
          "oculus.store.gearvr",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "nx.store",
          "b.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "420ce26e-f6a7-4420-8067-8cf2965a39d6",
          "d55a3dda-b482-4ff6-bf30-3d2ba9324c19",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "video_trailer",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:56:44.594Z",
        "LastModifiedDate": "2025-04-25T17:48:21.221Z",
        "Contents": [],
        "Images": [
          {
            "Id": "033b503b-2b3b-409a-a016-1754894ab969",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/033b503b-2b3b-409a-a016-1754894ab969/StrangersBiomeSettlers3_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "f6d996e5-6b1c-4041-bfa8-a0292148f6f1",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.6,
          "TotalCount": 5385,
          "Count5Star": 4456,
          "Count4Star": 410,
          "Count3Star": 164,
          "Count2Star": 58,
          "Count1Star": 297
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "4bafcddc-1a84-4de4-a165-528edff7cd64",
          "originalCreatorId": "2535448579972708",
          "price": 310,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "d55a3dda-b482-4ff6-bf30-3d2ba9324c19",
              "version": "1.0.1"
            }
          ],
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "videoUrl": "https://www.youtube.com/watch?v=FdhcVjLud-c"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"6d6f40da-6b0a-47f1-a82a-b23721c6140b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "920a3a5c-b344-42a8-bf23-021b0d315239",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "0d80adc8-77a2-4190-a246-09fd9fdff6a6"
          }
        ],
        "Title": {
          "en-US": "Brody's Give Campaign Skin",
          "NEUTRAL": "Brody's Give Campaign Skin",
          "neutral": "Brody's Give Campaign Skin"
        },
        "Description": {
          "en-US": "A special skin pack for winning the Give Campaign auction.",
          "NEUTRAL": "A special skin pack for winning the Give Campaign auction.",
          "neutral": "A special skin pack for winning the Give Campaign auction."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Roleplaying Game", "Cool", "Narration", "Skin"]
          },
          "NEUTRAL": {
            "Values": ["Roleplaying Game", "Cool", "Narration", "Skin"]
          },
          "neutral": {
            "Values": ["Roleplaying Game", "Cool", "Narration", "Skin"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "920a3a5c-b344-42a8-bf23-021b0d315239",
          "6d6f40da-6b0a-47f1-a82a-b23721c6140b",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.roleplaying_game",
          "tag.cool",
          "tag.narration",
          "tag.skin",
          "1P"
        ],
        "CreationDate": "2020-10-06T23:00:37.062Z",
        "LastModifiedDate": "2023-08-10T03:49:05.55Z",
        "Contents": [],
        "Images": [
          {
            "Id": "a89a0ac1-2b70-43ad-8a37-3fc4a27515e8",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/pf-title-b63a0803d3653643-20ca2/a89a0ac1-2b70-43ad-8a37-3fc4a27515e8/thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "517cd5c4-0c04-4f02-9a25-38a0fe1f725d",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.5,
          "TotalCount": 78,
          "Count5Star": 64,
          "Count4Star": 5,
          "Count3Star": 1,
          "Count2Star": 2,
          "Count1Star": 6
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "0d80adc8-77a2-4190-a246-09fd9fdff6a6",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "6d6f40da-6b0a-47f1-a82a-b23721c6140b",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 1
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"136fe27d-4eb3-4564-8c9b-b4130ffbdd3c", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "83722c79-a25d-4448-a853-3a4b0fdd99d5",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "ef411444-2070-4d73-9a51-56267b616a74"
          }
        ],
        "Title": {
          "en-US": "Claire's Give Campaign Skin",
          "NEUTRAL": "Claire's Give Campaign Skin",
          "neutral": "Claire's Give Campaign Skin"
        },
        "Description": {
          "en-US": "A special skin pack for winning the Give Campaign auction.",
          "NEUTRAL": "A special skin pack for winning the Give Campaign auction.",
          "neutral": "A special skin pack for winning the Give Campaign auction."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Roleplaying Game", "Cool", "Narration", "Skin"]
          },
          "NEUTRAL": {
            "Values": ["Roleplaying Game", "Cool", "Narration", "Skin"]
          },
          "neutral": {
            "Values": ["Roleplaying Game", "Cool", "Narration", "Skin"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "83722c79-a25d-4448-a853-3a4b0fdd99d5",
          "136fe27d-4eb3-4564-8c9b-b4130ffbdd3c",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.roleplaying_game",
          "tag.cool",
          "tag.narration",
          "tag.skin",
          "1P"
        ],
        "CreationDate": "2020-10-06T22:59:59.515Z",
        "LastModifiedDate": "2023-08-10T02:41:14.283Z",
        "Contents": [],
        "Images": [
          {
            "Id": "aec5c2da-a001-496f-a3fb-2fac3d2fcfc1",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/pf-title-b63a0803d3653643-20ca2/aec5c2da-a001-496f-a3fb-2fac3d2fcfc1/thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "08538afa-5454-4412-8b01-245f23f5df96",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.6,
          "TotalCount": 83,
          "Count5Star": 69,
          "Count4Star": 6,
          "Count3Star": 1,
          "Count2Star": 2,
          "Count1Star": 5
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "ef411444-2070-4d73-9a51-56267b616a74",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "136fe27d-4eb3-4564-8c9b-b4130ffbdd3c",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 1
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"6c37b8c1-ff20-4bf6-a20c-5045aa2d3f57", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "29ce2f54-be6e-4748-b63e-335d6fa8a9d0",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "125b33e4-e99f-4e94-8411-59f9bd107f78"
          }
        ],
        "Title": {
          "en-US": "Coral Crafters Skin Pack",
          "NEUTRAL": "Coral Crafters Skin Pack",
          "neutral": "Coral Crafters Skin Pack"
        },
        "Description": {
          "en-US": "A selection of sea-worthy skins to celebrate the Update Aquatic! Explore the oceans as a dolphin or turtle, or opt for a statue skin – covered in kelp or coral! Take a deep dive with the Ocean Explorer, Coral Diver and more! Net proceeds will go to support The Nature Conservancy’s efforts to protect and restore coral reefs, learn more at https://aka.ms/coralcrafters.",
          "NEUTRAL": "A selection of sea-worthy skins to celebrate the Update Aquatic! Explore the oceans as a dolphin or turtle, or opt for a statue skin – covered in kelp or coral! Take a deep dive with the Ocean Explorer, Coral Diver and more! Net proceeds will go to support The Nature Conservancy’s efforts to protect and restore coral reefs, learn more at https://aka.ms/coralcrafters.",
          "neutral": "A selection of sea-worthy skins to celebrate the Update Aquatic! Explore the oceans as a dolphin or turtle, or opt for a statue skin – covered in kelp or coral! Take a deep dive with the Ocean Explorer, Coral Diver and more! Net proceeds will go to support The Nature Conservancy’s efforts to protect and restore coral reefs, learn more at https://aka.ms/coralcrafters."
        },
        "Keywords": {
          "en-US": {
            "Values": []
          },
          "NEUTRAL": {
            "Values": []
          },
          "neutral": {
            "Values": []
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "ios.store",
          "oculus.store.rift",
          "oculus.store.gearvr",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "nx.store",
          "b.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "29ce2f54-be6e-4748-b63e-335d6fa8a9d0",
          "6c37b8c1-ff20-4bf6-a20c-5045aa2d3f57",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:57:14.336Z",
        "LastModifiedDate": "2024-10-14T23:46:19.389Z",
        "Contents": [],
        "Images": [
          {
            "Id": "6c3dc9f3-bf52-48f0-bd25-ff868e330867",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/6c3dc9f3-bf52-48f0-bd25-ff868e330867/CoralCrafters_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "d0fadb19-1279-4a2c-9cb4-33133e674656",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.6,
          "TotalCount": 3932,
          "Count5Star": 3264,
          "Count4Star": 287,
          "Count3Star": 118,
          "Count2Star": 52,
          "Count1Star": 211
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "125b33e4-e99f-4e94-8411-59f9bd107f78",
          "originalCreatorId": "2535448579972708",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "6c37b8c1-ff20-4bf6-a20c-5045aa2d3f57",
              "version": "3.11.26"
            }
          ],
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"e58fb8eb-0e70-4c89-9f60-e7a4a72f9061", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "60a2047b-fe99-4a1d-9ccf-79d6a9b63adb",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "79fe9dfe-a65b-4a47-b264-cc0aba1d7b3e"
          }
        ],
        "Title": {
          "NEUTRAL": "Doctor Who Skins Volume I",
          "neutral": "Doctor Who Skins Volume I"
        },
        "Description": {
          "NEUTRAL": "Launch yourself on an epic adventure in space and time with the Minecraft Doctor Who Skins Volume I. Over 50 characters from all eras of the show including the First, Fourth, Eleventh and Twelfth Doctors, Amy Pond, Clara Oswald, Rose Tyler, Zygons, The Master, Weeping Angels, the Daleks and their evil creator Davros.\r\n\r\nBedrock Cosmos Note: Special thanks to Mwam for providing us with the original skin pack files.",
          "neutral": "Launch yourself on an epic adventure in space and time with the Minecraft Doctor Who Skins Volume I. Over 50 characters from all eras of the show including the First, Fourth, Eleventh and Twelfth Doctors, Amy Pond, Clara Oswald, Rose Tyler, Zygons, The Master, Weeping Angels, the Daleks and their evil creator Davros.\r\n\r\nBedrock Cosmos Note: Special thanks to Mwam for providing us with the original skin pack files."
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["title.bedrockvanilla"],
        "Tags": [
          "60a2047b-fe99-4a1d-9ccf-79d6a9b63adb",
          "e58fb8eb-0e70-4c89-9f60-e7a4a72f9061",
          "skinpack",
          "has_skinpack",
          "genre.action",
          "tag.science_fiction",
          "tag.skin",
          "1P"
        ],
        "CreationDate": "2018-07-31T18:07:15.234Z",
        "LastModifiedDate": "2024-10-18T02:09:19.362Z",
        "Images": [],
        "ItemReferences": [
          {
            "Id": "79fe9dfe-a65b-4a47-b264-cc0aba1d7b3e",
            "Amount": 1
          }
        ],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "60a2047b-fe99-4a1d-9ccf-79d6a9b63adb",
          "originalCreatorId": "2535448579972708",
          "price": -1,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "e58fb8eb-0e70-4c89-9f60-e7a4a72f9061",
              "version": "1.0.6"
            }
          ],
          "skinPack": {
            "count": 57
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"83ba3582-970f-4100-b8cc-277a10217b13", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "c65b1919-df90-4c9b-b3d5-a59c7d7a3979",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "0865b49f-0123-459e-8e6d-a1ec99f5f9fa"
          }
        ],
        "Title": {
          "NEUTRAL": "Doctor Who Skins Volume II",
          "neutral": "Doctor Who Skins Volume II"
        },
        "Description": {
          "NEUTRAL": "Zooming through the Time Vortex, hot on the heels of the first Minecraft Doctor Who Skin pack, comes Volume II. Over 50 characters from all eras of the show including the Second, Third, Eighth and Tenth Doctors, Donna Noble, Captain Jack Harkness, K9, Brigadier Lethbridge-Stewart, the Sea Devil and the Cybermen in all their guises from the 60’s through to the most recent and deadly upgrade.\r\n\r\nBedrock Cosmos Note: Special thanks to Mwam for providing us with the original skin pack files.\r\n",
          "neutral": "Zooming through the Time Vortex, hot on the heels of the first Minecraft Doctor Who Skin pack, comes Volume II. Over 50 characters from all eras of the show including the Second, Third, Eighth and Tenth Doctors, Donna Noble, Captain Jack Harkness, K9, Brigadier Lethbridge-Stewart, the Sea Devil and the Cybermen in all their guises from the 60’s through to the most recent and deadly upgrade.\r\n\r\nBedrock Cosmos Note: Special thanks to Mwam for providing us with the original skin pack files.\r\n"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["title.bedrockvanilla"],
        "Tags": [
          "c65b1919-df90-4c9b-b3d5-a59c7d7a3979",
          "83ba3582-970f-4100-b8cc-277a10217b13",
          "skinpack",
          "has_skinpack",
          "genre.action",
          "tag.science_fiction",
          "tag.skin",
          "1P"
        ],
        "CreationDate": "2018-07-31T18:07:15.234Z",
        "LastModifiedDate": "2024-10-18T02:09:19.362Z",
        "Images": [],
        "ItemReferences": [
          {
            "Id": "0865b49f-0123-459e-8e6d-a1ec99f5f9fa",
            "Amount": 1
          }
        ],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "c65b1919-df90-4c9b-b3d5-a59c7d7a3979",
          "originalCreatorId": "2535448579972708",
          "price": -1,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "83ba3582-970f-4100-b8cc-277a10217b13",
              "version": "1.0.6"
            }
          ],
          "skinPack": {
            "count": 51
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"70777aa6-5949-4529-947f-2fcdbc94c3cb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "0c77040a-abb6-4938-963d-5a8e9872c85c",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "388ee70d-2b01-43ca-a2d5-e3589e6e8b33"
          }
        ],
        "Title": {
          "en-US": "Earth Skin",
          "NEUTRAL": "Earth Skin",
          "neutral": "Earth Skin"
        },
        "Description": {
          "en-US": "Experience actual globetrotting by taking a walk in this excellent Earth skin! With cloud-coated shoulders, an Earthy torso, and rock-solid legs, this planetary pal is the perfect way to celebrate our upcoming game, Minecraft: Earth. Explore the Overworld AS the Overworld!",
          "NEUTRAL": "Experience actual globetrotting by taking a walk in this excellent Earth skin! With cloud-coated shoulders, an Earthy torso, and rock-solid legs, this planetary pal is the perfect way to celebrate our upcoming game, Minecraft: Earth. Explore the Overworld AS the Overworld!",
          "neutral": "Experience actual globetrotting by taking a walk in this excellent Earth skin! With cloud-coated shoulders, an Earthy torso, and rock-solid legs, this planetary pal is the perfect way to celebrate our upcoming game, Minecraft: Earth. Explore the Overworld AS the Overworld!"
        },
        "Keywords": {
          "en-US": {
            "Values": ["Creative", "Skin", "Planets", "Tree"]
          },
          "NEUTRAL": {
            "Values": ["Creative", "Skin", "Planets", "Tree"]
          },
          "neutral": {
            "Values": ["Creative", "Skin", "Planets", "Tree"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "0c77040a-abb6-4938-963d-5a8e9872c85c",
          "70777aa6-5949-4529-947f-2fcdbc94c3cb",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.creative",
          "tag.skin",
          "tag.planets",
          "tag.tree",
          "1P"
        ],
        "CreationDate": "2019-05-13T16:21:40.682Z",
        "LastModifiedDate": "2025-04-25T17:21:16.643Z",
        "Contents": [],
        "Images": [
          {
            "Id": "70371f70-cad7-47b4-a217-3c44bedc727a",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/70371f70-cad7-47b4-a217-3c44bedc727a/EarthSkin_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "2882bef9-7809-4b34-a9f7-b327262b1682",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.9,
          "TotalCount": 17559,
          "Count5Star": 17026,
          "Count4Star": 328,
          "Count3Star": 81,
          "Count2Star": 18,
          "Count1Star": 106
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "388ee70d-2b01-43ca-a2d5-e3589e6e8b33",
          "originalCreatorId": "2535448579972708",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "70777aa6-5949-4529-947f-2fcdbc94c3cb",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 1
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"d44ba892-7378-4fcd-a3f1-72de53675d24", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "62c68fd4-3075-40ed-8b7b-15dcc7b667ff",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Festive Mash-Up",
          "neutral": "Festive Mash-Up"
        },
        "Description": {
          "NEUTRAL": "Celebrate the Festive period with this wintery Mash-up Pack containing a Festive style Texture Pack, Skin Pack, new music and a Festive world!",
          "neutral": "Celebrate the Festive period with this wintery Mash-up Pack containing a Festive style Texture Pack, Skin Pack, new music and a Festive world!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["xboxone.store"],
        "Tags": [
          "62c68fd4-3075-40ed-8b7b-15dcc7b667ff",
          "d44ba892-7378-4fcd-a3f1-72de53675d24",
          "skinpack"
        ],
        "CreationDate": "2025-10-27T10:00:00Z",
        "LastModifiedDate": "2025-10-27T10:00:00Z",
        "Images": [
          {
            "Id": "2211bea0-8a75-4150-a548-9ccaa2f9f246",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://bedrock-cosmos.app/thumbnails/FestiveLegacy.jpeg"
          }
        ],
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "62c68fd4-3075-40ed-8b7b-15dcc7b667ff",
          "originalCreatorId": "2535448579972708",
          "price": -1,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "d44ba892-7378-4fcd-a3f1-72de53675d24",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"4972c4c7-6eac-4e4c-b2d0-822b590b6fa7", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "b3b50166-5612-4ff1-8f03-9af0b01cb4da",
        "Type": "bundle",
        "AlternateIds": [],
        "Title": {
          "en-US": "Founder's Cape",
          "NEUTRAL": "Founder's Cape",
          "neutral": "Founder's Cape"
        },
        "Description": {
          "en-US": "Secure your Character Creator Founder’s Cape early by downloading this skin pack. By downloading you will automatically receive your cape when it launches later this fall.",
          "NEUTRAL": "Secure your Character Creator Founder’s Cape early by downloading this skin pack. By downloading you will automatically receive your cape when it launches later this fall.",
          "neutral": "Secure your Character Creator Founder’s Cape early by downloading this skin pack. By downloading you will automatically receive your cape when it launches later this fall."
        },
        "Keywords": {
          "en-US": {
            "Values": [
              "Exploration",
              "Cape",
              "Character Customization",
              "Survival"
            ]
          },
          "NEUTRAL": {
            "Values": [
              "Exploration",
              "Cape",
              "Character Customization",
              "Survival"
            ]
          },
          "neutral": {
            "Values": [
              "Exploration",
              "Cape",
              "Character Customization",
              "Survival"
            ]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "ios.store",
          "oculus.store.rift",
          "oculus.store.gearvr",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "nx.store",
          "b.store",
          "title.bedrockvanilla"
        ],
        "Tags": [
          "skinpack",
          "has_skinpack",
          "1P",
          "4972c4c7-6eac-4e4c-b2d0-822b590b6fa7",
          "b3b50166-5612-4ff1-8f03-9af0b01cb4da",
          "tag.exploration",
          "tag.cape",
          "tag.character_customization",
          "genre.survival",
          "hidden_offer"
        ],
        "CreationDate": "2019-09-27T05:52:34.995Z",
        "LastModifiedDate": "2024-10-17T23:32:45.055Z",
        "Contents": [],
        "Images": [
          {
            "Id": "9df08182-1412-43f4-b3a4-e198e95b3683",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/pf-title-b63a0803d3653643-ee7b/9df08182-1412-43f4-b3a4-e198e95b3683/FoundersPack_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "3d708c22-05fd-436b-8c4b-c08c51ab4eef",
            "Amount": 1
          },
          {
            "Id": "ae5d26f9-3b31-4d27-b0be-0343b4f740d3",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.7,
          "TotalCount": 168909,
          "Count5Star": 144473,
          "Count4Star": 9556,
          "Count3Star": 5437,
          "Count2Star": 2118,
          "Count1Star": 7325
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "originalCreatorId": "2535448579972708",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "4972c4c7-6eac-4e4c-b2d0-822b590b6fa7",
              "version": "3.11.26"
            },
            {
              "type": "persona_piece",
              "uuid": "1b99b77c-3caa-4aaa-8f79-f79f053e586f",
              "version": "1.0.1"
            }
          ],
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"91551b69-a8ab-447a-b0b6-693e9086eae3", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "5b13cb52-e2bf-438c-97f2-1105c54929d9",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Halloween Charity Skin Pack",
          "neutral": "Halloween Charity Skin Pack"
        },
        "Description": {
          "NEUTRAL": "For a limited time only, we're raising some money for good causes. A load of cool games developers have helped create this collection of fun Halloween skins! Some even include capes! 100% of the purchase price will be divided amongst the designated causes. Go to PlayXBLA.com for information on which good causes will benefit and the proportion of funds that will go to each.",
          "neutral": "For a limited time only, we're raising some money for good causes. A load of cool games developers have helped create this collection of fun Halloween skins! Some even include capes! 100% of the purchase price will be divided amongst the designated causes. Go to PlayXBLA.com for information on which good causes will benefit and the proportion of funds that will go to each."
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "5b13cb52-e2bf-438c-97f2-1105c54929d9",
          "91551b69-a8ab-447a-b0b6-693e9086eae3",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-03-01T06:04:40Z",
        "LastModifiedDate": "2026-03-01T06:04:40Z",
        "DisplayProperties": {
          "creatorName": "MinecraftHidden",
          "offerId": "5b13cb52-e2bf-438c-97f2-1105c54929d9",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "91551b69-a8ab-447a-b0b6-693e9086eae3",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"a9396dff-9629-43fa-b7f7-4e885ab258fd", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "e205acc9-2c5a-430f-8576-d87c5ba67db4",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "2fe606b4-b802-4a71-88c4-252111c5ffbf"
          }
        ],
        "Title": {
          "en-US": "Joslyn's Give Campaign Skin",
          "NEUTRAL": "Joslyn's Give Campaign Skin",
          "neutral": "Joslyn's Give Campaign Skin"
        },
        "Description": {
          "en-US": "A special skin pack for winning the Give Campaign auction.",
          "NEUTRAL": "A special skin pack for winning the Give Campaign auction.",
          "neutral": "A special skin pack for winning the Give Campaign auction."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Roleplaying Game", "Skin", "Cool", "Narration"]
          },
          "NEUTRAL": {
            "Values": ["Roleplaying Game", "Skin", "Cool", "Narration"]
          },
          "neutral": {
            "Values": ["Roleplaying Game", "Skin", "Cool", "Narration"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "e205acc9-2c5a-430f-8576-d87c5ba67db4",
          "a9396dff-9629-43fa-b7f7-4e885ab258fd",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.roleplaying_game",
          "tag.skin",
          "tag.cool",
          "tag.narration",
          "1P"
        ],
        "CreationDate": "2020-10-06T22:59:20.891Z",
        "LastModifiedDate": "2023-08-10T10:48:45.975Z",
        "Contents": [],
        "Images": [
          {
            "Id": "d84e5543-39a6-4623-baf0-8534c25ec640",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/pf-title-b63a0803d3653643-20ca2/d84e5543-39a6-4623-baf0-8534c25ec640/thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "a6f4dcc9-8876-4bee-b09e-93a0fa7d6ba3",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.6,
          "TotalCount": 123,
          "Count5Star": 102,
          "Count4Star": 5,
          "Count3Star": 7,
          "Count2Star": 1,
          "Count1Star": 8
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "2fe606b4-b802-4a71-88c4-252111c5ffbf",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "a9396dff-9629-43fa-b7f7-4e885ab258fd",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 1
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"39fa1d65-b3ca-4726-b9e0-f3d2a404e5a4", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "b89ef5de-78ad-4a48-b8a5-f12065286e7d",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "4a27724d-4301-4dd9-9215-190691e3cc92"
          }
        ],
        "Title": {
          "en-US": "Legacy Skin Pack",
          "NEUTRAL": "Legacy Skin Pack",
          "neutral": "Legacy Skin Pack"
        },
        "Description": {
          "en-US": "Get cracking with these starter skins and old favorites brought over from Minecraft editions of yore. Widen your wardrobe, turn out in a tux, or rock it as a croc! ",
          "NEUTRAL": "Get cracking with these starter skins and old favorites brought over from Minecraft editions of yore. Widen your wardrobe, turn out in a tux, or rock it as a croc! ",
          "neutral": "Get cracking with these starter skins and old favorites brought over from Minecraft editions of yore. Widen your wardrobe, turn out in a tux, or rock it as a croc! "
        },
        "Keywords": {
          "en-US": {
            "Values": []
          },
          "NEUTRAL": {
            "Values": []
          },
          "neutral": {
            "Values": []
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "ios.store",
          "oculus.store.rift",
          "oculus.store.gearvr",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "nx.store",
          "b.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "b89ef5de-78ad-4a48-b8a5-f12065286e7d",
          "39fa1d65-b3ca-4726-b9e0-f3d2a404e5a4",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:58:33.242Z",
        "LastModifiedDate": "2024-10-16T01:05:50.727Z",
        "Contents": [],
        "Images": [
          {
            "Id": "da14ab2e-57ca-4d9d-a05b-1dd0262569d0",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/da14ab2e-57ca-4d9d-a05b-1dd0262569d0/legacy_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "4ad42ba2-e6dd-40f2-99b7-6370618bcba8",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.6,
          "TotalCount": 791784,
          "Count5Star": 653653,
          "Count4Star": 49759,
          "Count3Star": 30572,
          "Count2Star": 11445,
          "Count1Star": 46355
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "4a27724d-4301-4dd9-9215-190691e3cc92",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "39fa1d65-b3ca-4726-b9e0-f3d2a404e5a4",
              "version": "4.14.26"
            }
          ],
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"0232dca2-f67e-40d7-9f32-3e836cce9e88", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "38fdf771-febb-4b6f-a162-c42850817d95",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "cbcce217-7916-4d59-b256-78aded026729"
          }
        ],
        "Title": {
          "en-US": "LEGO(R) Minecraft(TM) Dragon Slayer",
          "NEUTRAL": "LEGO(R) Minecraft(TM) Dragon Slayer",
          "neutral": "LEGO(R) Minecraft(TM) Dragon Slayer"
        },
        "Description": {
          "en-US": "Be the Dragon Slayer!\r\nThink you can defeat the ender dragon? Then you’re worthy of wearing this cool Dragon Slayer Skin! Don your armor, grab your enchanted bow and head for the End dimension, where the dragon awaits!",
          "NEUTRAL": "Be the Dragon Slayer!\r\nThink you can defeat the ender dragon? Then you’re worthy of wearing this cool Dragon Slayer Skin! Don your armor, grab your enchanted bow and head for the End dimension, where the dragon awaits!",
          "neutral": "Be the Dragon Slayer!\r\nThink you can defeat the ender dragon? Then you’re worthy of wearing this cool Dragon Slayer Skin! Don your armor, grab your enchanted bow and head for the End dimension, where the dragon awaits!"
        },
        "Keywords": {
          "en-US": {
            "Values": []
          },
          "NEUTRAL": {
            "Values": []
          },
          "neutral": {
            "Values": []
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "ios.store",
          "oculus.store.rift",
          "oculus.store.gearvr",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "nx.store",
          "b.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "38fdf771-febb-4b6f-a162-c42850817d95",
          "0232dca2-f67e-40d7-9f32-3e836cce9e88",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:58:43.519Z",
        "LastModifiedDate": "2024-11-15T00:38:45.161Z",
        "Contents": [],
        "Images": [
          {
            "Id": "535394f8-9660-4d82-8d20-6a39b30a695c",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/535394f8-9660-4d82-8d20-6a39b30a695c/Lego_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "2e06c883-e854-4b3b-a36c-68af09e6dcc3",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.8,
          "TotalCount": 12888,
          "Count5Star": 11795,
          "Count4Star": 593,
          "Count3Star": 228,
          "Count2Star": 74,
          "Count1Star": 198
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "cbcce217-7916-4d59-b256-78aded026729",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "0232dca2-f67e-40d7-9f32-3e836cce9e88",
              "version": "2.26.2026"
            }
          ],
          "skinPack": {
            "count": 1
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"a7657028-94cf-4d70-a421-42b64c18ad27", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "633422ca-cdc9-44c8-a25d-a43fb2d76bc7",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "5557562f-f9f0-47e9-84f7-07db404695ea"
          }
        ],
        "Title": {
          "en-US": "Lucy's Give Campaign Skin",
          "NEUTRAL": "Lucy's Give Campaign Skin",
          "neutral": "Lucy's Give Campaign Skin"
        },
        "Description": {
          "en-US": "A special skin pack for winning the Give Campaign auction.",
          "NEUTRAL": "A special skin pack for winning the Give Campaign auction.",
          "neutral": "A special skin pack for winning the Give Campaign auction."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Roleplaying Game", "Skin", "Cool", "Narration"]
          },
          "NEUTRAL": {
            "Values": ["Roleplaying Game", "Skin", "Cool", "Narration"]
          },
          "neutral": {
            "Values": ["Roleplaying Game", "Skin", "Cool", "Narration"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "633422ca-cdc9-44c8-a25d-a43fb2d76bc7",
          "a7657028-94cf-4d70-a421-42b64c18ad27",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.roleplaying_game",
          "tag.skin",
          "tag.cool",
          "tag.narration",
          "1P"
        ],
        "CreationDate": "2020-10-06T22:58:19.28Z",
        "LastModifiedDate": "2023-08-10T00:10:26.927Z",
        "Contents": [],
        "Images": [
          {
            "Id": "630a619f-892f-4fba-bfc7-80ffe691d37d",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/pf-title-b63a0803d3653643-20ca2/630a619f-892f-4fba-bfc7-80ffe691d37d/thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "5bd2899f-fd73-47a7-902f-31f2b4b28a37",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.3,
          "TotalCount": 79,
          "Count5Star": 58,
          "Count4Star": 6,
          "Count3Star": 3,
          "Count2Star": 1,
          "Count1Star": 11
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "5557562f-f9f0-47e9-84f7-07db404695ea",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "a7657028-94cf-4d70-a421-42b64c18ad27",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 1
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"0f2e08ee-8ef2-4521-b03d-9f89c907c70e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "4d7590d6-8f7f-4f53-989a-2df76b6b015b",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "f1b75170-54d5-47d6-9e5f-7acc04bb159c"
          }
        ],
        "Title": {
          "NEUTRAL": "LittleBigPlanet™ Mash-up",
          "neutral": "LittleBigPlanet™ Mash-up"
        },
        "Description": {
          "NEUTRAL": "Mix the crazy, non-stop creativity of LittleBigPlanet™ into the endless fun and freedom of Minecraft with this special mashup pack.\r\nSackboy®, Sackgirl®, OddSock, Toggle and Swoop will decorate your Minecraft universe with a whole heap of LBP characters, creatures and stuff.\r\nOnly available for Minecraft on PlayStation®4.",
          "neutral": "Mix the crazy, non-stop creativity of LittleBigPlanet™ into the endless fun and freedom of Minecraft with this special mashup pack.\r\nSackboy®, Sackgirl®, OddSock, Toggle and Swoop will decorate your Minecraft universe with a whole heap of LBP characters, creatures and stuff.\r\nOnly available for Minecraft on PlayStation®4."
        },
        "Keywords": {
          "NEUTRAL": {
            "Values": [
              "Exploration",
              "Adventures",
              "Cute",
              "Surreal",
              "Survival",
              "Open World"
            ]
          },
          "neutral": {
            "Values": [
              "Exploration",
              "Adventures",
              "Cute",
              "Surreal",
              "Survival",
              "Open World"
            ]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "b.store",
          "title.bedrockvanilla"
        ],
        "Tags": [
          "4d7590d6-8f7f-4f53-989a-2df76b6b015b",
          "0f2e08ee-8ef2-4521-b03d-9f89c907c70e",
          "abfcab1a-19fe-4564-b4ed-ffbda4a77690",
          "1dde574b-2b4d-48e6-951e-d135093bcdc9",
          "tag.exploration",
          "tag.adventures",
          "tag.cute",
          "tag.surreal",
          "1P",
          "mashup",
          "has_skinpack",
          "survival_spawn_world",
          "genre.survival",
          "subgenre.open_world",
          "playercount.1-4"
        ],
        "CreationDate": "2019-10-29T18:49:24.369Z",
        "LastModifiedDate": "2026-03-31T15:17:33.379Z",
        "Contents": [],
        "Images": [
          {
            "Id": "aa76e7af-907e-4241-a198-594105c6d062",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://bedrock-cosmos.app/thumbnails/LittleBigPlanetRestored_thumbnail.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "8bd9c53b-a1b8-4579-87a7-b41a0ce1b2d1",
            "Amount": 1
          },
          {
            "Id": "ff0b750d-8ab3-4397-8d9a-c057bca18fab",
            "Amount": 1
          },
          {
            "Id": "08840483-bde3-41a9-860d-44257e11e1d9",
            "Amount": 1
          }
        ],
        "Price": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 990
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 990
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "PriceOptions": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 990
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 990
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "Rating": {
          "Average": 4.3,
          "TotalCount": 18756,
          "Count5Star": 13997,
          "Count4Star": 1397,
          "Count3Star": 862,
          "Count2Star": 370,
          "Count1Star": 2130
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "f1b75170-54d5-47d6-9e5f-7acc04bb159c",
          "originalCreatorId": "2535448579972708",
          "price": 990,
          "purchasable": true,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "0f2e08ee-8ef2-4521-b03d-9f89c907c70e",
              "version": "3.3.26"
            },
            {
              "type": "resourcepack",
              "uuid": "abfcab1a-19fe-4564-b4ed-ffbda4a77690",
              "version": "1.0.75"
            },
            {
              "type": "worldtemplate",
              "uuid": "1dde574b-2b4d-48e6-951e-d135093bcdc9",
              "version": "1.0.75"
            }
          ],
          "skinPack": {
            "count": 38
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "hardwareMemoryTier": 0
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
})COSMOS"},
  {"47ca6989-81db-404b-a9f1-f3391258b8a2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "1fc32dd0-b399-4255-a4c7-e6e262a40ab6",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "1fc32dd0-b399-4255-a4c7-e6e262a40ab6"
          }
        ],
        "Title": {
          "NEUTRAL": "Mario Mash-Up",
          "neutral": "Mario Mash-Up"
        },
        "Description": {
          "NEUTRAL": "Super Mario meets Minecraft! This Mash-Up Pack contains a Super Mario-style Texture Pack, Skin Pack and a Super Mario-themed world to explore!",
          "neutral": "Super Mario meets Minecraft! This Mash-Up Pack contains a Super Mario-style Texture Pack, Skin Pack and a Super Mario-themed world to explore!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["title.bedrockvanilla"],
        "Tags": [
          "7f4ba1a2-43dd-45b1-aa3f-0b3ca2ebd5c8",
          "47ca6989-81db-404b-a9f1-f3391258b8a2",
          "mashup",
          "has_skinpack",
          "survival_spawn_world",
          "genre.survival",
          "subgenre.open_world",
          "playercount.1-4",
          "1P"
        ],
        "CreationDate": "2025-10-26T00:00:00Z",
        "LastModifiedDate": "2025-10-26T00:00:00Z",
        "Images": [
          {
            "Id": "62e8bc6f-43d1-4f85-8b2f-6057b36def49",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://bedrock-cosmos.app/thumbnails/MarioMashUp.jpeg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "1fc32dd0-b399-4255-a4c7-e6e262a40ab6",
            "Amount": 1
          }
        ],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "1fc32dd0-b399-4255-a4c7-e6e262a40ab6",
          "originalCreatorId": "2535448579972708",
          "price": -1,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "47ca6989-81db-404b-a9f1-f3391258b8a2",
              "version": "1.1.6"
            }
          ],
          "videoUrl": "https://www.youtube.com/watch?v=sNcVYOPw6r0",
          "hardwareMemoryTier": 0
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"083c0c90-cd38-46ad-a473-881f2a7cc069", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "2766095f-b2c0-4237-911f-e18a30fb0928",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "a88b5616-eae5-492e-b141-6de1dc229a46"
          }
        ],
        "Title": {
          "en-US": "Marvel Avengers Skin Pack",
          "NEUTRAL": "Marvel Avengers Skin Pack",
          "neutral": "Marvel Avengers Skin Pack"
        },
        "Description": {
          "en-US": "Step into Minecraft dressed as one of Earth’s Mightiest Heroes (or powerful villains) with this incredible Skin Pack, featuring core team members from Marvel’s Avengers including Iron Man, Captain America, Hulk, Thor, and many more iconic characters from the Marvel Universe.",
          "NEUTRAL": "Step into Minecraft dressed as one of Earth’s Mightiest Heroes (or powerful villains) with this incredible Skin Pack, featuring core team members from Marvel’s Avengers including Iron Man, Captain America, Hulk, Thor, and many more iconic characters from the Marvel Universe.",
          "neutral": "Step into Minecraft dressed as one of Earth’s Mightiest Heroes (or powerful villains) with this incredible Skin Pack, featuring core team members from Marvel’s Avengers including Iron Man, Captain America, Hulk, Thor, and many more iconic characters from the Marvel Universe."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Action", "Skin", "Superhero"]
          },
          "NEUTRAL": {
            "Values": ["Action", "Skin", "Superhero"]
          },
          "neutral": {
            "Values": ["Action", "Skin", "Superhero"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["", "title.bedrockvanilla"],
        "Tags": [
          "2766095f-b2c0-4237-911f-e18a30fb0928",
          "083c0c90-cd38-46ad-a473-881f2a7cc069",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.action",
          "tag.skin",
          "tag.superhero",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:59:06.539Z",
        "LastModifiedDate": "2023-08-09T19:17:58.509Z",
        "Contents": [],
        "Images": [
          {
            "Id": "d3cd9473-b3d9-407a-95b3-6ebfdca004a9",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/d3cd9473-b3d9-407a-95b3-6ebfdca004a9/Avengers_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "943ff888-510d-4ec9-8380-dfb63bc2942e",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.4,
          "TotalCount": 107,
          "Count5Star": 81,
          "Count4Star": 9,
          "Count3Star": 5,
          "Count2Star": 3,
          "Count1Star": 9
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "a88b5616-eae5-492e-b141-6de1dc229a46",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "083c0c90-cd38-46ad-a473-881f2a7cc069",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 35
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"1d3e88a9-617c-45a8-83ba-b4abef5fda4e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "1213b670-c82f-4e28-baf2-9f0d88954c9a",
        "Type": "bundle",
        "AlternateIds": [],
        "Title": {
          "en-US": "Marvel Guardians of the Galaxy Skin Pack",
          "NEUTRAL": "Marvel Guardians of the Galaxy Skin Pack",
          "neutral": "Marvel Guardians of the Galaxy Skin Pack"
        },
        "Description": {
          "en-US": "Join Marvel’s Guardians of the Galaxy in the most cosmic Marvel skin pack for for Minecraft yet! Star-Lord, Gamora, Rocket, Groot and Drax are only part of the pack of 24 skins inspired both by Marvel’s blockbuster film and the comic books.",
          "NEUTRAL": "Join Marvel’s Guardians of the Galaxy in the most cosmic Marvel skin pack for for Minecraft yet! Star-Lord, Gamora, Rocket, Groot and Drax are only part of the pack of 24 skins inspired both by Marvel’s blockbuster film and the comic books.",
          "neutral": "Join Marvel’s Guardians of the Galaxy in the most cosmic Marvel skin pack for for Minecraft yet! Star-Lord, Gamora, Rocket, Groot and Drax are only part of the pack of 24 skins inspired both by Marvel’s blockbuster film and the comic books."
        },
        "Keywords": {
          "en-US": {
            "Values": []
          },
          "NEUTRAL": {
            "Values": []
          },
          "neutral": {
            "Values": []
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["xboxone.store", "title.bedrockvanilla"],
        "Tags": [
          "1P",
          "skinpack",
          "1d3e88a9-617c-45a8-83ba-b4abef5fda4e",
          "1213b670-c82f-4e28-baf2-9f0d88954c9a",
          "hidden_offer",
          "mc_only"
        ],
        "CreationDate": "2018-07-31T20:59:17.543Z",
        "LastModifiedDate": "2023-08-07T00:31:27.14Z",
        "Contents": [],
        "Images": [
          {
            "Id": "b34d9d88-0ad1-43ed-b98c-770faebd3cfb",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/b34d9d88-0ad1-43ed-b98c-770faebd3cfb/MC__MarvelGotG_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "96c108a9-d74c-49ea-abc3-ed810575d9d5",
            "Amount": 1
          }
        ],
        "Price": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 1000000
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "PriceOptions": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 1000000
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "Rating": {
          "Average": 4.1,
          "TotalCount": 194,
          "Count5Star": 132,
          "Count4Star": 21,
          "Count3Star": 5,
          "Count2Star": 3,
          "Count1Star": 33
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "originalCreatorId": "2535448579972708",
          "price": 1000000,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "1d3e88a9-617c-45a8-83ba-b4abef5fda4e",
              "version": "3.11.26"
            }
          ],
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"8eba8968-4ad4-446c-8717-36c38cae0edb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "b79f57ee-ef4f-4e01-bc03-20f5aa21bc26",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "c8837315-c917-42bc-b1db-1fa54a2decea"
          }
        ],
        "Title": {
          "en-US": "Marvel Spider-Man Skin Pack",
          "NEUTRAL": "Marvel Spider-Man Skin Pack",
          "neutral": "Marvel Spider-Man Skin Pack"
        },
        "Description": {
          "en-US": "Look out! Here comes the Spider-Man Skin Pack! Featuring an assortment of 35 friends and foes straight from the saga of your favorite Wall-Crawler, this pack is sure to amaze. Catch it now!",
          "NEUTRAL": "Look out! Here comes the Spider-Man Skin Pack! Featuring an assortment of 35 friends and foes straight from the saga of your favorite Wall-Crawler, this pack is sure to amaze. Catch it now!",
          "neutral": "Look out! Here comes the Spider-Man Skin Pack! Featuring an assortment of 35 friends and foes straight from the saga of your favorite Wall-Crawler, this pack is sure to amaze. Catch it now!"
        },
        "Keywords": {
          "en-US": {
            "Values": ["Action", "Skin", "Superhero"]
          },
          "NEUTRAL": {
            "Values": ["Action", "Skin", "Superhero"]
          },
          "neutral": {
            "Values": ["Action", "Skin", "Superhero"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["xboxone.store", "title.bedrockvanilla"],
        "Tags": [
          "b79f57ee-ef4f-4e01-bc03-20f5aa21bc26",
          "8eba8968-4ad4-446c-8717-36c38cae0edb",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.action",
          "tag.skin",
          "tag.superhero",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:59:28.932Z",
        "LastModifiedDate": "2024-10-18T10:55:00.831Z",
        "Contents": [],
        "Images": [
          {
            "Id": "d2766dd7-c7e9-4836-99f2-ca87eac688cb",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/d2766dd7-c7e9-4836-99f2-ca87eac688cb/MC__SpiderMan_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "1213ed19-481b-4a20-b34d-1050f68c5276",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.5,
          "TotalCount": 435,
          "Count5Star": 362,
          "Count4Star": 12,
          "Count3Star": 13,
          "Count2Star": 4,
          "Count1Star": 44
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "c8837315-c917-42bc-b1db-1fa54a2decea",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "8eba8968-4ad4-446c-8717-36c38cae0edb",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 35
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"98500e08-627e-4f46-a4d3-705a01f6f110", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "4ad937a2-bf33-4390-93e3-62198b58f9ff",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "3b1f5085-2590-4b4b-96ca-bde8040fee99"
          }
        ],
        "Title": {
          "en-US": "Mighty Morphin Power Rangers",
          "NEUTRAL": "Mighty Morphin Power Rangers",
          "neutral": "Mighty Morphin Power Rangers"
        },
        "Description": {
          "en-US": "Assemble your Mighty Morphin Power Rangers team and Go Go!",
          "NEUTRAL": "Assemble your Mighty Morphin Power Rangers team and Go Go!",
          "neutral": "Assemble your Mighty Morphin Power Rangers team and Go Go!"
        },
        "Keywords": {
          "en-US": {
            "Values": ["Action", "Skin", "Superhero"]
          },
          "NEUTRAL": {
            "Values": ["Action", "Skin", "Superhero"]
          },
          "neutral": {
            "Values": ["Action", "Skin", "Superhero"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla"
        ],
        "Tags": [
          "4ad937a2-bf33-4390-93e3-62198b58f9ff",
          "98500e08-627e-4f46-a4d3-705a01f6f110",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.action",
          "tag.skin",
          "tag.superhero",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:59:40.372Z",
        "LastModifiedDate": "2024-11-27T23:05:16.46Z",
        "Contents": [],
        "Images": [
          {
            "Id": "fb481e6f-0173-4bdd-b4ff-7e49b163f904",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/fb481e6f-0173-4bdd-b4ff-7e49b163f904/MightyMorphinPowerRangers_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "a24ced99-5ed4-40ce-a20b-1179b876c36e",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.6,
          "TotalCount": 10734,
          "Count5Star": 9124,
          "Count4Star": 569,
          "Count3Star": 296,
          "Count2Star": 134,
          "Count1Star": 611
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "3b1f5085-2590-4b4b-96ca-bde8040fee99",
          "originalCreatorId": "2535448579972708",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "98500e08-627e-4f46-a4d3-705a01f6f110",
              "version": "3.11.26"
            }
          ],
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"42ae66b4-d3db-49be-8dd8-207a0cade6d8", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "7dae6bfe-e92b-403e-842e-d8d75e329644",
        "Type": "bundle",
        "AlternateIds": [],
        "Title": {
          "en-US": "Minecon 2015 Skin Pack",
          "NEUTRAL": "Minecon 2015 Skin Pack",
          "neutral": "Minecon 2015 Skin Pack"
        },
        "Description": {
          "en-US": "Alex and Steve are ready for Minecon 2015! They’ve brought their complete Minecon cape collection with them and don’t they both look grand?",
          "NEUTRAL": "Alex and Steve are ready for Minecon 2015! They’ve brought their complete Minecon cape collection with them and don’t they both look grand?",
          "neutral": "Alex and Steve are ready for Minecon 2015! They’ve brought their complete Minecon cape collection with them and don’t they both look grand?"
        },
        "Keywords": {
          "en-US": {
            "Values": []
          },
          "NEUTRAL": {
            "Values": []
          },
          "neutral": {
            "Values": []
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "ios.store",
          "oculus.store.rift",
          "oculus.store.gearvr",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "nx.store",
          "b.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "1P",
          "skinpack",
          "hidden_offer",
          "42ae66b4-d3db-49be-8dd8-207a0cade6d8",
          "7dae6bfe-e92b-403e-842e-d8d75e329644"
        ],
        "CreationDate": "2018-07-31T20:59:50.72Z",
        "LastModifiedDate": "2023-08-06T20:01:34.065Z",
        "Contents": [],
        "Images": [
          {
            "Id": "65f2a2fb-cd9e-46f7-9b91-660b83245f4e",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/65f2a2fb-cd9e-46f7-9b91-660b83245f4e/Minecon2015_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "d923a6b5-b43d-47bc-909e-909caca3983b",
            "Amount": 1
          }
        ],
        "Price": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 1000000
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 1000000
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "PriceOptions": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 1000000
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 1000000
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "Rating": {
          "Average": 4.7,
          "TotalCount": 3175,
          "Count5Star": 2720,
          "Count4Star": 156,
          "Count3Star": 103,
          "Count2Star": 42,
          "Count1Star": 154
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "originalCreatorId": "2535448579972708",
          "price": 1000000,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "42ae66b4-d3db-49be-8dd8-207a0cade6d8",
              "version": "3.11.26"
            }
          ],
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"838bdb6b-bf30-42ca-a4d8-e35865fba8e2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "20b4d681-df67-420c-aff3-07673bb44d07",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "892edc6f-e181-4aa9-9192-59a53dc91e01"
          }
        ],
        "Title": {
          "en-US": "MINECON 2016 Skin Pack",
          "NEUTRAL": "MINECON 2016 Skin Pack",
          "neutral": "MINECON 2016 Skin Pack"
        },
        "Description": {
          "en-US": "Are you ready for MINECON?",
          "NEUTRAL": "Are you ready for MINECON?",
          "neutral": "Are you ready for MINECON?"
        },
        "Keywords": {
          "en-US": {
            "Values": []
          },
          "NEUTRAL": {
            "Values": []
          },
          "neutral": {
            "Values": []
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "ios.store",
          "oculus.store.rift",
          "oculus.store.gearvr",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "nx.store",
          "b.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "20b4d681-df67-420c-aff3-07673bb44d07",
          "838bdb6b-bf30-42ca-a4d8-e35865fba8e2",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:59:59.923Z",
        "LastModifiedDate": "2023-08-07T18:38:32.129Z",
        "Contents": [],
        "Images": [
          {
            "Id": "f219076e-dac1-4367-aaf3-eaad0987e927",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/f219076e-dac1-4367-aaf3-eaad0987e927/MINECON2016_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "1007779f-a9e2-4620-a460-ee5b4e74e970",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.7,
          "TotalCount": 18067,
          "Count5Star": 15445,
          "Count4Star": 1053,
          "Count3Star": 587,
          "Count2Star": 239,
          "Count1Star": 743
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "892edc6f-e181-4aa9-9192-59a53dc91e01",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "838bdb6b-bf30-42ca-a4d8-e35865fba8e2",
              "version": "3.11.26"
            }
          ],
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"ac3914ce-f321-4b13-89bf-5a74990242c8", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "01d22780-c8c6-421d-a5cf-c615a398c480",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "927731b1-1710-4032-a9f1-abc4fcb5a713"
          }
        ],
        "Title": {
          "en-US": "Mumbo Jumbo & Grian Skins",
          "NEUTRAL": "Mumbo Jumbo & Grian Skins",
          "neutral": "Mumbo Jumbo & Grian Skins"
        },
        "Description": {
          "en-US": "Private skin pack containing Mumbo Jumbo’s and Grian’s skins for use in their Minecraft Earth road trip video series, debuting at Minecon Live 2020. ",
          "NEUTRAL": "Private skin pack containing Mumbo Jumbo’s and Grian’s skins for use in their Minecraft Earth road trip video series, debuting at Minecon Live 2020. ",
          "neutral": "Private skin pack containing Mumbo Jumbo’s and Grian’s skins for use in their Minecraft Earth road trip video series, debuting at Minecon Live 2020. "
        },
        "Keywords": {
          "en-US": {
            "Values": ["Action", "Choose Your Own Adventure", "Movie Star"]
          },
          "NEUTRAL": {
            "Values": ["Action", "Choose Your Own Adventure", "Movie Star"]
          },
          "neutral": {
            "Values": ["Action", "Choose Your Own Adventure", "Movie Star"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "01d22780-c8c6-421d-a5cf-c615a398c480",
          "ac3914ce-f321-4b13-89bf-5a74990242c8",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.action",
          "tag.choose_your_own_adventure",
          "tag.movie_star",
          "1P"
        ],
        "CreationDate": "2020-08-17T23:40:54.817Z",
        "LastModifiedDate": "2023-08-09T16:03:29.371Z",
        "Contents": [],
        "Images": [
          {
            "Id": "89252f64-c1b0-41dc-a538-94fa0c14fa1b",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/pf-title-b63a0803d3653643-20ca2/89252f64-c1b0-41dc-a538-94fa0c14fa1b/EarthSkin_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "7b1cb6fc-405e-4e35-a33f-1ee5b94564df",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.2,
          "TotalCount": 268,
          "Count5Star": 194,
          "Count4Star": 20,
          "Count3Star": 11,
          "Count2Star": 6,
          "Count1Star": 37
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "927731b1-1710-4032-a9f1-abc4fcb5a713",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "ac3914ce-f321-4b13-89bf-5a74990242c8",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 2
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"a618ca05-77ba-4afb-bb9a-8fdb413219ab", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "0d8ce926-257f-4297-b585-05d1f88e782a",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "5a2efa45-6d0b-4068-852a-77578c2255c5"
          }
        ],
        "Title": {
          "en-US": "Paws and Claws Cosplay Pack",
          "NEUTRAL": "Paws and Claws Cosplay Pack",
          "neutral": "Paws and Claws Cosplay Pack"
        },
        "Description": {
          "en-US": "Wish you looked more like a sneezing panda? How about as swish as a Siamese cat? Paws your game and give yourself an unfurgettable makeover with these cat and panda skins, with 62.5% of the sales going to WWF and their amazing work protecting panda habitats and other vulnerable species. Purrrfect! Learn more at https://aka.ms/WWF.",
          "NEUTRAL": "Wish you looked more like a sneezing panda? How about as swish as a Siamese cat? Paws your game and give yourself an unfurgettable makeover with these cat and panda skins, with 62.5% of the sales going to WWF and their amazing work protecting panda habitats and other vulnerable species. Purrrfect! Learn more at https://aka.ms/WWF.",
          "neutral": "Wish you looked more like a sneezing panda? How about as swish as a Siamese cat? Paws your game and give yourself an unfurgettable makeover with these cat and panda skins, with 62.5% of the sales going to WWF and their amazing work protecting panda habitats and other vulnerable species. Purrrfect! Learn more at https://aka.ms/WWF."
        },
        "Keywords": {
          "en-US": {
            "Values": []
          },
          "NEUTRAL": {
            "Values": []
          },
          "neutral": {
            "Values": []
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "ios.store",
          "oculus.store.rift",
          "oculus.store.gearvr",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "nx.store",
          "b.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "0d8ce926-257f-4297-b585-05d1f88e782a",
          "a618ca05-77ba-4afb-bb9a-8fdb413219ab",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "1P"
        ],
        "CreationDate": "2018-12-11T23:52:55.918Z",
        "LastModifiedDate": "2023-07-29T20:26:04.069Z",
        "Contents": [],
        "Images": [
          {
            "Id": "fa3d4886-12d4-49f9-922b-4dcc9240dc43",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/fa3d4886-12d4-49f9-922b-4dcc9240dc43/thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "f943bc86-f993-4b6b-87af-7851050db0cb",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.5,
          "TotalCount": 1336,
          "Count5Star": 1088,
          "Count4Star": 93,
          "Count3Star": 47,
          "Count2Star": 17,
          "Count1Star": 91
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "5a2efa45-6d0b-4068-852a-77578c2255c5",
          "originalCreatorId": "2535448579972708",
          "price": 490,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "a618ca05-77ba-4afb-bb9a-8fdb413219ab",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 16
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"720ee1f3-dc46-4ffc-a390-8bb035e7be26", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "a681c130-1ac9-456f-a13a-1f985365bb77",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "c2d43a4c-04cf-461a-bda7-3f21ef6bef40"
          }
        ],
        "Title": {
          "en-US": "Skin Pack 1",
          "NEUTRAL": "Skin Pack 1",
          "neutral": "Skin Pack 1"
        },
        "Description": {
          "en-US": "A dedicated version of Skin Pack 1, featuring exclusive characters along with others from the Classic version.\r\nOnly available for Minecraft on PlayStation®4.",
          "NEUTRAL": "A dedicated version of Skin Pack 1, featuring exclusive characters along with others from the Classic version.\r\nOnly available for Minecraft on PlayStation®4.",
          "neutral": "A dedicated version of Skin Pack 1, featuring exclusive characters along with others from the Classic version.\r\nOnly available for Minecraft on PlayStation®4."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Old School", "Retro"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Old School", "Retro"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Old School", "Retro"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["b.store", "title.bedrockvanilla"],
        "Tags": [
          "a681c130-1ac9-456f-a13a-1f985365bb77",
          "720ee1f3-dc46-4ffc-a390-8bb035e7be26",
          "skinpack",
          "has_skinpack",
          "genre.survival",
          "tag.skin",
          "tag.old_school",
          "tag.retro",
          "1P"
        ],
        "CreationDate": "2019-10-29T18:53:58.392Z",
        "LastModifiedDate": "2025-05-02T20:12:59.932Z",
        "Contents": [],
        "Images": [
          {
            "Id": "db90b652-cfe4-40a5-bb5f-9e534d01daa4",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/pf-title-b63a0803d3653643-ee7b/db90b652-cfe4-40a5-bb5f-9e534d01daa4/SkinPack1Sony_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "ec0fe809-ec9a-4c9f-830a-551800875229",
            "Amount": 1
          }
        ],
        "Price": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 490
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 490
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "PriceOptions": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 490
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 490
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "Rating": {
          "Average": 4.6,
          "TotalCount": 59211,
          "Count5Star": 48176,
          "Count4Star": 4495,
          "Count3Star": 2298,
          "Count2Star": 881,
          "Count1Star": 3361
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "c2d43a4c-04cf-461a-bda7-3f21ef6bef40",
          "originalCreatorId": "2535448579972708",
          "price": 490,
          "purchasable": true,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "720ee1f3-dc46-4ffc-a390-8bb035e7be26",
              "version": "1.0.5"
            }
          ],
          "skinPack": {
            "count": 44
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"f73518e4-10b6-4eaa-a088-7b246483694e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "d1e7ecae-b422-40a2-8037-cf24571f901c",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "3df39646-58ce-4781-a34c-c0ef6822a24b"
          }
        ],
        "Title": {
          "en-US": "Skin Pack 1 - Classic",
          "NEUTRAL": "Skin Pack 1 - Classic",
          "neutral": "Skin Pack 1 - Classic"
        },
        "Description": {
          "en-US": "Customize your character with this selection of stunning skins!\r\n\r\nBedrock Cosmos Note: Due to this skin pack being recently delisted, these skins are not currently available for use if you have not previously purchased/redeemed them on your Minecraft account.",
          "NEUTRAL": "Customize your character with this selection of stunning skins!\r\n\r\nBedrock Cosmos Note: Due to this skin pack being recently delisted, these skins are not currently available for use if you have not previously purchased/redeemed them on your Minecraft account.",
          "neutral": "Customize your character with this selection of stunning skins!\r\n\r\nBedrock Cosmos Note: Due to this skin pack being recently delisted, these skins are not currently available for use if you have not previously purchased/redeemed them on your Minecraft account."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Classic", "Old School"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Classic", "Old School"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Classic", "Old School"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla"
        ],
        "Tags": [
          "d1e7ecae-b422-40a2-8037-cf24571f901c",
          "f73518e4-10b6-4eaa-a088-7b246483694e",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.survival",
          "tag.skin",
          "tag.classic",
          "tag.old_school",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:54:50.815Z",
        "LastModifiedDate": "2024-10-15T19:37:02.698Z",
        "Contents": [],
        "Images": [
          {
            "Id": "5450d128-ca64-4113-b348-ec85d7dc3207",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/5450d128-ca64-4113-b348-ec85d7dc3207/1_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "56a43aae-6a67-4d8d-a86e-425a5a2b2f2c",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.5,
          "TotalCount": 33851,
          "Count5Star": 26466,
          "Count4Star": 2679,
          "Count3Star": 1673,
          "Count2Star": 674,
          "Count1Star": 2359
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "3df39646-58ce-4781-a34c-c0ef6822a24b",
          "originalCreatorId": "2535448579972708",
          "price": 490,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "f73518e4-10b6-4eaa-a088-7b246483694e",
              "version": "3.20.2026"
            }
          ],
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"d78aa7a2-9680-417c-97da-01c9cfbf0c4b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "40fbf08d-390d-480c-9213-afb3886915eb",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "af36d596-d63a-40c4-87fc-1fbbcf76c279"
          }
        ],
        "Title": {
          "en-US": "Skin Pack 2",
          "NEUTRAL": "Skin Pack 2",
          "neutral": "Skin Pack 2"
        },
        "Description": {
          "en-US": "A dedicated version of Skin Pack 2, featuring exclusive characters along with others from the Classic version.\r\nOnly available for Minecraft on PlayStation®4.",
          "NEUTRAL": "A dedicated version of Skin Pack 2, featuring exclusive characters along with others from the Classic version.\r\nOnly available for Minecraft on PlayStation®4.",
          "neutral": "A dedicated version of Skin Pack 2, featuring exclusive characters along with others from the Classic version.\r\nOnly available for Minecraft on PlayStation®4."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Old School", "Retro"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Old School", "Retro"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Old School", "Retro"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["b.store", "title.bedrockvanilla"],
        "Tags": [
          "40fbf08d-390d-480c-9213-afb3886915eb",
          "d78aa7a2-9680-417c-97da-01c9cfbf0c4b",
          "skinpack",
          "has_skinpack",
          "genre.survival",
          "tag.skin",
          "tag.old_school",
          "tag.retro",
          "1P"
        ],
        "CreationDate": "2019-10-29T18:54:28.944Z",
        "LastModifiedDate": "2025-05-02T20:12:44.949Z",
        "Contents": [],
        "Images": [
          {
            "Id": "6d9cfbe1-bdd2-4e80-ad43-a4cea44a6b1d",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/pf-title-b63a0803d3653643-ee7b/6d9cfbe1-bdd2-4e80-ad43-a4cea44a6b1d/SkinPack2Sony_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "e4ae0bea-99f5-4c32-aabd-fafa0fd560d8",
            "Amount": 1
          }
        ],
        "Price": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 490
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 490
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "PriceOptions": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 490
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 490
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "Rating": {
          "Average": 4.6,
          "TotalCount": 5037,
          "Count5Star": 4112,
          "Count4Star": 377,
          "Count3Star": 173,
          "Count2Star": 55,
          "Count1Star": 320
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "af36d596-d63a-40c4-87fc-1fbbcf76c279",
          "originalCreatorId": "2535448579972708",
          "price": 490,
          "purchasable": true,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "d78aa7a2-9680-417c-97da-01c9cfbf0c4b",
              "version": "3.20.2026"
            }
          ],
          "skinPack": {
            "count": 43
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"d53c598e-3ea8-48d5-80e2-3ae9fc08e527", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "586448fd-d6ce-4bdf-9f1b-8e3f65b6bb95",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "d9e52a89-c414-4e9e-a2c1-fd5540c1e3b5"
          }
        ],
        "Title": {
          "en-US": "Skin Pack 2 - Classic",
          "NEUTRAL": "Skin Pack 2 - Classic",
          "neutral": "Skin Pack 2 - Classic"
        },
        "Description": {
          "en-US": "Customise your Minecraft character with this 2nd selection of stunning skins!",
          "NEUTRAL": "Customise your Minecraft character with this 2nd selection of stunning skins!",
          "neutral": "Customise your Minecraft character with this 2nd selection of stunning skins!"
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Classic", "Old School"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Classic", "Old School"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Classic", "Old School"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "ios.store",
          "oculus.store.rift",
          "oculus.store.gearvr",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "nx.store",
          "title.bedrockvanilla"
        ],
        "Tags": [
          "586448fd-d6ce-4bdf-9f1b-8e3f65b6bb95",
          "d53c598e-3ea8-48d5-80e2-3ae9fc08e527",
          "skinpack",
          "has_skinpack",
          "genre.survival",
          "tag.skin",
          "tag.classic",
          "tag.old_school",
          "1P"
        ],
        "CreationDate": "2018-10-10T03:37:58.09Z",
        "LastModifiedDate": "2025-04-25T19:27:17.298Z",
        "Contents": [],
        "Images": [
          {
            "Id": "65c0d4ee-e8f9-417d-97b1-3d05419fcf08",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/pf-title-b63a0803d3653643-ee7b/65c0d4ee-e8f9-417d-97b1-3d05419fcf08/Minecraft_SkinPack2_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "52b2fe9b-36d9-4e82-956e-9345dc936a8b",
            "Amount": 1
          }
        ],
        "Price": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 490
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 490
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "PriceOptions": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 490
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 490
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "Rating": {
          "Average": 4.6,
          "TotalCount": 6486,
          "Count5Star": 5462,
          "Count4Star": 400,
          "Count3Star": 205,
          "Count2Star": 85,
          "Count1Star": 334
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "d9e52a89-c414-4e9e-a2c1-fd5540c1e3b5",
          "originalCreatorId": "2535448579972708",
          "price": 490,
          "purchasable": true,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "d53c598e-3ea8-48d5-80e2-3ae9fc08e527",
              "version": "3.20.2026"
            }
          ],
          "skinPack": {
            "count": 43,
            "sampleSkins": [
              {
                "localizationName": "Pirate",
                "skinIndex": 9
              },
              {
                "localizationName": "Ninja",
                "skinIndex": 10
              }
            ]
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "lastUpdated": "1.14.30"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"640f444e-0d59-4d9a-9502-d64658a9b51b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "36b8bc1a-10a1-4405-adc1-c93086dcb317",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "d6ef4a27-1e87-447a-8e22-21c5ccc0d470"
          }
        ],
        "Title": {
          "en-US": "Skin Pack 3",
          "NEUTRAL": "Skin Pack 3",
          "neutral": "Skin Pack 3"
        },
        "Description": {
          "en-US": "A dedicated version of Skin Pack 3, featuring exclusive characters along with others from the Classic version.\r\nOnly available for Minecraft on PlayStation®4.",
          "NEUTRAL": "A dedicated version of Skin Pack 3, featuring exclusive characters along with others from the Classic version.\r\nOnly available for Minecraft on PlayStation®4.",
          "neutral": "A dedicated version of Skin Pack 3, featuring exclusive characters along with others from the Classic version.\r\nOnly available for Minecraft on PlayStation®4."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Old School", "Retro"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Old School", "Retro"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Old School", "Retro"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["b.store", "title.bedrockvanilla"],
        "Tags": [
          "36b8bc1a-10a1-4405-adc1-c93086dcb317",
          "640f444e-0d59-4d9a-9502-d64658a9b51b",
          "skinpack",
          "has_skinpack",
          "genre.survival",
          "tag.skin",
          "tag.old_school",
          "tag.retro",
          "1P"
        ],
        "CreationDate": "2019-10-29T18:55:02.36Z",
        "LastModifiedDate": "2025-05-02T22:53:46.223Z",
        "Contents": [],
        "Images": [
          {
            "Id": "533991c2-2839-4585-b26c-95ca68d70acc",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/pf-title-b63a0803d3653643-ee7b/533991c2-2839-4585-b26c-95ca68d70acc/SkinPack3Sony_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "16a1e9a8-c2e3-4d89-98b4-1e80e8601fda",
            "Amount": 1
          }
        ],
        "Price": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 490
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 490
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "PriceOptions": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 490
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 490
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "Rating": {
          "Average": 4.5,
          "TotalCount": 3297,
          "Count5Star": 2630,
          "Count4Star": 250,
          "Count3Star": 139,
          "Count2Star": 34,
          "Count1Star": 244
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "d6ef4a27-1e87-447a-8e22-21c5ccc0d470",
          "originalCreatorId": "2535448579972708",
          "price": 490,
          "purchasable": true,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "640f444e-0d59-4d9a-9502-d64658a9b51b",
              "version": "3.20.2026"
            }
          ],
          "skinPack": {
            "count": 45
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"5371bde5-04bb-4195-8305-67dd24194f7b", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "297ef7fb-debf-40a5-aea7-4e7acf141c59",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "59f88432-2cbf-4306-8bed-f297c8ffd427"
          }
        ],
        "Title": {
          "en-US": "Skin Pack 3 - Classic",
          "NEUTRAL": "Skin Pack 3 - Classic",
          "neutral": "Skin Pack 3 - Classic"
        },
        "Description": {
          "en-US": "Customize your character with this selection of stunning skins!",
          "NEUTRAL": "Customize your character with this selection of stunning skins!",
          "neutral": "Customize your character with this selection of stunning skins!"
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Classic", "Old School"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Classic", "Old School"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Classic", "Old School"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "ios.store",
          "oculus.store.rift",
          "oculus.store.gearvr",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "nx.store",
          "title.bedrockvanilla"
        ],
        "Tags": [
          "297ef7fb-debf-40a5-aea7-4e7acf141c59",
          "5371bde5-04bb-4195-8305-67dd24194f7b",
          "skinpack",
          "has_skinpack",
          "genre.survival",
          "tag.skin",
          "tag.classic",
          "tag.old_school",
          "1P"
        ],
        "CreationDate": "2018-10-10T03:38:20.824Z",
        "LastModifiedDate": "2025-04-25T19:27:23.879Z",
        "Contents": [],
        "Images": [
          {
            "Id": "14dc48c8-70c6-41c9-ab2a-b748adcda4a7",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/pf-title-b63a0803d3653643-ee7b/14dc48c8-70c6-41c9-ab2a-b748adcda4a7/Minecraft_SkinPack2_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "c3644a56-4abc-4dc0-b3a6-2719b52d846f",
            "Amount": 1
          }
        ],
        "Price": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 490
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 490
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "PriceOptions": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 490
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 490
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "Rating": {
          "Average": 4.6,
          "TotalCount": 5438,
          "Count5Star": 4519,
          "Count4Star": 346,
          "Count3Star": 179,
          "Count2Star": 79,
          "Count1Star": 315
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "59f88432-2cbf-4306-8bed-f297c8ffd427",
          "originalCreatorId": "2535448579972708",
          "price": 490,
          "purchasable": true,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "5371bde5-04bb-4195-8305-67dd24194f7b",
              "version": "3.20.2026"
            }
          ],
          "skinPack": {
            "count": 44,
            "sampleSkins": [
              {
                "localizationName": "Castaway",
                "skinIndex": 0
              },
              {
                "localizationName": "Farmer",
                "skinIndex": 6
              }
            ]
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "lastUpdated": "1.14.30"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"55fa75f0-1635-485f-9586-1bdd0cb6a255", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "2f60a7a0-8010-49b1-8b57-851ac41f34cf",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Skin Pack 4",
          "neutral": "Skin Pack 4"
        },
        "Description": {
          "NEUTRAL": "This fourth skin pack brings you a fresh bunch of exciting skins for you to customise your Minecraft character with!",
          "neutral": "This fourth skin pack brings you a fresh bunch of exciting skins for you to customise your Minecraft character with!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["xboxone.store"],
        "Tags": [
          "2f60a7a0-8010-49b1-8b57-851ac41f34cf",
          "55fa75f0-1635-485f-9586-1bdd0cb6a255",
          "skinpack"
        ],
        "CreationDate": "2025-10-27T10:00:00Z",
        "LastModifiedDate": "2025-10-27T10:00:00Z",
        "Images": [
          {
            "Id": "2211bea0-8a75-4150-a548-9ccaa2f9f246",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://www.4jstudios.com/wp-content/uploads/2022/09/skinpack4_Thumbnail_0.jpg"
          }
        ],
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "2f60a7a0-8010-49b1-8b57-851ac41f34cf",
          "originalCreatorId": "2535448579972708",
          "price": -1,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "55fa75f0-1635-485f-9586-1bdd0cb6a255",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"cc59b688-7cfb-4fa0-a76e-84aa55b92cae", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "80c85890-dad7-4d3a-b2ef-60071327b7cf",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Skin Pack 5",
          "neutral": "Skin Pack 5"
        },
        "Description": {
          "NEUTRAL": "Dress up as your favorite Minecraft characters from this striking 5th collection.",
          "neutral": "Dress up as your favorite Minecraft characters from this striking 5th collection."
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["xboxone.store"],
        "Tags": [
          "80c85890-dad7-4d3a-b2ef-60071327b7cf",
          "cc59b688-7cfb-4fa0-a76e-84aa55b92cae",
          "skinpack"
        ],
        "CreationDate": "2025-10-27T10:00:00Z",
        "LastModifiedDate": "2025-10-27T10:00:00Z",
        "Images": [
          {
            "Id": "2211bea0-8a75-4150-a548-9ccaa2f9f246",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://www.4jstudios.com/wp-content/uploads/2022/09/skinpack5_Thumbnail_0.jpg"
          }
        ],
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "80c85890-dad7-4d3a-b2ef-60071327b7cf",
          "originalCreatorId": "2535448579972708",
          "price": -1,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "cc59b688-7cfb-4fa0-a76e-84aa55b92cae",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"0037a29f-876e-4709-8bb8-a388738e6f51", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "4c61b1f5-2bbc-492f-8a2a-1f3b813c4113",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Skin Pack 6",
          "neutral": "Skin Pack 6"
        },
        "Description": {
          "NEUTRAL": "A cool assortment of amazing characters is ready for you in this wonderful 6th collection. Don’t miss out!",
          "neutral": "A cool assortment of amazing characters is ready for you in this wonderful 6th collection. Don’t miss out!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["xboxone.store"],
        "Tags": [
          "4c61b1f5-2bbc-492f-8a2a-1f3b813c4113",
          "0037a29f-876e-4709-8bb8-a388738e6f51",
          "skinpack"
        ],
        "CreationDate": "2025-10-27T10:00:00Z",
        "LastModifiedDate": "2025-10-27T10:00:00Z",
        "Images": [
          {
            "Id": "2211bea0-8a75-4150-a548-9ccaa2f9f246",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://www.4jstudios.com/wp-content/uploads/2022/09/skinpack6_Thumbnail_0.jpg"
          }
        ],
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "4c61b1f5-2bbc-492f-8a2a-1f3b813c4113",
          "originalCreatorId": "2535448579972708",
          "price": -1,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "0037a29f-876e-4709-8bb8-a388738e6f51",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"93b450c2-910f-4915-894d-444dde7a3306", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "f60ed293-2f4c-46e5-92b3-922a95df2dd6",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "853b0946-31b5-4c8a-87a4-72bf7bf21da5"
          }
        ],
        "Title": {
          "en-US": "Stranger Things Skin Pack",
          "NEUTRAL": "Stranger Things Skin Pack",
          "neutral": "Stranger Things Skin Pack"
        },
        "Description": {
          "en-US": "Something is coming, something hungry for blood. A shadow grows on the wall behind you, swallowing you in darkness. It is almost here… Boom! Stranger Things comes to Minecraft! Join Mike, Dustin, Lucas, Will, Eleven, Joyce, Hopper and many more as they survive monsters, adolescence and 80's fashion choices.",
          "NEUTRAL": "Something is coming, something hungry for blood. A shadow grows on the wall behind you, swallowing you in darkness. It is almost here… Boom! Stranger Things comes to Minecraft! Join Mike, Dustin, Lucas, Will, Eleven, Joyce, Hopper and many more as they survive monsters, adolescence and 80's fashion choices.",
          "neutral": "Something is coming, something hungry for blood. A shadow grows on the wall behind you, swallowing you in darkness. It is almost here… Boom! Stranger Things comes to Minecraft! Join Mike, Dustin, Lucas, Will, Eleven, Joyce, Hopper and many more as they survive monsters, adolescence and 80's fashion choices."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Horror", "Holiday"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Horror", "Holiday"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Horror", "Holiday"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla"
        ],
        "Tags": [
          "f60ed293-2f4c-46e5-92b3-922a95df2dd6",
          "93b450c2-910f-4915-894d-444dde7a3306",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.survival",
          "tag.skin",
          "tag.horror",
          "tag.holiday",
          "video_trailer",
          "1P"
        ],
        "CreationDate": "2018-07-31T21:02:25.003Z",
        "LastModifiedDate": "2023-08-10T12:27:28.544Z",
        "Contents": [],
        "Images": [
          {
            "Id": "ce618cfc-b99d-4376-9bd6-a57030898356",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/pf-title-b63a0803d3653643-20ca2/ce618cfc-b99d-4376-9bd6-a57030898356/StrangerThings_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "ad973453-8f09-48a2-bf95-6003b88e73fa",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.8,
          "TotalCount": 25457,
          "Count5Star": 22777,
          "Count4Star": 1145,
          "Count3Star": 432,
          "Count2Star": 175,
          "Count1Star": 928
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "853b0946-31b5-4c8a-87a4-72bf7bf21da5",
          "originalCreatorId": "2535448579972708",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "93b450c2-910f-4915-894d-444dde7a3306",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 52
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "lastUpdated": "1.17.30",
          "videoUrl": "https://www.youtube.com/watch?v=Vin5fjzjRww"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"5fe3e01c-609b-497e-b17e-342b83281369", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "358a8710-bcf4-4cd7-ae86-a63ffec500c8",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Summer of Arcade Skin Pack",
          "neutral": "Summer of Arcade Skin Pack"
        },
        "Description": {
          "NEUTRAL": "Customize your character with this selection of stunning skins celebrating the great games in the Summer of Arcade 2012 promotion; Tony Hawk's Pro Skater HD, Wreckateer, Deadlight, Hybrid, Dust: An Elysian Tail.",
          "neutral": "Customize your character with this selection of stunning skins celebrating the great games in the Summer of Arcade 2012 promotion; Tony Hawk's Pro Skater HD, Wreckateer, Deadlight, Hybrid, Dust: An Elysian Tail."
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "358a8710-bcf4-4cd7-ae86-a63ffec500c8",
          "5fe3e01c-609b-497e-b17e-342b83281369",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-03-01T06:09:45Z",
        "LastModifiedDate": "2026-03-01T06:09:45Z",
        "DisplayProperties": {
          "creatorName": "MinecraftHidden",
          "offerId": "358a8710-bcf4-4cd7-ae86-a63ffec500c8",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "5fe3e01c-609b-497e-b17e-342b83281369",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"4f4a0dfa-6e3a-4a2b-bad1-eb84b1b76ee9", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "39ddc16e-e398-4c71-b562-75b2ac5b1319",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "04e8961b-4573-4233-9e5e-aec388236314"
          }
        ],
        "Title": {
          "en-US": "The Simpsons Skin Pack",
          "NEUTRAL": "The Simpsons Skin Pack",
          "neutral": "The Simpsons Skin Pack"
        },
        "Description": {
          "en-US": "The Simpsons as you have never seen them before; in pure, unadulterated Minecraft block-o-vision! Don't miss out this awesome pack featuring 24 characters from the series.",
          "NEUTRAL": "The Simpsons as you have never seen them before; in pure, unadulterated Minecraft block-o-vision! Don't miss out this awesome pack featuring 24 characters from the series.",
          "neutral": "The Simpsons as you have never seen them before; in pure, unadulterated Minecraft block-o-vision! Don't miss out this awesome pack featuring 24 characters from the series."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Action", "Comedy", "Cartoon", "Animation"]
          },
          "NEUTRAL": {
            "Values": ["Action", "Comedy", "Cartoon", "Animation"]
          },
          "neutral": {
            "Values": ["Action", "Comedy", "Cartoon", "Animation"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["xboxone.store", "", "title.bedrockvanilla"],
        "Tags": [
          "39ddc16e-e398-4c71-b562-75b2ac5b1319",
          "4f4a0dfa-6e3a-4a2b-bad1-eb84b1b76ee9",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.action",
          "tag.comedy",
          "tag.cartoon",
          "tag.animation",
          "1P"
        ],
        "CreationDate": "2018-07-31T21:01:17.848Z",
        "LastModifiedDate": "2023-08-09T20:52:19.305Z",
        "Contents": [],
        "Images": [
          {
            "Id": "5d180df6-b118-4c66-8700-3c119809a1d8",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets002.xboxlive.com/serviceid-18231953-4b1d-472c-a39e-48b10105b7b7-public/5d180df6-b118-4c66-8700-3c119809a1d8/simpsons_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "b960effc-0cbf-4051-95ca-299a82d32792",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.3,
          "TotalCount": 2377,
          "Count5Star": 1800,
          "Count4Star": 132,
          "Count3Star": 109,
          "Count2Star": 38,
          "Count1Star": 298
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "04e8961b-4573-4233-9e5e-aec388236314",
          "originalCreatorId": "2535448579972708",
          "price": -1,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "4f4a0dfa-6e3a-4a2b-bad1-eb84b1b76ee9",
              "version": "3.11.26"
            }
          ],
          "skinPack": {
            "count": 24
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          }
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"202539ce-e6c5-40b5-a4a1-4296277d18f6", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "8e78a44d-0c1f-4ce2-826b-8bbc555012de",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "ebd5c3b4-eef1-408d-b483-e4b2bd5add12"
          }
        ],
        "Title": {
          "en-US": "1st Birthday Skin Pack",
          "NEUTRAL": "1st Birthday Skin Pack",
          "neutral": "1st Birthday Skin Pack"
        },
        "Description": {
          "en-US": "Join the Minecraft party now!",
          "NEUTRAL": "Join the Minecraft party now!",
          "neutral": "Join the Minecraft party now!"
        },
        "Keywords": {
          "en-US": {
            "Values": ["Skin", "Festival", "Survival"]
          },
          "NEUTRAL": {
            "Values": ["Skin", "Festival", "Survival"]
          },
          "neutral": {
            "Values": ["Skin", "Festival", "Survival"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "8e78a44d-0c1f-4ce2-826b-8bbc555012de",
          "202539ce-e6c5-40b5-a4a1-4296277d18f6",
          "skinpack",
          "has_skinpack",
          "tag.limited",
          "tag.skin",
          "tag.festival",
          "genre.survival",
          "1P"
        ],
        "CreationDate": "2018-07-31T20:55:01.99Z",
        "LastModifiedDate": "2023-08-10T03:32:11.7Z",
        "Contents": [],
        "Images": [
          {
            "Id": "b3292e60-9898-4813-869c-40b301b5ac0a",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/pf-title-b63a0803d3653643-20ca2/b3292e60-9898-4813-869c-40b301b5ac0a/1stBirthday_Thumbnail_0.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "d5e9ac7f-8c6c-4f47-97ec-3d9defc4f480",
            "Amount": 1
          }
        ],
        "Price": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 0
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 0
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "PriceOptions": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 0
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 0
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "Rating": {
          "Average": 4.7,
          "TotalCount": 533755,
          "Count5Star": 469435,
          "Count4Star": 28896,
          "Count3Star": 12638,
          "Count2Star": 5235,
          "Count1Star": 17551
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "price": 0,
          "purchasable": true,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "202539ce-e6c5-40b5-a4a1-4296277d18f6",
              "version": "3.1.26"
            }
          ],
          "skinPack": {
            "count": 23
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "lastUpdated": "1.16.210"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"d532b9b3-eddc-4f98-96fc-5fe5e227c426", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "770196c2-718f-43ef-94d6-8e53a7b5b0af",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "4af11277-e068-4e74-b0d9-ad3460397a5c"
          }
        ],
        "Title": {
          "en-US": "2nd Birthday Skin Pack - 2015",
          "NEUTRAL": "2nd Birthday Skin Pack - 2015",
          "neutral": "2nd Birthday Skin Pack - 2015"
        },
        "Description": {
          "en-US": "Minecraft is growing up, time to celebrate together our 2nd Birthday!\r\nOnly available for Minecraft on PlayStation 4 (2019).",
          "NEUTRAL": "Minecraft is growing up, time to celebrate together our 2nd Birthday!\r\nOnly available for Minecraft on PlayStation 4 (2019).",
          "neutral": "Minecraft is growing up, time to celebrate together our 2nd Birthday!\r\nOnly available for Minecraft on PlayStation 4 (2019)."
        },
        "Keywords": {
          "en-US": {
            "Values": ["Survival", "Skin", "Holiday"]
          },
          "NEUTRAL": {
            "Values": ["Survival", "Skin", "Holiday"]
          },
          "neutral": {
            "Values": ["Survival", "Skin", "Holiday"]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": ["b.store", "title.bedrockvanilla"],
        "Tags": [
          "770196c2-718f-43ef-94d6-8e53a7b5b0af",
          "d532b9b3-eddc-4f98-96fc-5fe5e227c426",
          "skinpack",
          "has_skinpack",
          "hidden_offer",
          "genre.survival",
          "tag.skin",
          "tag.holiday",
          "1P"
        ],
        "CreationDate": "2019-12-10T17:47:04.166Z",
        "LastModifiedDate": "2024-10-16T01:32:02.324Z",
        "Contents": [],
        "Images": [
          {
            "Id": "2cb9d7f6-6b3d-445e-a323-d28522959a95",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/pf-title-b63a0803d3653643-20ca2/2cb9d7f6-6b3d-445e-a323-d28522959a95/Skinpack_2ndBirthday_Sony_thumbnail_800x450.jpg"
          }
        ],
        "ItemReferences": [
          {
            "Id": "d9caea4e-2149-4249-925c-9ab216046eca",
            "Amount": 1
          }
        ],
        "Rating": {
          "Average": 4.6,
          "TotalCount": 10503,
          "Count5Star": 8759,
          "Count4Star": 665,
          "Count3Star": 351,
          "Count2Star": 120,
          "Count1Star": 608
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "4af11277-e068-4e74-b0d9-ad3460397a5c",
          "originalCreatorId": "2535448579972708",
          "price": 0,
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "d532b9b3-eddc-4f98-96fc-5fe5e227c426",
              "version": "3.1.26"
            }
          ],
          "skinPack": {
            "count": 24
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "lastUpdated": "1.14.30"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"f2c9ef8d-690b-41df-9682-d85225774b77", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "SourceEntity": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "SourceEntityKey": {
          "Id": "B63A0803D3653643",
          "Type": "namespace",
          "TypeString": "namespace"
        },
        "Id": "32c1ef67-3cb2-4094-bd0d-92eb55b5ad75",
        "Type": "bundle",
        "AlternateIds": [
          {
            "Type": "FriendlyId",
            "Value": "14db4920-2713-48eb-b465-e15a9d9750cf"
          }
        ],
        "Title": {
          "en-US": "Greek Mythology Mash-up",
          "NEUTRAL": "Greek Mythology Mash-up",
          "neutral": "Greek Mythology Mash-up"
        },
        "Description": {
          "en-US": "Build a pantheon fit for the gods, trap the Minotaur in an elaborate maze, or set sail for adventures across the sea. The world is your square oyster!",
          "NEUTRAL": "Build a pantheon fit for the gods, trap the Minotaur in an elaborate maze, or set sail for adventures across the sea. The world is your square oyster!",
          "neutral": "Build a pantheon fit for the gods, trap the Minotaur in an elaborate maze, or set sail for adventures across the sea. The world is your square oyster!"
        },
        "Keywords": {
          "en-US": {
            "Values": [
              "Exploration",
              "Mythology",
              "Historical",
              "Survival",
              "Open World"
            ]
          },
          "NEUTRAL": {
            "Values": [
              "Exploration",
              "Mythology",
              "Historical",
              "Survival",
              "Open World"
            ]
          },
          "neutral": {
            "Values": [
              "Exploration",
              "Mythology",
              "Historical",
              "Survival",
              "Open World"
            ]
          }
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "CreatorEntityKey": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "CreatorEntity": {
          "Id": "301F442C3B63DC20",
          "Type": "master_player_account",
          "TypeString": "master_player_account"
        },
        "IsStackable": false,
        "Platforms": [
          "android.amazonappstore",
          "android.googleplay",
          "b.store",
          "ios.store",
          "nx.store",
          "oculus.store.gearvr",
          "oculus.store.rift",
          "uwp.store",
          "uwp.store.mobile",
          "xboxone.store",
          "title.bedrockvanilla",
          "title.earth"
        ],
        "Tags": [
          "32c1ef67-3cb2-4094-bd0d-92eb55b5ad75",
          "f2c9ef8d-690b-41df-9682-d85225774b77",
          "98330b0a-2c79-4d30-b9c8-136098340edc",
          "e8ad3b41-ddd3-4247-907b-090419cdb7ca",
          "tag.exploration",
          "tag.mythology",
          "tag.historical",
          "1P",
          "mashup",
          "has_skinpack",
          "survival_spawn_world",
          "genre.survival",
          "subgenre.open_world",
          "playercount.1-4"
        ],
        "CreationDate": "2018-07-31T20:52:57.342Z",
        "LastModifiedDate": "2025-12-13T01:01:15.674Z",
        "Contents": [],
        "Images": [
          {
            "Id": "82ee5e9c-6822-43c5-a326-5fbabe7e10f2",
            "Tag": "Thumbnail",
            "Type": "Thumbnail",
            "Url": "https://xforgeassets001.xboxlive.com/pf-namespace-b63a0803d3653643/82ee5e9c-6822-43c5-a326-5fbabe7e10f2/GreekMythology_thumbnail_800x450.jpg"
          }
        ],
        "ItemReferences": [
          { "Id": "c15fbfa2-e5c4-44b3-9e62-32b61cf945bf", "Amount": 1 },
          { "Id": "8cd67c8e-9765-4e78-a522-e333ec418f7e", "Amount": 1 },
          { "Id": "36758df7-84d0-49bd-9290-b4eab4b0c025", "Amount": 1 }
        ],
        "Price": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 990
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 990
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "PriceOptions": {
          "Prices": [
            {
              "Amounts": [
                {
                  "CurrencyId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Id": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "ItemId": "ecd19d3c-7635-402c-a185-eb11cb6c6946",
                  "Amount": 990
                }
              ]
            },
            {
              "Amounts": [
                {
                  "CurrencyId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Id": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "ItemId": "0113e233-7637-48e7-91b0-349fdc74713d",
                  "Amount": 990
                }
              ]
            }
          ],
          "RealPrices": []
        },
        "Rating": {
          "Average": 4.4,
          "TotalCount": 63859,
          "Count5Star": 47459,
          "Count4Star": 6263,
          "Count3Star": 3212,
          "Count2Star": 1162,
          "Count1Star": 5763
        },
        "DeepLinks": [],
        "DisplayProperties": {
          "creatorName": "Minecraft",
          "offerId": "14db4920-2713-48eb-b465-e15a9d9750cf",
          "originalCreatorId": "2535448579972708",
          "price": 990,
          "purchasable": true,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "f2c9ef8d-690b-41df-9682-d85225774b77",
              "version": "3.3.26"
            },
            {
              "type": "resourcepack",
              "uuid": "98330b0a-2c79-4d30-b9c8-136098340edc",
              "version": "1.0.79"
            },
            {
              "type": "worldtemplate",
              "uuid": "e8ad3b41-ddd3-4247-907b-090419cdb7ca",
              "version": "1.0.79"
            }
          ],
          "skinPack": {
            "count": 39,
            "sampleSkins": [
              { "localizationName": "Atalanta", "skinIndex": 0 },
              { "localizationName": "Hephaestus", "skinIndex": 1 }
            ]
          },
          "publicChangelog": {
            "neutral": "",
            "en-US": "",
            "bg-BG": "",
            "cs-CZ": "",
            "da-DK": "",
            "de-DE": "",
            "el-GR": "",
            "en-GB": "",
            "es-ES": "",
            "es-MX": "",
            "fi-FI": "",
            "fr-CA": "",
            "fr-FR": "",
            "hu-HU": "",
            "id-ID": "",
            "it-IT": "",
            "ja-JP": "",
            "ko-KR": "",
            "nb-NO": "",
            "nl-NL": "",
            "pl-PL": "",
            "pt-BR": "",
            "pt-PT": "",
            "ru-RU": "",
            "sk-SK": "",
            "sv-SE": "",
            "tr-TR": "",
            "uk-UA": "",
            "zh-CN": "",
            "zh-TW": ""
          },
          "hardwareMemoryTier": 0
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"4c7836bf-ea15-46ec-9868-33fe9b455631", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "b1026ea3-1c85-492d-aa01-21a1d51829fe",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Alleis Skin Pack",
          "neutral": "Alleis Skin Pack"
        },
        "Description": {
          "NEUTRAL": "Customize your character with over 150 skins from various franchises, like Super Mario, Super Smash Bros., Minecraft Legends, and more!\n\nSkins with YELLOW names work on some featured servers, like The Hive.\nOther skins use fully-custom models and likely will not work on featured servers.",
          "neutral": "Customize your character with over 150 skins from various franchises, like Super Mario, Super Smash Bros., Minecraft Legends, and more!\n\nSkins with YELLOW names work on some featured servers, like The Hive.\nOther skins use fully-custom models and likely will not work on featured servers."
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "b1026ea3-1c85-492d-aa01-21a1d51829fe",
          "4c7836bf-ea15-46ec-9868-33fe9b455631",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-07-07T02:33:34Z",
        "LastModifiedDate": "2026-07-07T02:33:34Z",
        "DisplayProperties": {
          "creatorName": "Alleis Elis",
          "offerId": "b1026ea3-1c85-492d-aa01-21a1d51829fe",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "4c7836bf-ea15-46ec-9868-33fe9b455631",
              "version": "1.3.8"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
})COSMOS"},
  {"262c9840-c332-48d2-b62f-6c19ad0f7aa6", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "8713ccc6-b61f-4d3a-9719-02b4c670967d",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Alleis Slop Pack",
          "neutral": "Alleis Slop Pack"
        },
        "Description": {
          "NEUTRAL": "A companion piece to the Alleis Skin Pack, which includes normal skins and other previously-unreleased skins!",
          "neutral": "A companion piece to the Alleis Skin Pack, which includes normal skins and other previously-unreleased skins!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "8713ccc6-b61f-4d3a-9719-02b4c670967d",
          "262c9840-c332-48d2-b62f-6c19ad0f7aa6",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-08-16T06:53:12Z",
        "LastModifiedDate": "2026-08-16T06:53:12Z",
        "DisplayProperties": {
          "creatorName": "Alleis Elis",
          "offerId": "8713ccc6-b61f-4d3a-9719-02b4c670967d",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "262c9840-c332-48d2-b62f-6c19ad0f7aa6",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
})COSMOS"},
  {"60d6c1f6-ba2c-4086-ae92-bb46f90f3b74", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "ee2e819d-323d-4245-b2a5-b679ae961402",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Various Girls",
          "neutral": "Various Girls"
        },
        "Description": {
          "NEUTRAL": "Transform your look with 12 different girl skins!\\nIncludes 5 Normal Skins, 2 Custom Geometry Skins, and 5 Hive Cosmetics!",
          "neutral": "Transform your look with 12 different girl skins!\\nIncludes 5 Normal Skins, 2 Custom Geometry Skins, and 5 Hive Cosmetics!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "ee2e819d-323d-4245-b2a5-b679ae961402",
          "60d6c1f6-ba2c-4086-ae92-bb46f90f3b74",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-06-17T07:17:02Z",
        "LastModifiedDate": "2026-06-17T07:17:02Z",
        "DisplayProperties": {
          "creatorName": "Alleis Elis",
          "offerId": "ee2e819d-323d-4245-b2a5-b679ae961402",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "60d6c1f6-ba2c-4086-ae92-bb46f90f3b74",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
})COSMOS"},
  {"342df268-636d-4f2b-a971-8350eb4fc440", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "1dafe8e5-aacc-4518-98ed-f6ce66bfba80",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "6th Birthday Skin Pack",
          "neutral": "6th Birthday Skin Pack"
        },
        "Description": {
          "NEUTRAL": "A twist on Minecraft's 1st Birthday Skin Pack with 23 brand new skins to select from!\r\n\r\nCreator's Note: This pack was mostly made for fun (partially jokingly) back in 2021. I had not previously published it before, but now it is free to use in Bedrock Cosmos!",
          "neutral": "A twist on Minecraft's 1st Birthday Skin Pack with 23 brand new skins to select from!\r\n\r\nCreator's Note: This pack was mostly made for fun (partially jokingly) back in 2021. I had not previously published it before, but now it is free to use in Bedrock Cosmos!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "1dafe8e5-aacc-4518-98ed-f6ce66bfba80",
          "342df268-636d-4f2b-a971-8350eb4fc440",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-02-28T19:08:03Z",
        "LastModifiedDate": "2026-02-28T19:08:03Z",
        "DisplayProperties": {
          "creatorName": "BionicBen",
          "offerId": "1dafe8e5-aacc-4518-98ed-f6ce66bfba80",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "342df268-636d-4f2b-a971-8350eb4fc440",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"248868b1-e260-4434-b56b-b41a48f57b91", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "aa8a18de-f2b0-40be-bc70-c4cd9dd6ae62",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "BionicBen Skin Pack",
          "neutral": "BionicBen Skin Pack"
        },
        "Description": {
          "NEUTRAL": "A skin pack containing a variety of BionicBen's skins throughout his YouTube history - from holiday skins to the infamous mega skin!\r\n\r\nCreator's Note: The mega skins and skins with HD capes included in this skin pack may not work on featured servers.",
          "neutral": "A skin pack containing a variety of BionicBen's skins throughout his YouTube history - from holiday skins to the infamous mega skin!\r\n\r\nCreator's Note: The mega skins and skins with HD capes included in this skin pack may not work on featured servers."
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "aa8a18de-f2b0-40be-bc70-c4cd9dd6ae62",
          "248868b1-e260-4434-b56b-b41a48f57b91",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-02-28T19:10:41Z",
        "LastModifiedDate": "2026-02-28T19:10:41Z",
        "DisplayProperties": {
          "creatorName": "BionicBen",
          "offerId": "aa8a18de-f2b0-40be-bc70-c4cd9dd6ae62",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "248868b1-e260-4434-b56b-b41a48f57b91",
              "version": "1.0.2"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"aa5e26c6-9032-487e-9ed5-a6b99d68ba98", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "aa0b65fd-8cfe-43dc-a7c0-c306757fe1a3",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Deadmau5 Skin Pack",
          "neutral": "Deadmau5 Skin Pack"
        },
        "Description": {
          "NEUTRAL": "Party hard with 11 uniquely-colored deadmau5 skins, each with their own pair of exclusive ears from Minecraft Java Edition! Original blue and red deadmau5 skins made by deadmau5 and Mojang.",
          "neutral": "Party hard with 11 uniquely-colored deadmau5 skins, each with their own pair of exclusive ears from Minecraft Java Edition! Original blue and red deadmau5 skins made by deadmau5 and Mojang."
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "aa0b65fd-8cfe-43dc-a7c0-c306757fe1a3",
          "aa5e26c6-9032-487e-9ed5-a6b99d68ba98",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-04-21T02:59:15Z",
        "LastModifiedDate": "2026-04-21T02:59:15Z",
        "DisplayProperties": {
          "creatorName": "BionicBen",
          "offerId": "aa0b65fd-8cfe-43dc-a7c0-c306757fe1a3",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "aa5e26c6-9032-487e-9ed5-a6b99d68ba98",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"a8822913-5c64-4a73-bf8b-b1713a4434b2", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "0ce8d2eb-d178-4ae9-8060-00fd9714c93b",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Project Star Skin Pack",
          "neutral": "Project Star Skin Pack"
        },
        "Description": {
          "NEUTRAL": "A skin pack previously made for the Project Star Launcher. This pack contains Steve and Alex in Project Star attire and 11 uniquely-colored capes!",
          "neutral": "A skin pack previously made for the Project Star Launcher. This pack contains Steve and Alex in Project Star attire and 11 uniquely-colored capes!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "0ce8d2eb-d178-4ae9-8060-00fd9714c93b",
          "a8822913-5c64-4a73-bf8b-b1713a4434b2",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-02-28T19:13:18Z",
        "LastModifiedDate": "2026-02-28T19:13:18Z",
        "DisplayProperties": {
          "creatorName": "BionicBen",
          "offerId": "0ce8d2eb-d178-4ae9-8060-00fd9714c93b",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "a8822913-5c64-4a73-bf8b-b1713a4434b2",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"51bb5ca4-77b9-4e9d-8c90-992b61d94c0d", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "22688cde-3822-4bd8-9638-625713ba4dfd",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "EMC1",
          "neutral": "EMC1"
        },
        "Description": {
          "NEUTRAL": "Express yourself in game with a friend or partner using the 30 skins in this first skin pack!",
          "neutral": "Express yourself in game with a friend or partner using the 30 skins in this first skin pack!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "22688cde-3822-4bd8-9638-625713ba4dfd",
          "51bb5ca4-77b9-4e9d-8c90-992b61d94c0d",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-02-27T21:47:48Z",
        "LastModifiedDate": "2026-02-27T21:47:48Z",
        "DisplayProperties": {
          "creatorName": "Exports",
          "offerId": "22688cde-3822-4bd8-9638-625713ba4dfd",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "51bb5ca4-77b9-4e9d-8c90-992b61d94c0d",
              "version": "1.0.0"
            }
          ],
          "videoUrl": "https://www.youtube.com/watch?v=jDdXPw8ehZY"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"6d111aff-3c61-4e8c-a0b3-5da38332430c", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "a045e0ba-b58e-44d5-b463-e8968f28ae99",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "EMC2",
          "neutral": "EMC2"
        },
        "Description": {
          "NEUTRAL": "Express yourself in game with a friend or partner using the 30 skins in this second skin pack!",
          "neutral": "Express yourself in game with a friend or partner using the 30 skins in this second skin pack!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "a045e0ba-b58e-44d5-b463-e8968f28ae99",
          "6d111aff-3c61-4e8c-a0b3-5da38332430c",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-03-01T13:34:48Z",
        "LastModifiedDate": "2026-03-01T13:34:48Z",
        "DisplayProperties": {
          "creatorName": "Exports",
          "offerId": "a045e0ba-b58e-44d5-b463-e8968f28ae99",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "6d111aff-3c61-4e8c-a0b3-5da38332430c",
              "version": "1.0.0"
            }
          ],
          "videoUrl": "https://www.youtube.com/watch?v=cgrhwL2inRw"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"0484ef22-b675-4468-b58d-699890b377b1", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "2d43de6c-6846-4cdc-a43b-55f8627b7b01",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "EMC3",
          "neutral": "EMC3"
        },
        "Description": {
          "NEUTRAL": "Express yourself in game with a friend or partner using the 30 skins in this third skin pack!",
          "neutral": "Express yourself in game with a friend or partner using the 30 skins in this third skin pack!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "2d43de6c-6846-4cdc-a43b-55f8627b7b01",
          "0484ef22-b675-4468-b58d-699890b377b1",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-03-01T13:33:47Z",
        "LastModifiedDate": "2026-03-01T13:33:47Z",
        "DisplayProperties": {
          "creatorName": "Exports",
          "offerId": "2d43de6c-6846-4cdc-a43b-55f8627b7b01",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "0484ef22-b675-4468-b58d-699890b377b1",
              "version": "1.0.0"
            }
          ],
          "videoUrl": "https://www.youtube.com/watch?v=ZmeyYheOC_k"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"2291990c-6b7a-42d8-ad13-c1b490b9e1f6", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "d1c19132-0b7d-453d-b39b-5b06a5fb30f9",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "EMC4",
          "neutral": "EMC4"
        },
        "Description": {
          "NEUTRAL": "Express yourself in game with a friend or partner using the 30 skins in this fourth skin pack!",
          "neutral": "Express yourself in game with a friend or partner using the 30 skins in this fourth skin pack!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "d1c19132-0b7d-453d-b39b-5b06a5fb30f9",
          "2291990c-6b7a-42d8-ad13-c1b490b9e1f6",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-03-01T13:32:10Z",
        "LastModifiedDate": "2026-03-01T13:32:10Z",
        "DisplayProperties": {
          "creatorName": "Exports",
          "offerId": "d1c19132-0b7d-453d-b39b-5b06a5fb30f9",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "2291990c-6b7a-42d8-ad13-c1b490b9e1f6",
              "version": "1.0.0"
            }
          ],
          "videoUrl": "https://www.youtube.com/watch?v=eL5Sg009y0c"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"1ea3fef7-eea7-4413-ac90-13e053ea4cea", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "a2a191a7-ad0d-4802-a990-975538c7489f",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Matching Cosmetics 5",
          "neutral": "Matching Cosmetics 5"
        },
        "Description": {
          "NEUTRAL": "Express yourself in game with a friend or partner using the 30 skins in this fifth skin pack!",
          "neutral": "Express yourself in game with a friend or partner using the 30 skins in this fifth skin pack!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "a2a191a7-ad0d-4802-a990-975538c7489f",
          "1ea3fef7-eea7-4413-ac90-13e053ea4cea",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-04-21T03:02:31Z",
        "LastModifiedDate": "2026-04-21T03:02:31Z",
        "DisplayProperties": {
          "creatorName": "Exports",
          "offerId": "a2a191a7-ad0d-4802-a990-975538c7489f",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "1ea3fef7-eea7-4413-ac90-13e053ea4cea",
              "version": "1.0.0"
            }
          ],
          "videoUrl": "https://www.youtube.com/watch?v=5QzSKjJZYdY"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"ff1018de-be33-4ce9-a131-f94d0c2abb2e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "7a92c69c-d1c8-4c00-b3a2-cd9c7e650148",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Matching Cosmetics 6",
          "neutral": "Matching Cosmetics 6"
        },
        "Description": {
          "NEUTRAL": "Express yourself in game with a friend or partner using the 30 skins in this sixth skin pack!",
          "neutral": "Express yourself in game with a friend or partner using the 30 skins in this sixth skin pack!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "7a92c69c-d1c8-4c00-b3a2-cd9c7e650148",
          "ff1018de-be33-4ce9-a131-f94d0c2abb2e",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-04-21T03:02:31Z",
        "LastModifiedDate": "2026-04-21T03:02:31Z",
        "DisplayProperties": {
          "creatorName": "Exports",
          "offerId": "7a92c69c-d1c8-4c00-b3a2-cd9c7e650148",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "ff1018de-be33-4ce9-a131-f94d0c2abb2e",
              "version": "1.0.0"
            }
          ],
          "videoUrl": "https://www.youtube.com/watch?v=f7fROv6DC9Q"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"b6733994-4772-41a1-9dfb-c445d24048c7", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "dfc5ace1-fd1c-414c-8b1f-ec34e1bf7ba8",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Matching Cosmetics 7",
          "neutral": "Matching Cosmetics 7"
        },
        "Description": {
          "NEUTRAL": "Express yourself in game with a friend or partner using the 30 skins in this seventh skin pack!",
          "neutral": "Express yourself in game with a friend or partner using the 30 skins in this seventh skin pack!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "dfc5ace1-fd1c-414c-8b1f-ec34e1bf7ba8",
          "b6733994-4772-41a1-9dfb-c445d24048c7",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-04-21T03:02:31Z",
        "LastModifiedDate": "2026-04-21T03:02:31Z",
        "DisplayProperties": {
          "creatorName": "Exports",
          "offerId": "dfc5ace1-fd1c-414c-8b1f-ec34e1bf7ba8",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "b6733994-4772-41a1-9dfb-c445d24048c7",
              "version": "1.0.0"
            }
          ],
          "videoUrl": "https://www.youtube.com/watch?v=HAq6dFby9vg"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"cd99e175-5498-4edf-8bb2-ab29cbfc00b9", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "0b18e5e0-9b6f-452b-9e89-1d3a9f6f95be",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Matching Cosmetics 8",
          "neutral": "Matching Cosmetics 8"
        },
        "Description": {
          "NEUTRAL": "Express yourself in game with a friend or partner using the 30 skins in this eighth skin pack!",
          "neutral": "Express yourself in game with a friend or partner using the 30 skins in this eighth skin pack!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "0b18e5e0-9b6f-452b-9e89-1d3a9f6f95be",
          "cd99e175-5498-4edf-8bb2-ab29cbfc00b9",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-04-21T03:02:31Z",
        "LastModifiedDate": "2026-04-21T03:02:31Z",
        "DisplayProperties": {
          "creatorName": "Exports",
          "offerId": "0b18e5e0-9b6f-452b-9e89-1d3a9f6f95be",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "cd99e175-5498-4edf-8bb2-ab29cbfc00b9",
              "version": "1.0.0"
            }
          ],
          "videoUrl": "https://www.youtube.com/watch?v=mb1r-t64Fjw"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"5fe7c32b-fd56-44ba-b2a1-a549cccc17fd", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "fc4de45c-9d1c-4909-87be-6e3366a857ba",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Matching Cosmetics 9",
          "neutral": "Matching Cosmetics 9"
        },
        "Description": {
          "NEUTRAL": "Express yourself in game with a friend or partner using the 30 skins in this ninth skin pack!",
          "neutral": "Express yourself in game with a friend or partner using the 30 skins in this ninth skin pack!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "fc4de45c-9d1c-4909-87be-6e3366a857ba",
          "5fe7c32b-fd56-44ba-b2a1-a549cccc17fd",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-08-16T06:50:14Z",
        "LastModifiedDate": "2026-08-16T06:50:14Z",
        "DisplayProperties": {
          "creatorName": "Exports",
          "offerId": "fc4de45c-9d1c-4909-87be-6e3366a857ba",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "5fe7c32b-fd56-44ba-b2a1-a549cccc17fd",
              "version": "1.0.0"
            }
          ],
          "videoUrl": "https://www.youtube.com/watch?v=j2Djo_VPous"
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
})COSMOS"},
  {"8d4eb2f0-d468-4e64-a485-06e948caed48", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "43132398-078d-4a7f-b6b9-5ae469f1e727",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Casual Knights Skin Pack",
          "neutral": "Casual Knights Skin Pack"
        },
        "Description": {
          "NEUTRAL": "A fun skin pack containing an assortment of medieval skins!",
          "neutral": "A fun skin pack containing an assortment of medieval skins!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "43132398-078d-4a7f-b6b9-5ae469f1e727",
          "8d4eb2f0-d468-4e64-a485-06e948caed48",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-08-18T20:03:13Z",
        "LastModifiedDate": "2026-08-18T20:03:13Z",
        "DisplayProperties": {
          "creatorName": "Mono",
          "offerId": "43132398-078d-4a7f-b6b9-5ae469f1e727",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "8d4eb2f0-d468-4e64-a485-06e948caed48",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
})COSMOS"},
  {"d3fabdf1-3e91-4903-ac95-db2b2d752f8e", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "74694ab4-178f-4c60-a0dd-96ec4627390e",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "SRG's Voxel Skin Pack",
          "neutral": "SRG's Voxel Skin Pack"
        },
        "Description": {
          "NEUTRAL": "Pixel art comes to life in this skin pack, with over 70 voxelated characters available to choose from!",
          "neutral": "Pixel art comes to life in this skin pack, with over 70 voxelated characters available to choose from!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "74694ab4-178f-4c60-a0dd-96ec4627390e",
          "d3fabdf1-3e91-4903-ac95-db2b2d752f8e",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-07-08T03:32:10Z",
        "LastModifiedDate": "2026-07-08T03:32:10Z",
        "DisplayProperties": {
          "creatorName": "SRG64",
          "offerId": "74694ab4-178f-4c60-a0dd-96ec4627390e",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "d3fabdf1-3e91-4903-ac95-db2b2d752f8e",
              "version": "1.3.1"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
})COSMOS"},
  {"f978adc0-729f-406d-bc0c-08cfbf5f9c30", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "b20dc966-1071-4845-a7a0-b0d2acb253ce",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "LEGO(R) Minecraft(TM) Skin Pack",
          "neutral": "LEGO(R) Minecraft(TM) Skin Pack"
        },
        "Description": {
          "NEUTRAL": "This skin pack contains over 100 player and mob skins from the official LEGO(R) Minecraft(TM) sets! These skins are also modeled to look just like the original LEGO(R) minifigures!",
          "neutral": "This skin pack contains over 100 player and mob skins from the official LEGO(R) Minecraft(TM) sets! These skins are also modeled to look just like the original LEGO(R) minifigures!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "b20dc966-1071-4845-a7a0-b0d2acb253ce",
          "f978adc0-729f-406d-bc0c-08cfbf5f9c30",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-05-19T04:16:15Z",
        "LastModifiedDate": "2026-05-19T04:16:15Z",
        "DisplayProperties": {
          "creatorName": "YEH",
          "offerId": "b20dc966-1071-4845-a7a0-b0d2acb253ce",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "f978adc0-729f-406d-bc0c-08cfbf5f9c30",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
})COSMOS"},
  {"2f8d9fb8-c3c9-47d5-8460-e15da1a528fb", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "17c404b3-3979-49a3-93cb-3f53e2e33eb6",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "R.E.P.O SEMIBOTS",
          "neutral": "R.E.P.O SEMIBOTS"
        },
        "Description": {
          "NEUTRAL": "Enjoy this cool R.E.P.O skin pack with 75 Semibots of different sizes and colors!",
          "neutral": "Enjoy this cool R.E.P.O skin pack with 75 Semibots of different sizes and colors!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "17c404b3-3979-49a3-93cb-3f53e2e33eb6",
          "2f8d9fb8-c3c9-47d5-8460-e15da1a528fb",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-04-06T10:04:12Z",
        "LastModifiedDate": "2026-04-06T10:04:12Z",
        "DisplayProperties": {
          "creatorName": "YEH",
          "offerId": "17c404b3-3979-49a3-93cb-3f53e2e33eb6",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "2f8d9fb8-c3c9-47d5-8460-e15da1a528fb",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"73d78fb2-9cd7-43bb-8f60-899f654761e1", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "86e6a53f-6ae6-4109-935a-72f877194c02",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "R.E.P.O SEMIBOTS: 5D",
          "neutral": "R.E.P.O SEMIBOTS: 5D"
        },
        "Description": {
          "NEUTRAL": "Enjoy this cool R.E.P.O skin pack with Semibots of different sizes and colors, now in \"5D\"!",
          "neutral": "Enjoy this cool R.E.P.O skin pack with Semibots of different sizes and colors, now in \"5D\"!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "86e6a53f-6ae6-4109-935a-72f877194c02",
          "73d78fb2-9cd7-43bb-8f60-899f654761e1",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-04-06T10:04:12Z",
        "LastModifiedDate": "2026-04-06T10:04:12Z",
        "DisplayProperties": {
          "creatorName": "YEH",
          "offerId": "86e6a53f-6ae6-4109-935a-72f877194c02",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "73d78fb2-9cd7-43bb-8f60-899f654761e1",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"ec24d5bb-c72d-4ca7-a684-4de5be42e126", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "b96ad5fb-f58c-4a92-bbbc-44bb9244e732",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Black Hole Skin Pack",
          "neutral": "Black Hole Skin Pack"
        },
        "Description": {
          "NEUTRAL": "-",
          "neutral": "-"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "b96ad5fb-f58c-4a92-bbbc-44bb9244e732",
          "ec24d5bb-c72d-4ca7-a684-4de5be42e126",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-04-14T18:49:56Z",
        "LastModifiedDate": "2026-04-14T18:49:56Z",
        "DisplayProperties": {
          "creatorName": "ZeroMISTER JA",
          "offerId": "b96ad5fb-f58c-4a92-bbbc-44bb9244e732",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "ec24d5bb-c72d-4ca7-a684-4de5be42e126",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"a7952402-135e-4f5d-abea-5b738904e2c4", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "dedd7dce-a317-4786-930f-9c2357d25d82",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Detective Conan Skin Pack",
          "neutral": "Detective Conan Skin Pack"
        },
        "Description": {
          "NEUTRAL": "A cubic Bedrock Edition port of the Detective Conan collaboration from Minecraft China Edition!",
          "neutral": "A cubic Bedrock Edition port of the Detective Conan collaboration from Minecraft China Edition!"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "dedd7dce-a317-4786-930f-9c2357d25d82",
          "a7952402-135e-4f5d-abea-5b738904e2c4",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-04-14T18:49:56Z",
        "LastModifiedDate": "2026-04-14T18:49:56Z",
        "DisplayProperties": {
          "creatorName": "ZeroMISTER JA",
          "offerId": "dedd7dce-a317-4786-930f-9c2357d25d82",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "a7952402-135e-4f5d-abea-5b738904e2c4",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"7489dfb0-f606-41fc-9bfb-c7ef396d8358", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "ae90416f-1942-4c2b-a675-8d947fc53cf1",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Doraemon Skin Pack",
          "neutral": "Doraemon Skin Pack"
        },
        "Description": {
          "NEUTRAL": "-",
          "neutral": "-"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "ae90416f-1942-4c2b-a675-8d947fc53cf1",
          "7489dfb0-f606-41fc-9bfb-c7ef396d8358",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-04-14T18:49:56Z",
        "LastModifiedDate": "2026-04-14T18:49:56Z",
        "DisplayProperties": {
          "creatorName": "ZeroMISTER JA",
          "offerId": "ae90416f-1942-4c2b-a675-8d947fc53cf1",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "7489dfb0-f606-41fc-9bfb-c7ef396d8358",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"b53d0382-a1e0-4707-9dd2-92ccae001033", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "7197503c-817f-4c5d-b570-67b2758d707b",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Hotel Transylvania Skin Pack",
          "neutral": "Hotel Transylvania Skin Pack"
        },
        "Description": {
          "NEUTRAL": "-",
          "neutral": "-"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "7197503c-817f-4c5d-b570-67b2758d707b",
          "b53d0382-a1e0-4707-9dd2-92ccae001033",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-04-14T18:49:56Z",
        "LastModifiedDate": "2026-04-14T18:49:56Z",
        "DisplayProperties": {
          "creatorName": "ZeroMISTER JA",
          "offerId": "7197503c-817f-4c5d-b570-67b2758d707b",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "b53d0382-a1e0-4707-9dd2-92ccae001033",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"863a125c-4fd6-413d-8f82-a3ab232e69ec", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "f6303374-6ab5-4079-baa0-6200189aa6a2",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Neon Genesis Evangelion Skin Pack",
          "neutral": "Neon Genesis Evangelion Skin Pack"
        },
        "Description": {
          "NEUTRAL": "-",
          "neutral": "-"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "f6303374-6ab5-4079-baa0-6200189aa6a2",
          "863a125c-4fd6-413d-8f82-a3ab232e69ec",
          "skinpack",
          "has_skinpack",
          "3P"
        ],
        "CreationDate": "2026-04-14T18:49:56Z",
        "LastModifiedDate": "2026-04-14T18:49:56Z",
        "DisplayProperties": {
          "creatorName": "ZeroMISTER JA",
          "offerId": "f6303374-6ab5-4079-baa0-6200189aa6a2",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "skinpack",
              "uuid": "863a125c-4fd6-413d-8f82-a3ab232e69ec",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
}
)COSMOS"},
  {"7b5cac88-d90d-483f-8e4e-e4e1aaa47787", R"COSMOS({
  "code": 200,
  "status": "OK",
  "data": {
    "Count": 1,
    "Items": [
      {
        "Id": "be094038-1e9b-42ca-b849-7c6345f2be50",
        "Type": "bundle",
        "Title": {
          "NEUTRAL": "Cape Physics",
          "neutral": "Cape Physics"
        },
        "ContentType": "MarketplaceDurableCatalog_V1.2",
        "Tags": [
          "be094038-1e9b-42ca-b849-7c6345f2be50",
          "7b5cac88-d90d-483f-8e4e-e4e1aaa47787",
          "3P"
        ],
        "CreationDate": "2026-06-03T03:16:16Z",
        "LastModifiedDate": "2026-06-03T03:16:16Z",
        "DisplayProperties": {
          "creatorName": "Xatalyst",
          "offerId": "be094038-1e9b-42ca-b849-7c6345f2be50",
          "purchasable": false,
          "packIdentity": [
            {
              "type": "resources",
              "uuid": "7b5cac88-d90d-483f-8e4e-e4e1aaa47787",
              "version": "1.0.0"
            }
          ]
        }
      }
    ],
    "ConfigurationName": "DEFAULT"
  }
})COSMOS"},
};
}
