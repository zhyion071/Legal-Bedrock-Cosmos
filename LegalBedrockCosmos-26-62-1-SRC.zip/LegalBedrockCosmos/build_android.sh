#!/usr/bin/env bash
set -euo pipefail
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to your NDK path}"
ABI="${ANDROID_ABI:-${1:-arm64-v8a}}"
PLATFORM="${ANDROID_PLATFORM:-android-24}"
ROOT="$(cd "$(dirname "$0")" && pwd)"
cmake -S "$ROOT" -B "$ROOT/build" \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI="$ABI" -DANDROID_PLATFORM="$PLATFORM" -DCMAKE_BUILD_TYPE=Release
cmake --build "$ROOT/build" --config Release -j"$(nproc)"
echo "Output: $ROOT/build/libLegalBedrockCosmos.so"
