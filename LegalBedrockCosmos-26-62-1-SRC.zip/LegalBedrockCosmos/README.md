# Legal Bedrock Cosmos — v1.3.12 source

LeviLauncher native mod source for Minecraft Bedrock 1.26.62.1. The native `com.xbox.httpclient` response bridge follows the user's working BedrockCosmosPortSRC reference, with Legal Bedrock Cosmos routes and embedded response data.

## Skin-pack route

Marketplace offer → `ItemDetail_<offer-id>` → selector using the actual `packIdentity.uuid` → viewer/skin data. Do not substitute the offer ID for the pack UUID.

## Cape catalogue in v1.3.12

This build keeps the prior user-requested removals (including One Vanilla from the Owned Capes row), and adds the requested seven Bedrock Cosmos capes plus all thirteen Oxynix capes to the main Creator Capes row and respective creator pages. Existing PlayFab cape fixtures are reused. The separate 100K Milestone Cape is not added. The vanilla heading is 56 to match its 56 entries.

## Inventory and ownership

The real Microsoft Marketplace player inventory/entitlement response is passed through unchanged. This mod does not fabricate or forward ownership/entitlement responses. Source offer metadata is preserved.

## Storage behavior

The native source does not create `/Android/media/org.levilauncher` and has no persistent file logger. Diagnostics go to Android logcat only.

## Build

Set `ANDROID_NDK_HOME` to an installed NDK and run:

```sh
bash build_android.sh arm64-v8a
```

Output: `build/libLegalBedrockCosmos.so`. Requires CMake 3.22+ and Android NDK r29 or compatible.

## Source files

- `src/libcapes.cpp`: native response bridge and route handling.
- `src/cosmos_bridge_dex.hpp`: embedded response bridge class.
- `src/*pages*.hpp`, `src/*skinpack*.hpp`, `src/playfab_*.hpp`: embedded response payloads.
- `assets/cosmos/`: source JSON response assets.
- `CREDITS.md`, `LICENSE.MD`: attribution and licensing.

This is a community mod, not affiliated with Microsoft or Mojang Studios. Minecraft is a Microsoft trademark.


## Added creator cape entries in v1.3.12

Adds the requested seven Bedrock Cosmos capes and all thirteen Oxynix capes to the main Creator Capes list and the corresponding creator pages. The existing GetPublishedItem fixtures are reused; the unrelated 100K Milestone Cape fixture is not added.


## Separate cape catalogues in v1.3.12

The seven Bedrock Cosmos capes and thirteen Oxynix capes are removed from the combined By Creator grid and shown in their own separate grids, each with a matching heading and count.
