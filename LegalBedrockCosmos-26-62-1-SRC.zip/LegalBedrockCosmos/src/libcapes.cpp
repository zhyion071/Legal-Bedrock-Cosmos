#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <link.h>
#include <elf.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <thread>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <string>
#include <string_view>
#include <vector>
#include <map>
#include <mutex>
#include <utility>
#include <cstdarg>
#include <cstdio>
#include <cerrno>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <time.h>
#include <sys/stat.h>

#include "cosmos_bridge_dex.hpp"
#include "capes_v1.hpp"
#include "capes_v2.hpp"
#include "creator_pages.hpp"
#include "profile_persona_append.hpp"
#include "profile_skins_append.hpp"
#include "skinpack_viewer_60a2047b_fe99_4a1d_9ccf_79d6a9b63adb.hpp"
#include "skinpack_viewer_c65b1919_df90_4c9b_b3d5_a59c7d7a3979.hpp"
#include "skinpack_viewer_62c68fd4_3075_40ed_8b7b_15dcc7b667ff.hpp"
#include "skinpack_viewer_2f60a7a0_8010_49b1_8b57_851ac41f34cf.hpp"
#include "skinpack_viewer_80c85890_dad7_4d3a_b2ef_60071327b7cf.hpp"
#include "skinpack_viewer_4c61b1f5_2bbc_492f_8a2a_1f3b813c4113.hpp"
#include "skinpack_viewer_1fc32dd0_b399_4255_a4c7_e6e262a40ab6.hpp"
#include "skinpack_viewer_358a8710_bcf4_4cd7_ae86_a63ffec500c8.hpp"
#include "skinpack_viewer_5b13cb52_e2bf_438c_97f2_1105c54929d9.hpp"
#include "all_main_pages.hpp"
#include "skinpack_pages.hpp"
#include "playfab_items.hpp"
#include "playfab_search.hpp"
#include "cape_playfab_items.hpp"

#define LOG_TAG "mchook"
// Keep diagnostics in logcat only; never create or write workspace/device files.
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {
std::atomic<bool> g_install_complete{false};
std::atomic<bool> g_install_mutated{false};

JavaVM* g_vm = nullptr;

// ---------------------------------------------------------------------------
// 1.26.60 / LeviLauncher v1.6.0 port (2026-10-31)
//
// What broke: LeviLauncher v1.6.0 (the first build with Minecraft 26.60 support)
// is the first release built with R8 minify/obfuscation. Its okhttp3 classes are
// renamed away (v1.5.27 ships 378 okhttp3 classes by name, v1.6.0 ships 15:
// okhttp3.Interceptor, OkHttpClient$Builder, Interceptor$Chain, Callback ... are
// gone). The old mod injected an okhttp3.Interceptor into
// HttpClientRequest.OK_CLIENT, so on v1.6.0 it could not find a usable loader and
// installed nothing: custom capes, layouts and creator pages disappeared.
//
// New transport: LeviLauncher keeps com.xbox.httpclient.** un-obfuscated
// (minecraft/consumer-rules.pro). libHttpClient calls back into native code
// through HttpClientRequest.OnRequestCompleted/OnRequestFailed and reads the body
// through HttpClientResponse$NativeOutputStream.nativeWrite. We re-bind those
// three JNI natives (chaining to libHttpClient's exported originals), read the
// request URL/body with libHttpClient's exported HC* API, and hand libHttpClient a
// CosmosResponse (a HttpClientResponse subclass from our embedded DEX) whenever
// a Cosmos route matches. No okhttp3 member is touched anywhere.
// ---------------------------------------------------------------------------
constexpr const char* kHttpRequestDotClass = "com.xbox.httpclient.HttpClientRequest";
constexpr const char* kHttpResponseDotClass = "com.xbox.httpclient.HttpClientResponse";
constexpr const char* kNativeOutputDotClass = "com.xbox.httpclient.HttpClientResponse$NativeOutputStream";
// v6: the request body is streamed to OkHttp through this class's nativeRead().
constexpr const char* kNativeInputDotClass = "com.xbox.httpclient.HttpClientRequestBody$NativeInputStream";
constexpr const char* kCosmosResponseDotClass = "com.mchook.CosmosResponse";
constexpr const char* kHttpClientLib = "libHttpClient.Android.so";

// Scope: Tab's port ships the entitlement-inventory forwarding DISABLED. The
// real Marketplace inventory response is always passed through untouched.
constexpr bool kForwardEntitlementInventory = false;

std::string jstring_value(JNIEnv* env, jobject obj);

struct LocalRef {
    JNIEnv* env{};
    jobject obj{};
    ~LocalRef() { if (env && obj) env->DeleteLocalRef(obj); }
    LocalRef(const LocalRef&) = delete;
    LocalRef& operator=(const LocalRef&) = delete;
};

bool clear_exception(JNIEnv* env, const char* where, bool describe = true) {
    if (!env || !env->ExceptionCheck()) return false;
    if (describe) {
        jthrowable t = env->ExceptionOccurred();
        env->ExceptionDescribe();
        env->ExceptionClear();
        std::string text;
        if (t) {
            // v5: the exception text also reaches the file log (ExceptionDescribe is logcat-only).
            jclass oc = env->FindClass("java/lang/Object");
            jmethodID ts = oc ? env->GetMethodID(oc, "toString", "()Ljava/lang/String;") : nullptr;
            jobject js = (ts && !env->ExceptionCheck()) ? env->CallObjectMethod(t, ts) : nullptr;
            if (env->ExceptionCheck()) { env->ExceptionClear(); js = nullptr; }
            if (js) {
                const char* c = env->GetStringUTFChars(static_cast<jstring>(js), nullptr);
                if (c) { text = c; env->ReleaseStringUTFChars(static_cast<jstring>(js), c); }
                env->DeleteLocalRef(js);
            }
            if (oc) env->DeleteLocalRef(oc);
            env->DeleteLocalRef(t);
        }
        LOGE("JNI exception at %s: %s", where, text.empty() ? "(no message)" : text.c_str());
    }
    env->ExceptionClear();
    return true;
}

jclass load_class(JNIEnv* env, jobject loader, const char* name) {
    if (!env || !loader) return nullptr;
    jclass loaderCls = env->FindClass("java/lang/ClassLoader");
    if (clear_exception(env, "FindClass(ClassLoader)")) return nullptr;
    jmethodID loadClass = env->GetMethodID(loaderCls, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
    if (clear_exception(env, "GetMethodID(ClassLoader.loadClass)")) return nullptr;
    jstring nameStr = env->NewStringUTF(name);
    jobject result = env->CallObjectMethod(loader, loadClass, nameStr);
    env->DeleteLocalRef(nameStr);
    if (clear_exception(env, "ClassLoader.loadClass")) return nullptr;
    return static_cast<jclass>(result);
}

bool loader_can_load(JNIEnv* env, jobject loader, const char* name) {
    if (!loader) return false;
    jobject cls = load_class(env, loader, name);
    if (!cls) return false;
    env->DeleteLocalRef(cls);
    return true;
}

jobject class_loader_of(JNIEnv* env, jclass clazz) {
    if (!clazz) return nullptr;
    jmethodID getClassLoader = env->GetMethodID(env->FindClass("java/lang/Class"), "getClassLoader", "()Ljava/lang/ClassLoader;");
    if (clear_exception(env, "Class.getClassLoader method")) return nullptr;
    jobject loader = env->CallObjectMethod(clazz, getClassLoader);
    if (clear_exception(env, "Class.getClassLoader")) return nullptr;
    return loader;
}

jobject application_class_loader(JNIEnv* env, jobject app) {
    if (!app) return nullptr;
    jclass appCls = env->GetObjectClass(app);
    jmethodID mid = env->GetMethodID(appCls, "getClassLoader", "()Ljava/lang/ClassLoader;");
    if (clear_exception(env, "Application.getClassLoader method")) return nullptr;
    jobject loader = env->CallObjectMethod(app, mid);
    if (clear_exception(env, "Application.getClassLoader")) return nullptr;
    env->DeleteLocalRef(appCls);
    return loader;
}

jobject context_class_loader(JNIEnv* env) {
    jclass threadCls = env->FindClass("java/lang/Thread");
    if (clear_exception(env, "FindClass(Thread)")) return nullptr;
    jmethodID currentThread = env->GetStaticMethodID(threadCls, "currentThread", "()Ljava/lang/Thread;");
    jmethodID getContext = env->GetMethodID(threadCls, "getContextClassLoader", "()Ljava/lang/ClassLoader;");
    if (clear_exception(env, "Thread methods")) return nullptr;
    jobject thread = env->CallStaticObjectMethod(threadCls, currentThread);
    if (clear_exception(env, "Thread.currentThread")) return nullptr;
    jobject loader = env->CallObjectMethod(thread, getContext);
    env->DeleteLocalRef(thread);
    if (clear_exception(env, "Thread.getContextClassLoader")) return nullptr;
    return loader;
}

jobject system_class_loader(JNIEnv* env) {
    jclass cls = env->FindClass("java/lang/ClassLoader");
    if (clear_exception(env, "FindClass(ClassLoader)")) return nullptr;
    jmethodID mid = env->GetStaticMethodID(cls, "getSystemClassLoader", "()Ljava/lang/ClassLoader;");
    if (clear_exception(env, "getSystemClassLoader method")) return nullptr;
    jobject loader = env->CallStaticObjectMethod(cls, mid);
    if (clear_exception(env, "getSystemClassLoader")) return nullptr;
    return loader;
}

jobject current_application(JNIEnv* env) {
    jclass at = env->FindClass("android/app/ActivityThread");
    if (clear_exception(env, "FindClass(ActivityThread)")) return nullptr;
    jmethodID currentApplication = env->GetStaticMethodID(at, "currentApplication", "()Landroid/app/Application;");
    if (clear_exception(env, "ActivityThread.currentApplication method")) return nullptr;
    jobject app = env->CallStaticObjectMethod(at, currentApplication);
    if (clear_exception(env, "ActivityThread.currentApplication")) return nullptr;
    if (!app) {
        LOGW("currentApplication returned null");
        return nullptr;
    }
    return app;
}

void add_candidate(JNIEnv* env, std::vector<jobject>& out, jobject loader) {
    if (!loader) return;
    for (jobject existing : out) {
        if (env->IsSameObject(existing, loader)) {
            env->DeleteLocalRef(loader);
            return;
        }
    }
    out.push_back(loader);
}


// ===========================================================================
// Class loader discovery (only needs LeviLauncher's com.xbox.httpclient classes)
// ===========================================================================
jobject find_http_loader(JNIEnv* env, jobject app) {
    std::vector<jobject> candidates;
    if (jobject loader = application_class_loader(env, app)) add_candidate(env, candidates, loader);
    if (jobject loader = context_class_loader(env)) add_candidate(env, candidates, loader);
    if (jobject loader = system_class_loader(env)) add_candidate(env, candidates, loader);

    jclass loaderCls = env->FindClass("java/lang/ClassLoader");
    if (clear_exception(env, "FindClass(ClassLoader)")) loaderCls = nullptr;
    jmethodID getParent = loaderCls ? env->GetMethodID(loaderCls, "getParent", "()Ljava/lang/ClassLoader;") : nullptr;
    if (clear_exception(env, "ClassLoader.getParent method")) getParent = nullptr;
    for (size_t i = 0; getParent && i < candidates.size() && i < 32; ++i) {
        jobject parent = env->CallObjectMethod(candidates[i], getParent);
        if (clear_exception(env, "ClassLoader.getParent")) continue;
        if (parent) add_candidate(env, candidates, parent);
    }

    jobject chosen = nullptr;
    for (jobject loader : candidates) {
        const bool req = loader_can_load(env, loader, kHttpRequestDotClass);
        const bool resp = req && loader_can_load(env, loader, kHttpResponseDotClass);
        LOGI("[bridge] loader candidate HttpClientRequest=%d HttpClientResponse=%d", req, resp);
        if (req && resp) { chosen = env->NewGlobalRef(loader); break; }
    }
    for (jobject c : candidates) env->DeleteLocalRef(c);
    if (!chosen) LOGW("[bridge] no class loader resolves com.xbox.httpclient yet");
    return chosen;
}

jclass load_embedded_dex(JNIEnv* env, jobject parentLoader, const std::uint8_t* dexBytes,
                         size_t dexSize, const char* className) {
    jclass byteBufferCls = env->FindClass("java/nio/ByteBuffer");
    if (clear_exception(env, "FindClass(ByteBuffer)")) return nullptr;
    jmethodID allocateDirect = env->GetStaticMethodID(byteBufferCls, "allocateDirect", "(I)Ljava/nio/ByteBuffer;");
    jmethodID put = env->GetMethodID(byteBufferCls, "put", "([B)Ljava/nio/ByteBuffer;");
    jmethodID rewind = env->GetMethodID(byteBufferCls, "rewind", "()Ljava/nio/Buffer;");
    if (clear_exception(env, "ByteBuffer methods")) return nullptr;
    jobject buffer = env->CallStaticObjectMethod(byteBufferCls, allocateDirect, static_cast<jint>(dexSize));
    if (clear_exception(env, "ByteBuffer.allocateDirect") || !buffer) return nullptr;
    jbyteArray bytes = env->NewByteArray(static_cast<jsize>(dexSize));
    if (clear_exception(env, "NewByteArray(dex)") || !bytes) return nullptr;
    env->SetByteArrayRegion(bytes, 0, static_cast<jsize>(dexSize), reinterpret_cast<const jbyte*>(dexBytes));
    env->CallObjectMethod(buffer, put, bytes);
    env->CallObjectMethod(buffer, rewind);
    if (clear_exception(env, "ByteBuffer fill")) return nullptr;

    jclass memLoaderCls = env->FindClass("dalvik/system/InMemoryDexClassLoader");
    if (clear_exception(env, "FindClass(InMemoryDexClassLoader)")) return nullptr;
    jmethodID ctor = env->GetMethodID(memLoaderCls, "<init>", "(Ljava/nio/ByteBuffer;Ljava/lang/ClassLoader;)V");
    if (clear_exception(env, "InMemoryDexClassLoader ctor")) return nullptr;
    jobject loader = env->NewObject(memLoaderCls, ctor, buffer, parentLoader);
    if (clear_exception(env, "InMemoryDexClassLoader construction") || !loader) return nullptr;
    jclass clazz = load_class(env, loader, className);
    if (!clazz) LOGE("[bridge] loadClass(%s) from embedded DEX failed", className);
    env->DeleteLocalRef(loader);
    env->DeleteLocalRef(bytes);
    env->DeleteLocalRef(buffer);
    return clazz;
}



std::string jstring_value(JNIEnv* env, jobject obj) {
    if (!obj) return {};
    const char* c = env->GetStringUTFChars(static_cast<jstring>(obj), nullptr);
    std::string out = c ? c : "";
    if (c) env->ReleaseStringUTFChars(static_cast<jstring>(obj), c);
    return out;
}

jobject json_obj(JNIEnv* env, const char* raw) {
    jclass cls = env->FindClass("org/json/JSONObject");
    if (clear_exception(env, "FindClass(JSONObject)")) return nullptr;
    jmethodID ctor = env->GetMethodID(cls, "<init>", "(Ljava/lang/String;)V");
    if (clear_exception(env, "JSONObject ctor")) return nullptr;
    jstring s = env->NewStringUTF(raw ? raw : "{}");
    jobject o = env->NewObject(cls, ctor, s);
    env->DeleteLocalRef(s);
    if (clear_exception(env, "JSONObject parse")) return nullptr;
    return o;
}

jobject json_array_get(JNIEnv* env, jobject arr, int index) {
    if (!arr) return nullptr;
    jclass cls = env->GetObjectClass(arr);
    jmethodID get = env->GetMethodID(cls, "get", "(I)Ljava/lang/Object;");
    if (clear_exception(env, "JSONArray.get")) return nullptr;
    jobject o = env->CallObjectMethod(arr, get, index);
    if (clear_exception(env, "JSONArray.get call")) return nullptr;
    return o;
}

int json_array_len(JNIEnv* env, jobject arr) {
    if (!arr) return 0;
    jclass cls = env->GetObjectClass(arr);
    jmethodID len = env->GetMethodID(cls, "length", "()I");
    if (clear_exception(env, "JSONArray.length")) return 0;
    return env->CallIntMethod(arr, len);
}

jobject json_opt_obj(JNIEnv* env, jobject obj, const char* key) {
    if (!obj) return nullptr;
    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "optJSONObject", "(Ljava/lang/String;)Lorg/json/JSONObject;");
    if (clear_exception(env, "JSONObject.optJSONObject")) return nullptr;
    jstring k = env->NewStringUTF(key);
    jobject out = env->CallObjectMethod(obj, mid, k);
    env->DeleteLocalRef(k);
    if (clear_exception(env, "JSONObject.optJSONObject call")) return nullptr;
    return out;
}

jobject json_opt_array(JNIEnv* env, jobject obj, const char* key) {
    if (!obj) return nullptr;
    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "optJSONArray", "(Ljava/lang/String;)Lorg/json/JSONArray;");
    if (clear_exception(env, "JSONObject.optJSONArray")) return nullptr;
    jstring k = env->NewStringUTF(key);
    jobject out = env->CallObjectMethod(obj, mid, k);
    env->DeleteLocalRef(k);
    if (clear_exception(env, "JSONObject.optJSONArray call")) return nullptr;
    return out;
}

std::string json_opt_string(JNIEnv* env, jobject obj, const char* key) {
    if (!obj) return {};
    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "optString", "(Ljava/lang/String;)Ljava/lang/String;");
    if (clear_exception(env, "JSONObject.optString")) return {};
    jstring k = env->NewStringUTF(key);
    jobject out = env->CallObjectMethod(obj, mid, k);
    env->DeleteLocalRef(k);
    if (clear_exception(env, "JSONObject.optString call") || !out) return {};
    std::string value = jstring_value(env, out);
    env->DeleteLocalRef(out);
    return value;
}

int json_opt_int(JNIEnv* env, jobject obj, const char* key, int fallback) {
    if (!obj) return fallback;
    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "optInt", "(Ljava/lang/String;I)I");
    if (clear_exception(env, "JSONObject.optInt")) return fallback;
    jstring k = env->NewStringUTF(key);
    jint out = env->CallIntMethod(obj, mid, k, fallback);
    env->DeleteLocalRef(k);
    if (clear_exception(env, "JSONObject.optInt call")) return fallback;
    return out;
}

bool json_put(JNIEnv* env, jobject obj, const char* key, jobject value) {
    if (!obj) return false;
    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "put", "(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;");
    if (clear_exception(env, "JSONObject.put")) return false;
    jstring k = env->NewStringUTF(key);
    env->CallObjectMethod(obj, mid, k, value);
    env->DeleteLocalRef(k);
    return !clear_exception(env, "JSONObject.put call");
}

bool json_put_int(JNIEnv* env, jobject obj, const char* key, int value) {
    if (!obj) return false;
    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "put", "(Ljava/lang/String;I)Lorg/json/JSONObject;");
    if (clear_exception(env, "JSONObject.put int")) return false;
    jstring k = env->NewStringUTF(key);
    env->CallObjectMethod(obj, mid, k, value);
    env->DeleteLocalRef(k);
    return !clear_exception(env, "JSONObject.put int call");
}

jobject json_new_array(JNIEnv* env) {
    jclass cls = env->FindClass("org/json/JSONArray");
    if (clear_exception(env, "FindClass(JSONArray)")) return nullptr;
    jmethodID ctor = env->GetMethodID(cls, "<init>", "()V");
    if (clear_exception(env, "JSONArray ctor")) return nullptr;
    return env->NewObject(cls, ctor);
}

bool json_array_put(JNIEnv* env, jobject arr, jobject value) {
    if (!arr) return false;
    jclass cls = env->GetObjectClass(arr);
    jmethodID mid = env->GetMethodID(cls, "put", "(Ljava/lang/Object;)Lorg/json/JSONArray;");
    if (clear_exception(env, "JSONArray.put")) return false;
    env->CallObjectMethod(arr, mid, value);
    return !clear_exception(env, "JSONArray.put call");
}

jobject json_to_string(JNIEnv* env, jobject obj) {
    if (!obj) return nullptr;
    jclass cls = env->GetObjectClass(obj);
    jmethodID mid = env->GetMethodID(cls, "toString", "()Ljava/lang/String;");
    if (clear_exception(env, "JSON.toString")) return nullptr;
    jobject s = env->CallObjectMethod(obj, mid);
    if (clear_exception(env, "JSON.toString call")) return nullptr;
    return s;
}

std::string transform_persona_profile(JNIEnv* env, const std::string& original) {
    jobject root = json_obj(env, original.c_str());
    if (!root) return original;
    std::string personaRaw(reinterpret_cast<const char*>(kProfilePersonaAppend), kProfilePersonaAppend_size);
    std::string skinsRaw(reinterpret_cast<const char*>(kProfileSkinsAppend), kProfileSkinsAppend_size);
    jobject persona = json_obj(env, personaRaw.c_str());
    jobject skins = json_obj(env, skinsRaw.c_str());
    if (!persona || !skins) return original;
    jobject personaItems = json_opt_array(env, persona, "items");
    jobject skinsItems = json_opt_array(env, skins, "items");
    jobject result = json_opt_obj(env, root, "result");
    jobject layout = json_opt_array(env, result, "layout");
    if (!personaItems || !skinsItems || !layout || json_array_len(env, layout) == 0) return original;
    jobject firstLayout = json_array_get(env, layout, 0);
    jobject rows = json_opt_array(env, firstLayout, "rows");
    if (!rows) return original;

    const int rowCount = json_array_len(env, rows);
    for (int i = 0; i < rowCount; ++i) {
        jobject row = json_array_get(env, rows, i);
        if (!row) continue;
        if (json_opt_string(env, row, "controlId") != "StoreRow") { env->DeleteLocalRef(row); continue; }
        jobject components = json_opt_array(env, row, "components");
        if (!components) { env->DeleteLocalRef(row); continue; }
        int dropdownId = -1;
        jobject itemList = nullptr;
        for (int j = 0; j < json_array_len(env, components); ++j) {
            jobject comp = json_array_get(env, components, j);
            if (!comp) continue;
            std::string type = json_opt_string(env, comp, "type");
            if (type == "dropdownOptionComp") dropdownId = json_opt_int(env, comp, "dropdownId", -1);
            else if (type == "itemListComp") itemList = comp;
            else env->DeleteLocalRef(comp);
        }
        if (!itemList) { env->DeleteLocalRef(components); env->DeleteLocalRef(row); continue; }
        jobject existing = json_opt_array(env, itemList, "items");
        jobject add = dropdownId == 0 ? personaItems : (dropdownId == 1 ? skinsItems : nullptr);
        if (!existing || !add) {
            env->DeleteLocalRef(itemList); env->DeleteLocalRef(components); env->DeleteLocalRef(row); continue;
        }
        jobject updated = json_new_array(env);
        for (int k = 0; k < json_array_len(env, add); ++k) { jobject v=json_array_get(env,add,k); if(v){json_array_put(env,updated,v);env->DeleteLocalRef(v);} }
        for (int k = 0; k < json_array_len(env, existing); ++k) { jobject v=json_array_get(env,existing,k); if(v){json_array_put(env,updated,v);env->DeleteLocalRef(v);} }
        int total = json_array_len(env, updated);
        json_put(env, itemList, "items", updated);
        json_put_int(env, itemList, "totalItems", total);
        jobject config = json_opt_obj(env, itemList, "customStoreRowConfiguration");
        if (config) { json_put_int(env, config, "maxOffers", total); env->DeleteLocalRef(config); }
        env->DeleteLocalRef(updated); env->DeleteLocalRef(existing); env->DeleteLocalRef(itemList); env->DeleteLocalRef(components); env->DeleteLocalRef(row);
    }
    jobject out = json_to_string(env, root);
    std::string resultStr = out ? jstring_value(env, out) : original;
    if (out) env->DeleteLocalRef(out);
    return resultStr.empty() ? original : resultStr;
}

std::string json_string_field(const std::string& body, const char* field) {
    std::string needle = "\"" + std::string(field) + "\"";
    size_t p = body.find(needle);
    if (p == std::string::npos) return {};
    p = body.find(':', p + needle.size());
    if (p == std::string::npos) return {};
    p = body.find('"', p + 1);
    if (p == std::string::npos) return {};
    size_t e = p + 1;
    while (e < body.size()) {
        if (body[e] == '"' && body[e - 1] != '\\') break;
        ++e;
    }
    if (e >= body.size()) return {};
    return body.substr(p + 1, e - p - 1);
}


// ===========================================================================
// libHttpClient symbols (exported by libHttpClient.Android.so)
// ===========================================================================
using HCGetUrlFn = std::int32_t (*)(void* call, const char** method, const char** url);
using HCGetBodyBytesFn = std::int32_t (*)(void* call, const std::uint8_t** body, std::uint32_t* size);
using HCBodyReadFn = std::int32_t (*)(void* call, size_t offset, size_t bytesAvailable, void* context,
                                      std::uint8_t* destination, size_t* bytesWritten);
using HCGetBodyReadFnFn = std::int32_t (*)(void* call, HCBodyReadFn* fn, size_t* bodySize, void** context);
using OnCompletedFn = void (*)(JNIEnv*, jobject, jlong, jobject);
using OnFailedFn = void (*)(JNIEnv*, jobject, jlong, jstring, jstring, jstring, jboolean);
using NativeWriteFn = void (*)(JNIEnv*, jobject, jlong, jbyteArray, jint, jint);
// libHttpClient's C++ side declares dstOffset/bytesAvailable as jlong (the Java side passes int).
using NativeReadFn = jint (*)(JNIEnv*, jobject, jlong, jlong, jbyteArray, jlong, jlong);

struct HcApi {
    HCGetUrlFn getUrl{};
    HCGetBodyBytesFn getBodyBytes{};
    HCGetBodyReadFnFn getBodyReadFn{};
    OnCompletedFn onCompleted{};
    OnFailedFn onFailed{};
    NativeWriteFn nativeWrite{};
    NativeReadFn nativeRead{};
} g_hc;

std::uint32_t gnu_hash(const char* s) {
    std::uint32_t h = 5381;
    for (const unsigned char* p = reinterpret_cast<const unsigned char*>(s); *p; ++p) h = (h << 5) + h + *p;
    return h;
}

std::uint32_t elf_hash(const char* s) {
    std::uint32_t h = 0, g;
    for (const unsigned char* p = reinterpret_cast<const unsigned char*>(s); *p; ++p) {
        h = (h << 4) + *p;
        if ((g = h & 0xf0000000u)) h ^= g >> 24;
        h &= ~g;
    }
    return h;
}

struct PhdrLookup { const char* lib; const char* sym; void* result; };

int phdr_lookup_cb(dl_phdr_info* info, size_t, void* data) {
    auto* q = static_cast<PhdrLookup*>(data);
    if (!info->dlpi_name || !std::strstr(info->dlpi_name, q->lib)) return 0;
    const ElfW(Addr) base = info->dlpi_addr;
    const ElfW(Dyn)* dyn = nullptr;
    for (int i = 0; i < info->dlpi_phnum; ++i) {
        if (info->dlpi_phdr[i].p_type == PT_DYNAMIC) {
            dyn = reinterpret_cast<const ElfW(Dyn)*>(base + info->dlpi_phdr[i].p_vaddr);
        }
    }
    if (!dyn) return 0;
    auto fix = [base](ElfW(Addr) p) { return p < base ? p + base : p; };
    const ElfW(Sym)* symtab = nullptr;
    const char* strtab = nullptr;
    const std::uint32_t* gnuHash = nullptr;
    const std::uint32_t* sysvHash = nullptr;
    for (const ElfW(Dyn)* d = dyn; d->d_tag != DT_NULL; ++d) {
        if (d->d_tag == DT_SYMTAB) symtab = reinterpret_cast<const ElfW(Sym)*>(fix(d->d_un.d_ptr));
        else if (d->d_tag == DT_STRTAB) strtab = reinterpret_cast<const char*>(fix(d->d_un.d_ptr));
        else if (d->d_tag == DT_GNU_HASH) gnuHash = reinterpret_cast<const std::uint32_t*>(fix(d->d_un.d_ptr));
        else if (d->d_tag == DT_HASH) sysvHash = reinterpret_cast<const std::uint32_t*>(fix(d->d_un.d_ptr));
    }
    if (!symtab || !strtab) return 0;
    if (gnuHash) {
        const std::uint32_t nbuckets = gnuHash[0], symoffset = gnuHash[1], bloomSize = gnuHash[2];
        const auto* bloom = reinterpret_cast<const ElfW(Addr)*>(gnuHash + 4);
        const auto* buckets = reinterpret_cast<const std::uint32_t*>(bloom + bloomSize);
        const std::uint32_t* chain = buckets + nbuckets;
        const std::uint32_t h = gnu_hash(q->sym);
        if (nbuckets) {
            std::uint32_t i = buckets[h % nbuckets];
            if (i >= symoffset) {
                for (;; ++i) {
                    const std::uint32_t ch = chain[i - symoffset];
                    if ((ch | 1u) == (h | 1u) && std::strcmp(strtab + symtab[i].st_name, q->sym) == 0 &&
                        symtab[i].st_shndx != SHN_UNDEF) {
                        q->result = reinterpret_cast<void*>(base + symtab[i].st_value);
                        return 1;
                    }
                    if (ch & 1u) break;
                }
            }
        }
    }
    if (sysvHash) {
        const std::uint32_t nbucket = sysvHash[0];
        const std::uint32_t* bucket = sysvHash + 2;
        const std::uint32_t* chain = bucket + nbucket;
        for (std::uint32_t i = bucket[elf_hash(q->sym) % nbucket]; i; i = chain[i]) {
            if (std::strcmp(strtab + symtab[i].st_name, q->sym) == 0 && symtab[i].st_shndx != SHN_UNDEF) {
                q->result = reinterpret_cast<void*>(base + symtab[i].st_value);
                return 1;
            }
        }
    }
    return 0;
}

void* find_hc_symbol(const char* sym) {
    if (void* h = dlopen(kHttpClientLib, RTLD_NOW | RTLD_NOLOAD)) {
        void* p = dlsym(h, sym);
        dlclose(h);
        if (p) return p;
    }
    if (void* p = dlsym(RTLD_DEFAULT, sym)) return p;
    PhdrLookup q{"libHttpClient", sym, nullptr};
    dl_iterate_phdr(phdr_lookup_cb, &q);
    return q.result;
}

bool resolve_hc() {
    if (g_hc.onCompleted && g_hc.onFailed && g_hc.nativeWrite && g_hc.getUrl) return true;
    g_hc.onCompleted = reinterpret_cast<OnCompletedFn>(find_hc_symbol("Java_com_xbox_httpclient_HttpClientRequest_OnRequestCompleted"));
    g_hc.onFailed = reinterpret_cast<OnFailedFn>(find_hc_symbol("Java_com_xbox_httpclient_HttpClientRequest_OnRequestFailed"));
    g_hc.nativeWrite = reinterpret_cast<NativeWriteFn>(find_hc_symbol("Java_com_xbox_httpclient_HttpClientResponse_00024NativeOutputStream_nativeWrite"));
    g_hc.getUrl = reinterpret_cast<HCGetUrlFn>(find_hc_symbol("HCHttpCallRequestGetUrl"));
    g_hc.nativeRead = reinterpret_cast<NativeReadFn>(find_hc_symbol("Java_com_xbox_httpclient_HttpClientRequestBody_00024NativeInputStream_nativeRead"));
    g_hc.getBodyBytes = reinterpret_cast<HCGetBodyBytesFn>(find_hc_symbol("HCHttpCallRequestGetRequestBodyBytes"));
    g_hc.getBodyReadFn = reinterpret_cast<HCGetBodyReadFnFn>(find_hc_symbol("HCHttpCallRequestGetRequestBodyReadFunction"));
    LOGI("[bridge] libHttpClient symbols: completed=%p failed=%p write=%p url=%p body=%p bodyfn=%p read=%p",
         reinterpret_cast<void*>(g_hc.onCompleted), reinterpret_cast<void*>(g_hc.onFailed),
         reinterpret_cast<void*>(g_hc.nativeWrite), reinterpret_cast<void*>(g_hc.getUrl),
         reinterpret_cast<void*>(g_hc.getBodyBytes), reinterpret_cast<void*>(g_hc.getBodyReadFn),
         reinterpret_cast<void*>(g_hc.nativeRead));
    return g_hc.onCompleted && g_hc.onFailed && g_hc.nativeWrite && g_hc.getUrl;
}

std::string call_url(jlong call) {
    if (!call || !g_hc.getUrl) return {};
    const char* method = nullptr;
    const char* url = nullptr;
    if (g_hc.getUrl(reinterpret_cast<void*>(call), &method, &url) < 0 || !url) return {};
    return url;
}

// v4: HTTP method of the call, for the request log ("?" when unknown).
std::string call_method(jlong call) {
    if (!call || !g_hc.getUrl) return "?";
    const char* method = nullptr;
    const char* url = nullptr;
    if (g_hc.getUrl(reinterpret_cast<void*>(call), &method, &url) < 0 || !method || !*method) return "?";
    return method;
}

// v4: one-line, length-capped copy of a request body for logcat.
std::string log_snippet(const std::string& s, size_t cap = 400) {
    std::string out;
    out.reserve(s.size() < cap ? s.size() : cap);
    for (size_t i = 0; i < s.size() && out.size() < cap; ++i) {
        const unsigned char ch = static_cast<unsigned char>(s[i]);
        out.push_back(ch == '\n' || ch == '\r' || ch == '\t' ? ' ' : (ch < 0x20 ? '.' : static_cast<char>(ch)));
    }
    if (s.size() > cap) out += "...(" + std::to_string(s.size()) + " bytes)";
    return out;
}

// v4: hosts whose every request is logged with its outcome (store / PlayFab / Cosmos).
bool is_store_host(const std::string& url) {
    return url.find("playfabapi.com") != std::string::npos ||
           url.find("minecraft-services.net") != std::string::npos ||
           url.find("bedrock-cosmos.app") != std::string::npos ||
           url.find("bedrockcosmos.app") != std::string::npos;
}

// v3 (2026-11-01): route matching must see the URL the way the 1.26.52.3 build did.
// That build matched against okhttp3 Request.url().toString(), and OkHttp
// canonicalises the scheme and host to lower case. libHttpClient hands us the raw
// string Minecraft built, and 1.26.60 builds its PlayFab base as
// "https://" + titleId + ".playfabapi.com/" with titleId "20CA2" (upper case), so
// "20ca2.playfabapi.com/Catalog/GetPublishedItem" / ".../Catalog/Search" never
// matched in v1/v2 and every Cosmos PlayFab payload (skin-pack contents, cape
// persona binaries) fell through to the real PlayFab "ItemNotFound" answer.
// Only scheme + host are lower-cased (exactly what OkHttp does); the path, query
// and the route tables are unchanged.
std::string canonical_url(const std::string& raw) {
    std::string out = raw;
    const size_t sep = out.find("://");
    if (sep == std::string::npos) return out;
    size_t end = out.find_first_of("/?#", sep + 3);
    if (end == std::string::npos) end = out.size();
    for (size_t i = 0; i < end; ++i) {
        const char c = out[i];
        if (c >= 'A' && c <= 'Z') out[i] = static_cast<char>(c - 'A' + 'a');
    }
    return out;
}

// ===========================================================================
// v6: request-body tee
// ---------------------------------------------------------------------------
// Root cause of "PlayFab body unreadable" in the v5 device log: Minecraft 1.26.60
// does not hand libHttpClient a byte buffer. It calls
// HCHttpCallRequestSetRequestBodyReadFunction with its own reader (libminecraftpe
// 1.26.60.4 @0x11c84e48, context = null). That reader looks the request up by
// HCHttpCallGetId and pulls the next chunk from Minecraft's own body *stream*; it
// ignores the offset argument, so it is forward-only. OkHttp drains that stream
// through HttpClientRequestBody$NativeInputStream.nativeRead() while sending, and
// by the time OnRequestCompleted reaches us the stream is at its end:
// GetRequestBodyBytes has no bytes (requestBodyBytes stays empty for a read
// function) and calling the reader again yields 0 bytes. So the body was never
// readable at completion time, whatever we did there.
// Fix: wrap nativeRead (RegisterNatives, same technique as nativeWrite) and keep a
// copy of every chunk Minecraft streams to OkHttp for PlayFab Catalog calls, keyed
// by the call handle. call_body() uses that copy first. The bytes OkHttp sends are
// untouched (we only read what the original nativeRead already wrote).
// ===========================================================================
constexpr size_t kTeeCap = 1u << 20;   // PlayFab Catalog bodies are a few hundred bytes
std::mutex g_teeMutex;
std::map<jlong, std::string> g_bodyTee;
std::atomic<bool> g_teeInstalled{false};
std::atomic<unsigned> g_teeChunks{0};

bool tee_wanted_url(const std::string& url) {
    return url.find("playfabapi.com/catalog/") != std::string::npos ||
           url.find("playfabapi.com/Catalog/") != std::string::npos;
}

void tee_store(jlong call, jlong srcOffset, const std::uint8_t* data, size_t n) {
    if (!call || !data || !n || srcOffset < 0) return;
    std::lock_guard<std::mutex> lock(g_teeMutex);
    auto it = g_bodyTee.find(call);
    if (srcOffset == 0) {
        // First chunk of a (re)sent body. Decide once per send whether this call is ours.
        if (it == g_bodyTee.end()) {
            if (!tee_wanted_url(canonical_url(call_url(call)))) return;
            it = g_bodyTee.emplace(call, std::string()).first;
        }
        it->second.clear();
    } else if (it == g_bodyTee.end()) {
        return;
    }
    const size_t off = static_cast<size_t>(srcOffset);
    if (off > kTeeCap || n > kTeeCap - off) return;
    std::string& buf = it->second;
    if (buf.size() < off + n) buf.resize(off + n, '\0');
    std::memcpy(&buf[off], data, n);
}

// Copies the chunk the original nativeRead just wrote into dst[dstOffset, +n).
void tee_after_read(JNIEnv* env, jlong call, jlong srcOffset, jbyteArray dst, jlong dstOffset, jint n) {
    if (n <= 0 || !dst || env->ExceptionCheck()) return;
    const jsize len = env->GetArrayLength(dst);
    if (dstOffset < 0 || dstOffset > len || n > len - dstOffset) return;
    std::string tmp(static_cast<size_t>(n), '\0');
    env->GetByteArrayRegion(dst, static_cast<jsize>(dstOffset), n, reinterpret_cast<jbyte*>(&tmp[0]));
    if (env->ExceptionCheck()) { env->ExceptionClear(); return; }
    tee_store(call, srcOffset, reinterpret_cast<const std::uint8_t*>(tmp.data()), tmp.size());
    g_teeChunks.fetch_add(1, std::memory_order_relaxed);
}

// Java: private native int nativeRead(long callHandle, long offset, byte[] b, int off, int len)
jint JNICALL hook_native_read_ii(JNIEnv* env, jobject thiz, jlong call, jlong srcOffset, jbyteArray dst,
                                 jint dstOffset, jint count) {
    const jint n = g_hc.nativeRead(env, thiz, call, srcOffset, dst, static_cast<jlong>(dstOffset), static_cast<jlong>(count));
    tee_after_read(env, call, srcOffset, dst, dstOffset, n);
    return n;
}
// Same, for a Java side that declares the last two as long (libHttpClient's own C++ prototype).
jint JNICALL hook_native_read_jj(JNIEnv* env, jobject thiz, jlong call, jlong srcOffset, jbyteArray dst,
                                 jlong dstOffset, jlong count) {
    const jint n = g_hc.nativeRead(env, thiz, call, srcOffset, dst, dstOffset, count);
    tee_after_read(env, call, srcOffset, dst, dstOffset, n);
    return n;
}

bool tee_take(jlong call, std::string& out) {
    std::lock_guard<std::mutex> lock(g_teeMutex);
    auto it = g_bodyTee.find(call);
    if (it == g_bodyTee.end()) return false;
    out.swap(it->second);
    g_bodyTee.erase(it);
    return !out.empty();
}

void tee_drop(jlong call) {
    std::lock_guard<std::mutex> lock(g_teeMutex);
    g_bodyTee.erase(call);
}

bool is_gzip(const std::string& b) {
    return b.size() >= 2 && static_cast<unsigned char>(b[0]) == 0x1f && static_cast<unsigned char>(b[1]) == 0x8b;
}

// Request body of a libHttpClient call (PlayFab bodies carry the ItemId / filter).
// Order (v6): the nativeRead tee, then libHttpClient's byte buffer, then the stored
// read function (the last two only work for calls that set bytes / a rewindable
// reader). A gzip body is inflated. If nothing yields a body we return false and
// the call is left alone, exactly like the old peek_request_body() fallback.
bool call_body(jlong call, std::string& out, const char** source = nullptr) {
    out.clear();
    const char* src = "none";
    if (!call) return false;
    void* c = reinterpret_cast<void*>(call);
    bool got = false;
    if (tee_take(call, out)) { got = true; src = "nativeRead tee"; }
    if (!got && g_hc.getBodyBytes) {
        const std::uint8_t* bytes = nullptr;
        std::uint32_t size = 0;
        if (g_hc.getBodyBytes(c, &bytes, &size) >= 0 && bytes && size > 0 && size < (8u << 20)) {
            out.assign(reinterpret_cast<const char*>(bytes), size);
            got = true; src = "body bytes";
        }
    }
    if (!got && g_hc.getBodyReadFn) {
        HCBodyReadFn fn = nullptr;
        size_t size = 0;
        void* ctx = nullptr;
        if (g_hc.getBodyReadFn(c, &fn, &size, &ctx) >= 0 && fn && size > 0 && size < (1u << 20)) {
            std::string buf(size, '\0');
            size_t total = 0;
            while (total < size) {
                size_t written = 0;
                if (fn(c, total, size - total, ctx, reinterpret_cast<std::uint8_t*>(&buf[total]), &written) < 0 ||
                    written == 0) break;
                total += written;
            }
            if (total == size) { out.swap(buf); got = true; src = "read function"; }
            else LOGW("[pf] read function gave %zu of %zu bytes (Minecraft's reader is a forward-only stream)", total, size);
        }
    }
    if (got && is_gzip(out)) {
        LOGI("[pf] gzip request body left untouched (decompression disabled)");
        got = false;
    }
    if (source) *source = src;
    if (!got) out.clear();
    return got;
}

// ===========================================================================
// Routes (same tables and matching as the 1.26.52.3 build)
// ===========================================================================
struct StaticRoute {
    const char* key;
    const std::uint8_t* bytes;
    std::size_t size;
};
std::vector<StaticRoute> g_routes;

void build_routes() {
    if (!g_routes.empty()) return;
    // Every static MainPages mapping the 1.26.52.3 build registered (unchanged list).
    const StaticRoute mainPages[] = {
        {"/api/v2.0/layout/pages/DressingRoom_Capes", kPage_Capes, kPage_Capes_size},
        {"/api/v2.0/layout/pages/MultiItemPage_BedrockCosmosMarketplaceCategoryPage", kPage_MainMarketplacePage, kPage_MainMarketplacePage_size},
        {"/api/v2.0/layout/pages/MultiItemPage_LegacyVault", kPage_LegacyVault, kPage_LegacyVault_size},
        {"/api/v2.0/layout/pages/MultiItemPage_MinecraftRestored", kPage_MinecraftRestored, kPage_MinecraftRestored_size},
        {"/api/v2.0/layout/pages/MultiItemPage_CreatorHub", kPage_Cosmos_Creator_Hub, kPage_Cosmos_Creator_Hub_size},
        {"/api/v2.0/layout/pages/PersonaCreatorPage_master_player_account!MinecraftCosmos", kPage_MinecraftCosmos_PersonaCreatorPage, kPage_MinecraftCosmos_PersonaCreatorPage_size},
        {"/api/v2.0/layout/pages/PersonaCreatorPage_master_player_account!SpinOffCapes", kPage_SpinOffCapes_PersonaCreatorPage, kPage_SpinOffCapes_PersonaCreatorPage_size},
        {"/api/v2.0/layout/pages/PersonaCreatorPage_master_player_account!BedrockCosmos", kPage_BedrockCosmos_PersonaCreatorPage, kPage_BedrockCosmos_PersonaCreatorPage_size},
        // Added in the 1.26.60 port from Bedrock-Cosmos/Responses (2026-10-20):
        {"/api/v2.0/layout/pages/PersonaCreatorPage_master_player_account!Oxynix", kPage_Oxynix_Persona, kPage_Oxynix_Persona_size},
        {"/api/v2.0/layout/pages/PersonaCreatorPage_master_player_account!BionicBen", kPage_BionicBen_Persona, kPage_BionicBen_Persona_size},
        {"/api/v2.0/layout/pages/PersonaCreatorPage_master_player_account!DL0ZE", kPage_DL0ZE_Persona, kPage_DL0ZE_Persona_size},
        {"/api/v2.0/layout/pages/PersonaCreatorPage_master_player_account!NAC", kPage_NAC_Persona, kPage_NAC_Persona_size},
        {"/api/v2.0/layout/pages/PersonaCreatorPage_master_player_account!Sability", kPage_Sability_Persona, kPage_Sability_Persona_size},
        {"/api/v2.0/layout/pages/PersonaCreatorPage_master_player_account!Stars", kPage_Stars_Persona, kPage_Stars_Persona_size},
        {"/api/v2.0/layout/pages/PersonaCreatorPage_master_player_account!Wizardry", kPage_Wizardry_Persona, kPage_Wizardry_Persona_size},
        {"/api/v2.0/layout/pages/MultiItemPage_Alleis_Elis_Marketplace", kPage_Alleis_Elis_Marketplace, kPage_Alleis_Elis_Marketplace_size},
        {"/api/v2.0/layout/pages/MultiItemPage_BionicBen_Marketplace", kPage_BionicBen_Marketplace, kPage_BionicBen_Marketplace_size},
        {"/api/v2.0/layout/pages/MultiItemPage_Exports_Marketplace", kPage_Exports_Marketplace, kPage_Exports_Marketplace_size},
        {"/api/v2.0/layout/pages/MultiItemPage_Mono_Marketplace", kPage_Mono_Marketplace, kPage_Mono_Marketplace_size},
        {"/api/v2.0/layout/pages/MultiItemPage_SRG64_Marketplace", kPage_SRG64_Marketplace, kPage_SRG64_Marketplace_size},
        {"/api/v2.0/layout/pages/MultiItemPage_YEH_Marketplace", kPage_YEH_Marketplace, kPage_YEH_Marketplace_size},
        {"/api/v2.0/layout/pages/MultiItemPage_ZeroMISTER_JA_Marketplace", kPage_ZeroMISTER_JA_Marketplace, kPage_ZeroMISTER_JA_Marketplace_size},
        {"/api/v2.0/layout/pages/PersonaCreatorPage_master_player_account!Essential", kPage_Essential_Persona, kPage_Essential_Persona_size},
        {"/api/v2.0/layout/pages/DressingRoom_CreeperCrunchCereal", kPage_CreeperCrunchCereal, kPage_CreeperCrunchCereal_size},
        {"/api/v2.0/layout/pages/DressingRoom_MinecraftDungeons", kPage_MinecraftDungeons, kPage_MinecraftDungeons_size},
        {"/api/v2.0/layout/pages/DressingRoom_MinecraftEarth", kPage_MinecraftEarth, kPage_MinecraftEarth_size},
        {"/api/v2.0/layout/pages/DressingRoom_RedeemableItems", kPage_RedeemableItems, kPage_RedeemableItems_size},
        {"/api/v2.0/layout/pages/DressingRoom_TinyTakeover", kPage_TinyTakeover, kPage_TinyTakeover_size},
        {"/api/v2.0/layout/pages/MultiItemPage_HiddenDLC", kPage_HiddenDLC, kPage_HiddenDLC_size},
        {"/api/v2.0/layout/pages/MultiItemPage_PersonaSkinSelector%7cSkinPack_60a2047b-fe99-4a1d-9ccf-79d6a9b63adb", kSkinPackViewer_60a2047b_fe99_4a1d_9ccf_79d6a9b63adb, kSkinPackViewer_60a2047b_fe99_4a1d_9ccf_79d6a9b63adb_size},
        {"/api/v2.0/layout/pages/MultiItemPage_PersonaSkinSelector%7cSkinPack_c65b1919-df90-4c9b-b3d5-a59c7d7a3979", kSkinPackViewer_c65b1919_df90_4c9b_b3d5_a59c7d7a3979, kSkinPackViewer_c65b1919_df90_4c9b_b3d5_a59c7d7a3979_size},
        {"/api/v2.0/layout/pages/MultiItemPage_PersonaSkinSelector%7cSkinPack_62c68fd4-3075-40ed-8b7b-15dcc7b667ff", kSkinPackViewer_62c68fd4_3075_40ed_8b7b_15dcc7b667ff, kSkinPackViewer_62c68fd4_3075_40ed_8b7b_15dcc7b667ff_size},
        {"/api/v2.0/layout/pages/MultiItemPage_PersonaSkinSelector%7cSkinPack_2f60a7a0-8010-49b1-8b57-851ac41f34cf", kSkinPackViewer_2f60a7a0_8010_49b1_8b57_851ac41f34cf, kSkinPackViewer_2f60a7a0_8010_49b1_8b57_851ac41f34cf_size},
        {"/api/v2.0/layout/pages/MultiItemPage_PersonaSkinSelector%7cSkinPack_80c85890-dad7-4d3a-b2ef-60071327b7cf", kSkinPackViewer_80c85890_dad7_4d3a_b2ef_60071327b7cf, kSkinPackViewer_80c85890_dad7_4d3a_b2ef_60071327b7cf_size},
        {"/api/v2.0/layout/pages/MultiItemPage_PersonaSkinSelector%7cSkinPack_4c61b1f5-2bbc-492f-8a2a-1f3b813c4113", kSkinPackViewer_4c61b1f5_2bbc_492f_8a2a_1f3b813c4113, kSkinPackViewer_4c61b1f5_2bbc_492f_8a2a_1f3b813c4113_size},
        {"/api/v2.0/layout/pages/MultiItemPage_PersonaSkinSelector%7cSkinPack_1fc32dd0-b399-4255-a4c7-e6e262a40ab6", kSkinPackViewer_1fc32dd0_b399_4255_a4c7_e6e262a40ab6, kSkinPackViewer_1fc32dd0_b399_4255_a4c7_e6e262a40ab6_size},
        {"/api/v2.0/layout/pages/MultiItemPage_PersonaSkinSelector%7cSkinPack_358a8710-bcf4-4cd7-ae86-a63ffec500c8", kSkinPackViewer_358a8710_bcf4_4cd7_ae86_a63ffec500c8, kSkinPackViewer_358a8710_bcf4_4cd7_ae86_a63ffec500c8_size},
        {"/api/v2.0/layout/pages/MultiItemPage_PersonaSkinSelector%7cSkinPack_5b13cb52-e2bf-438c-97f2-1105c54929d9", kSkinPackViewer_5b13cb52_e2bf_438c_97f2_1105c54929d9, kSkinPackViewer_5b13cb52_e2bf_438c_97f2_1105c54929d9_size},
    };
    for (const auto& r : mainPages) g_routes.push_back(r);
    for (std::size_t i = 0; i < cosmos::kSkinPackPagesCount; ++i) {
        const auto& page = cosmos::kSkinPackPages[i];
        g_routes.push_back({page.suffix, page.data, page.size});
    }
    LOGI("[bridge] %zu static routes ready", g_routes.size());
}

const StaticRoute* match_static(const std::string& url) {
    // Old Java interceptor: first spoof key contained in the URL (hash-map order).
    // Here: the longest contained key wins, which is the same answer whenever the
    // match is unambiguous and deterministic when it is not.
    const StaticRoute* best = nullptr;
    size_t bestLen = 0;
    for (const auto& r : g_routes) {
        const size_t n = std::strlen(r.key);
        if (n > bestLen && url.find(r.key) != std::string::npos) { best = &r; bestLen = n; }
    }
    return best;
}

bool is_playfab_item(const std::string& url) { return url.find("20ca2.playfabapi.com/Catalog/GetPublishedItem") != std::string::npos; }
bool is_playfab_search(const std::string& url) { return url.find("20ca2.playfabapi.com/Catalog/Search") != std::string::npos; }
bool is_persona_profile(const std::string& url) { return url.find("/api/v2.0/layout/pages/DressingRoom_PersonaProfile") != std::string::npos; }
bool is_entitlement_inventory(const std::string& url) {
    return url.find("entitlements.mktpl.minecraft-services.net/api/v1.0/player/inventory") != std::string::npos;
}

// Full replacement body for this call, if a Cosmos route owns it.
bool full_spoof_body(jlong call, const std::string& url, std::string& outBody, const char** label) {
    if (is_entitlement_inventory(url)) {
        // Out of scope for this port: always the real Marketplace inventory.
        if (!kForwardEntitlementInventory) LOGI("[bridge] entitlement inventory: real response (forwarding disabled)");
        return false;
    }
    if (is_playfab_item(url) || is_playfab_search(url)) {
        std::string body;
        const char* bodySource = "none";
        if (!call_body(call, body, &bodySource)) {
            LOGW("[bridge] PlayFab body unreadable; leaving %s untouched (tee %s, %u chunks teed so far)", url.c_str(),
                 g_teeInstalled.load() ? "on" : "OFF", g_teeChunks.load());
            return false;
        }
        // v4: every PlayFab Catalog request body and the decision taken on it.
        // v6: plus where the body came from (nativeRead tee / body bytes / read function).
        LOGI("[pf] body (%zu bytes, from %s) %s", body.size(), bodySource, log_snippet(body, 300).c_str());
        if (is_playfab_item(url)) {
            const std::string id = json_string_field(body, "ItemId");
            if (id.empty()) LOGW("[pf] GetPublishedItem: no \"ItemId\" in body -> real PlayFab answer");
            for (const auto& cape : persona::capes::kItemFixtures) {
                if (cape.id == id) {
                    LOGI("[pf] GetPublishedItem %s -> Cosmos cape payload", id.c_str());
                    outBody.assign(cape.payload); *label = "cape GetPublishedItem"; return true;
                }
            }
            auto it = cosmos::kPlayfabItems.find(id);
            if (it != cosmos::kPlayfabItems.end()) {
                LOGI("[pf] GetPublishedItem %s -> Cosmos payload (%zu bytes)", id.c_str(), it->second.size());
                outBody.assign(it->second); *label = "GetPublishedItem"; return true;
            }
            LOGI("[pf] GetPublishedItem %s -> not a Cosmos item, real PlayFab answer", id.c_str());
            return false;
        }
        size_t p = body.find("t eq '");
        if (p != std::string::npos) {
            // v4 log: every id in the filter (matching still uses the first, as in 1.26.52.3).
            std::string ids;
            for (size_t q = p; (q = body.find("t eq '", q)) != std::string::npos;) {
                q += 6;
                const size_t qe = body.find('\'', q);
                if (qe == std::string::npos) break;
                const std::string one = body.substr(q, qe - q);
                ids += one + (cosmos::kPlayfabSearch.count(one) ? "[cosmos] " : "[real] ");
                q = qe;
            }
            LOGI("[pf] Search filter ids: %s", ids.c_str());
            p += 6;
            size_t e = body.find('\'', p);
            if (e != std::string::npos) {
                auto it = cosmos::kPlayfabSearch.find(body.substr(p, e - p));
                if (it != cosmos::kPlayfabSearch.end()) {
                    LOGI("[pf] Search %s -> Cosmos payload", body.substr(p, e - p).c_str());
                    outBody.assign(it->second); *label = "PlayFab Search"; return true;
                }
                LOGI("[pf] Search %s -> not a Cosmos item, real PlayFab answer", body.substr(p, e - p).c_str());
            }
        } else {
            LOGI("[pf] Search without a \"t eq '...'\" filter -> real PlayFab answer");
        }
        return false;
    }
    if (const StaticRoute* r = match_static(url)) {
        outBody.assign(reinterpret_cast<const char*>(r->bytes), r->size);
        *label = r->key;
        return true;
    }
    return false;
}

// ===========================================================================
// JNI bridge state
// ===========================================================================
struct Bridge {
    jclass responseCls{};       // com.xbox.httpclient.HttpClientResponse
    jclass cosmosCls{};         // com.mchook.CosmosResponse
    jfieldID fidOkResponse{};   // HttpClientResponse.response (okhttp3.Response, name kept)
    jmethodID ctorResponse{};   // HttpClientResponse(long, okhttp3.Response)
    jmethodID midCode{};
    jmethodID midNumHeaders{};
    jmethodID midHeaderName{};
    jmethodID midHeaderValue{};
    jmethodID midBody{};
    jmethodID ctorCosmos{};
    jmethodID midUtf8{};        // static String utf8(byte[])
    jmethodID midBytes{};       // static byte[] bytes(String)
} g_bridge;

std::atomic<unsigned long> g_spoofed{0};

// Body capture: a HttpClientResponse built with a sentinel handle streams the real
// okhttp body into hook_native_write(), which stores it instead of forwarding.
struct Capture { std::string data; };
std::mutex g_captureMutex;
std::map<jlong, Capture*> g_captures;

void JNICALL hook_native_write(JNIEnv* env, jobject thiz, jlong handle, jbyteArray b, jint off, jint len) {
    Capture* cap = nullptr;
    {
        std::lock_guard<std::mutex> lock(g_captureMutex);
        auto it = g_captures.find(handle);
        if (it != g_captures.end()) cap = it->second;
    }
    if (!cap) {
        g_hc.nativeWrite(env, thiz, handle, b, off, len);
        return;
    }
    if (!b || len <= 0 || off < 0) return;
    const size_t old = cap->data.size();
    cap->data.resize(old + static_cast<size_t>(len));
    env->GetByteArrayRegion(b, off, len, reinterpret_cast<jbyte*>(&cap->data[old]));
}

void JNICALL cosmos_write_body(JNIEnv* env, jclass, jlong handle, jbyteArray body) {
    if (!body) return;
    g_hc.nativeWrite(env, nullptr, handle, body, 0, env->GetArrayLength(body));
}

jobject ok_response_of(JNIEnv* env, jobject httpResponse) {
    if (!httpResponse) return nullptr;
    jobject ok = env->GetObjectField(httpResponse, g_bridge.fidOkResponse);
    if (clear_exception(env, "HttpClientResponse.response")) return nullptr;
    return ok;
}

// Reads (and closes) the real network body of a HttpClientResponse.
bool read_real_body(JNIEnv* env, jobject httpResponse, std::string& out) {
    out.clear();
    jobject ok = ok_response_of(env, httpResponse);
    if (!ok) return false;
    Capture cap;
    const jlong key = static_cast<jlong>(reinterpret_cast<std::intptr_t>(&cap));
    {
        std::lock_guard<std::mutex> lock(g_captureMutex);
        g_captures[key] = &cap;
    }
    jobject tmp = env->NewObject(g_bridge.responseCls, g_bridge.ctorResponse, key, ok);
    bool ok2 = !clear_exception(env, "HttpClientResponse(capture)") && tmp;
    if (ok2) {
        env->CallVoidMethod(tmp, g_bridge.midBody);
        ok2 = !clear_exception(env, "HttpClientResponse.getResponseBodyBytes(capture)");
    }
    {
        std::lock_guard<std::mutex> lock(g_captureMutex);
        g_captures.erase(key);
    }
    if (tmp) env->DeleteLocalRef(tmp);
    env->DeleteLocalRef(ok);
    out.swap(cap.data);
    return ok2;
}

jobject make_cosmos_response(JNIEnv* env, jlong call, jobject okResponse, int code,
                             const std::vector<std::pair<std::string, std::string>>& headers,
                             const std::string& body) {
    jclass stringCls = env->FindClass("java/lang/String");
    if (clear_exception(env, "FindClass(String)")) return nullptr;
    const jsize n = static_cast<jsize>(headers.size());
    jobjectArray names = env->NewObjectArray(n, stringCls, nullptr);
    jobjectArray values = env->NewObjectArray(n, stringCls, nullptr);
    if (clear_exception(env, "header arrays") || !names || !values) return nullptr;
    for (jsize i = 0; i < n; ++i) {
        jstring k = env->NewStringUTF(headers[i].first.c_str());
        jstring v = env->NewStringUTF(headers[i].second.c_str());
        env->SetObjectArrayElement(names, i, k);
        env->SetObjectArrayElement(values, i, v);
        env->DeleteLocalRef(k);
        env->DeleteLocalRef(v);
    }
    jbyteArray bytes = env->NewByteArray(static_cast<jsize>(body.size()));
    if (clear_exception(env, "NewByteArray(body)") || !bytes) return nullptr;
    if (!body.empty()) env->SetByteArrayRegion(bytes, 0, static_cast<jsize>(body.size()), reinterpret_cast<const jbyte*>(body.data()));
    jobject resp = env->NewObject(g_bridge.cosmosCls, g_bridge.ctorCosmos, call, okResponse, static_cast<jint>(code), names, values, bytes);
    if (clear_exception(env, "new CosmosResponse")) resp = nullptr;
    env->DeleteLocalRef(names);
    env->DeleteLocalRef(values);
    env->DeleteLocalRef(bytes);
    env->DeleteLocalRef(stringCls);
    return resp;
}

const std::vector<std::pair<std::string, std::string>>& json_headers() {
    static const std::vector<std::pair<std::string, std::string>> h = {
        {"Content-Type", "application/json; charset=utf-8"}};
    return h;
}

std::string lower(std::string s) {
    for (char& c : s) c = static_cast<char>(c >= 'A' && c <= 'Z' ? c + 32 : c);
    return s;
}

// Persona profile: keep Minecraft's real response, append the Cosmos rows.
// The JSON round-trip goes through java.lang.String so 4-byte UTF-8 survives.
std::string append_persona_profile(JNIEnv* env, const std::string& rawUtf8) {
    jbyteArray in = env->NewByteArray(static_cast<jsize>(rawUtf8.size()));
    if (clear_exception(env, "NewByteArray(profile)") || !in) return rawUtf8;
    env->SetByteArrayRegion(in, 0, static_cast<jsize>(rawUtf8.size()), reinterpret_cast<const jbyte*>(rawUtf8.data()));
    jobject js = env->CallStaticObjectMethod(g_bridge.cosmosCls, g_bridge.midUtf8, in);
    env->DeleteLocalRef(in);
    if (clear_exception(env, "CosmosResponse.utf8") || !js) return rawUtf8;
    const std::string modified = jstring_value(env, js);   // modified UTF-8, round-trips through NewStringUTF
    env->DeleteLocalRef(js);
    const std::string updated = transform_persona_profile(env, modified);
    if (updated == modified) return rawUtf8;
    jstring outStr = env->NewStringUTF(updated.c_str());
    if (clear_exception(env, "NewStringUTF(profile)") || !outStr) return rawUtf8;
    jbyteArray out = static_cast<jbyteArray>(env->CallStaticObjectMethod(g_bridge.cosmosCls, g_bridge.midBytes, outStr));
    env->DeleteLocalRef(outStr);
    if (clear_exception(env, "CosmosResponse.bytes") || !out) return rawUtf8;
    std::string result(static_cast<size_t>(env->GetArrayLength(out)), '\0');
    if (!result.empty()) env->GetByteArrayRegion(out, 0, static_cast<jsize>(result.size()), reinterpret_cast<jbyte*>(&result[0]));
    env->DeleteLocalRef(out);
    LOGI("[bridge] DressingRoom_PersonaProfile: real response kept, Cosmos persona/skin rows appended");
    return result;
}

// v4: status code of a real response (-1 when unavailable), read without touching the body.
int real_status(JNIEnv* env, jobject response) {
    if (!response || !g_bridge.midCode) return -1;
    const int code = env->CallIntMethod(response, g_bridge.midCode);
    if (clear_exception(env, "HttpClientResponse.getResponseCode(log)")) return -1;
    return code;
}

// v4: Content-Type / Content-Length of a real response, for Cosmos CDN downloads.
std::string real_content_info(JNIEnv* env, jobject response) {
    std::string info;
    if (!response || !g_bridge.midNumHeaders) return info;
    const int n = env->CallIntMethod(response, g_bridge.midNumHeaders);
    if (clear_exception(env, "numHeaders(log)")) return info;
    for (int i = 0; i < n && i < 64; ++i) {
        jobject k = env->CallObjectMethod(response, g_bridge.midHeaderName, i);
        jobject v = env->CallObjectMethod(response, g_bridge.midHeaderValue, i);
        if (clear_exception(env, "header(log)")) { if (k) env->DeleteLocalRef(k); if (v) env->DeleteLocalRef(v); break; }
        const std::string ks = lower(jstring_value(env, k)), vs = jstring_value(env, v);
        if (k) env->DeleteLocalRef(k);
        if (v) env->DeleteLocalRef(v);
        if (ks == "content-type" || ks == "content-length" || ks == "location") info += " " + ks + "=" + vs;
    }
    return info;
}

// v4: one logcat line per request: method, URL, and what the bridge did with it.
void log_request(JNIEnv* env, jlong call, const std::string& raw, const std::string& url,
                 const char* outcome, jobject response) {
    const std::string method = call_method(call);
    const std::string shown = log_snippet(url, 600);
    if (outcome) {
        LOGI("[req] %s %s -> SPOOFED (%s)", method.c_str(), shown.c_str(), outcome);
    } else {
        const int code = real_status(env, response);
        const std::string extra = (url.find("bedrock-cosmos.app") != std::string::npos ||
                                   url.find("bedrockcosmos.app") != std::string::npos)
                                      ? real_content_info(env, response) : std::string();
        LOGI("[req] %s %s -> PASSED THROUGH (real status %d)%s", method.c_str(), shown.c_str(), code, extra.c_str());
    }
    if (raw != url && is_store_host(url)) LOGI("[req]   raw URL as built by Minecraft: %s", log_snippet(raw, 600).c_str());
}

void JNICALL hook_on_request_completed(JNIEnv* env, jobject thiz, jlong call, jobject response) {
    if (env->ExceptionCheck()) { g_hc.onCompleted(env, thiz, call, response); return; }
    const std::string rawUrl = call_url(call);
    const std::string url = canonical_url(rawUrl);
    if (!url.empty()) {
        std::string body;
        const char* label = "";
        const bool owned = full_spoof_body(call, url, body, &label);
        tee_drop(call);   // v6: the teed request body is only needed for that decision
        if (owned) {
            log_request(env, call, rawUrl, url, label, nullptr);
            std::string drained;
            if (response) read_real_body(env, response, drained);   // release the connection
            jobject ok = ok_response_of(env, response);
            jobject spoof = make_cosmos_response(env, call, ok, 200, json_headers(), body);
            if (ok) env->DeleteLocalRef(ok);
            if (spoof) {
                g_spoofed.fetch_add(1);
                LOGI("[bridge] spoof (%s) %s", label, url.c_str());
                g_hc.onCompleted(env, thiz, call, spoof);
                env->DeleteLocalRef(spoof);
                return;
            }
            LOGE("[bridge] could not build Cosmos response for %s; delivering real response", url.c_str());
            // Body already drained: hand libHttpClient an empty real-shaped response.
        } else if (response && is_persona_profile(url)) {
            log_request(env, call, rawUrl, url, "real response + Cosmos rows appended", nullptr);
            const int code = env->CallIntMethod(response, g_bridge.midCode);
            std::vector<std::pair<std::string, std::string>> headers;
            const int n = env->CallIntMethod(response, g_bridge.midNumHeaders);
            for (int i = 0; !env->ExceptionCheck() && i < n; ++i) {
                jobject k = env->CallObjectMethod(response, g_bridge.midHeaderName, i);
                jobject v = env->CallObjectMethod(response, g_bridge.midHeaderValue, i);
                std::string ks = jstring_value(env, k), vs = jstring_value(env, v);
                if (k) env->DeleteLocalRef(k);
                if (v) env->DeleteLocalRef(v);
                const std::string kl = lower(ks);
                if (kl == "content-length" || kl == "content-encoding" || kl == "transfer-encoding") continue;
                headers.emplace_back(ks, vs);
            }
            if (!clear_exception(env, "PersonaProfile headers")) {
                std::string original;
                read_real_body(env, response, original);
                const std::string updated = (code >= 200 && code < 300 && !original.empty())
                                                ? append_persona_profile(env, original) : original;
                jobject ok = ok_response_of(env, response);
                jobject spoof = make_cosmos_response(env, call, ok, code, headers, updated);
                if (ok) env->DeleteLocalRef(ok);
                if (spoof) {
                    g_hc.onCompleted(env, thiz, call, spoof);
                    env->DeleteLocalRef(spoof);
                    return;
                }
            }
        }
    }
    if (!url.empty() && !(response && is_persona_profile(url))) log_request(env, call, rawUrl, url, nullptr, response);
    clear_exception(env, "bridge before original OnRequestCompleted");
    g_hc.onCompleted(env, thiz, call, response);
}

void JNICALL hook_on_request_failed(JNIEnv* env, jobject thiz, jlong call, jstring type, jstring stack,
                                    jstring netInfo, jboolean unknownHost) {
    if (!env->ExceptionCheck()) {
        const std::string rawUrl = call_url(call);
        const std::string url = canonical_url(rawUrl);
        if (!url.empty()) {
            // v4: network failures are logged with libHttpClient's own words.
            const std::string t = jstring_value(env, type), ni = jstring_value(env, netInfo);
            LOGW("[req] %s %s -> NETWORK FAILURE type=%s netInfo=%s unknownHost=%d", call_method(call).c_str(),
                 log_snippet(url, 600).c_str(), log_snippet(t, 200).c_str(), log_snippet(ni, 200).c_str(),
                 unknownHost ? 1 : 0);
            clear_exception(env, "failed-request log");
        }
        std::string body;
        const char* label = "";
        const bool owned = !url.empty() && full_spoof_body(call, url, body, &label);
        tee_drop(call);
        if (owned) {
            jobject spoof = make_cosmos_response(env, call, nullptr, 200, json_headers(), body);
            if (spoof) {
                g_spoofed.fetch_add(1);
                LOGI("[bridge] spoof after network failure (%s) %s", label, url.c_str());
                g_hc.onCompleted(env, thiz, call, spoof);
                env->DeleteLocalRef(spoof);
                return;
            }
        }
    }
    tee_drop(call);
    clear_exception(env, "bridge before original OnRequestFailed");
    g_hc.onFailed(env, thiz, call, type, stack, netInfo, unknownHost);
}

template <typename T>
T as_global(JNIEnv* env, T local) {
    if (!local) return nullptr;
    T g = static_cast<T>(env->NewGlobalRef(local));
    env->DeleteLocalRef(local);
    return g;
}

bool install(JNIEnv* env) {
    if (!resolve_hc()) {
        LOGW("[bridge] libHttpClient not loaded yet");
        return false;
    }
    jobject app = current_application(env);
    if (!app) return false;
    jobject loader = find_http_loader(env, app);
    env->DeleteLocalRef(app);
    if (!loader) return false;

    bool ok = false;
    jclass requestCls = load_class(env, loader, kHttpRequestDotClass);
    jclass responseCls = load_class(env, loader, kHttpResponseDotClass);
    jclass nativeOutCls = load_class(env, loader, kNativeOutputDotClass);
    jclass nativeInCls = load_class(env, loader, kNativeInputDotClass);   // v6
    clear_exception(env, "load NativeInputStream");
    jclass cosmosCls = load_embedded_dex(env, loader, kCosmosBridgeDex, kCosmosBridgeDex_size, kCosmosResponseDotClass);
    do {
        if (!requestCls || !responseCls || !nativeOutCls || !cosmosCls) {
            LOGE("[bridge] classes: request=%p response=%p nativeOut=%p cosmos=%p",
                 requestCls, responseCls, nativeOutCls, cosmosCls);
            break;
        }
        Bridge b{};
        b.fidOkResponse = env->GetFieldID(responseCls, "response", "Lokhttp3/Response;");
        b.ctorResponse = env->GetMethodID(responseCls, "<init>", "(JLokhttp3/Response;)V");
        b.midCode = env->GetMethodID(responseCls, "getResponseCode", "()I");
        b.midNumHeaders = env->GetMethodID(responseCls, "getNumHeaders", "()I");
        b.midHeaderName = env->GetMethodID(responseCls, "getHeaderNameAtIndex", "(I)Ljava/lang/String;");
        b.midHeaderValue = env->GetMethodID(responseCls, "getHeaderValueAtIndex", "(I)Ljava/lang/String;");
        b.midBody = env->GetMethodID(responseCls, "getResponseBodyBytes", "()V");
        b.ctorCosmos = env->GetMethodID(cosmosCls, "<init>", "(JLokhttp3/Response;I[Ljava/lang/String;[Ljava/lang/String;[B)V");
        b.midUtf8 = env->GetStaticMethodID(cosmosCls, "utf8", "([B)Ljava/lang/String;");
        b.midBytes = env->GetStaticMethodID(cosmosCls, "bytes", "(Ljava/lang/String;)[B");
        if (clear_exception(env, "bridge member lookup")) break;

        JNINativeMethod cosmosNatives[] = {
            {"writeBody", "(J[B)V", reinterpret_cast<void*>(cosmos_write_body)}};
        if (env->RegisterNatives(cosmosCls, cosmosNatives, 1) != JNI_OK || clear_exception(env, "RegisterNatives(CosmosResponse)")) break;

        b.responseCls = as_global(env, responseCls); responseCls = nullptr;
        b.cosmosCls = as_global(env, cosmosCls); cosmosCls = nullptr;
        g_bridge = b;
        build_routes();

        JNINativeMethod writeNatives[] = {
            {"nativeWrite", "(J[BII)V", reinterpret_cast<void*>(hook_native_write)}};
        if (env->RegisterNatives(nativeOutCls, writeNatives, 1) != JNI_OK || clear_exception(env, "RegisterNatives(nativeWrite)")) break;

        // v6: request-body tee. Optional: without it the bridge works as in v5
        // (PlayFab bodies unreadable -> real PlayFab answers), so a failure here is logged, not fatal.
        if (!g_teeInstalled.load() && nativeInCls && g_hc.nativeRead) {
            JNINativeMethod readII[] = {
                {"nativeRead", "(JJ[BII)I", reinterpret_cast<void*>(hook_native_read_ii)}};
            if (env->RegisterNatives(nativeInCls, readII, 1) == JNI_OK && !clear_exception(env, "RegisterNatives(nativeRead JJ[BII)")) {
                g_teeInstalled.store(true);
                LOGI("[bridge] request-body tee on: HttpClientRequestBody$NativeInputStream.nativeRead (JJ[BII)I wrapped");
            } else {
                clear_exception(env, "RegisterNatives(nativeRead JJ[BII)");
                JNINativeMethod readJJ[] = {
                    {"nativeRead", "(JJ[BJJ)I", reinterpret_cast<void*>(hook_native_read_jj)}};
                if (env->RegisterNatives(nativeInCls, readJJ, 1) == JNI_OK && !clear_exception(env, "RegisterNatives(nativeRead JJ[BJJ)")) {
                    g_teeInstalled.store(true);
                    LOGI("[bridge] request-body tee on: HttpClientRequestBody$NativeInputStream.nativeRead (JJ[BJJ)I wrapped");
                } else {
                    clear_exception(env, "RegisterNatives(nativeRead JJ[BJJ)");
                    LOGW("[bridge] request-body tee NOT installed (nativeRead signature not found); PlayFab bodies stay unreadable");
                }
            }
        } else if (!g_teeInstalled.load()) {
            LOGW("[bridge] request-body tee NOT installed: NativeInputStream class=%p nativeRead=%p",
                 static_cast<void*>(nativeInCls), reinterpret_cast<void*>(g_hc.nativeRead));
        }

        g_install_mutated.store(true, std::memory_order_release);
        JNINativeMethod completed[] = {
            {"OnRequestCompleted", "(JLcom/xbox/httpclient/HttpClientResponse;)V", reinterpret_cast<void*>(hook_on_request_completed)}};
        if (env->RegisterNatives(requestCls, completed, 1) != JNI_OK || clear_exception(env, "RegisterNatives(OnRequestCompleted)")) break;
        JNINativeMethod failed[] = {
            {"OnRequestFailed", "(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V", reinterpret_cast<void*>(hook_on_request_failed)}};
        if (env->RegisterNatives(requestCls, failed, 1) != JNI_OK || clear_exception(env, "RegisterNatives(OnRequestFailed)")) {
            LOGW("[bridge] OnRequestFailed not bound; spoofing still works on successful requests");
        }
        LOGI("[bridge] installed: Cosmos routes active through com.xbox.httpclient (no okhttp3 dependency)");
        LOGI("[bridge] build v6 (2026-11-01): request log on ([req] every call, [pf] PlayFab decisions), file log on ([log]), request-body tee %s",
             g_teeInstalled.load() ? "on" : "OFF");
        ok = true;
    } while (false);

    if (requestCls) env->DeleteLocalRef(requestCls);
    if (responseCls) env->DeleteLocalRef(responseCls);
    if (nativeOutCls) env->DeleteLocalRef(nativeOutCls);
    if (nativeInCls) env->DeleteLocalRef(nativeInCls);
    if (cosmosCls) env->DeleteLocalRef(cosmosCls);
    env->DeleteGlobalRef(loader);
    return ok;
}

} // namespace

__attribute__((constructor))
static void native_constructor() {
    LOGI("[mchook] ELF constructor");
}

extern "C" jint JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    LOGI("[mchook] JNI_OnLoad START (Cosmos 1.26.60 bridge, build v6)");
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK || !env) {
        LOGE("[mchook] GetEnv failed");
        return JNI_VERSION_1_6;
    }
    std::thread([] {
        for (int attempt = 0; attempt < 600; ++attempt) {
            if (g_install_complete.load(std::memory_order_acquire)) return;
            JNIEnv* e = nullptr;
            bool attached = false;
            if (g_vm->GetEnv(reinterpret_cast<void**>(&e), JNI_VERSION_1_6) != JNI_OK) {
                if (g_vm->AttachCurrentThread(&e, nullptr) != JNI_OK) {
                    std::this_thread::sleep_for(std::chrono::milliseconds(500));
                    continue;
                }
                attached = true;
            }
            const bool done = e && install(e);
            if (attached) g_vm->DetachCurrentThread();
            if (done) {
                g_install_complete.store(true, std::memory_order_release);
                LOGI("[mchook] install succeeded on attempt %d", attempt + 1);
                return;
            }
            if (g_install_mutated.load(std::memory_order_acquire)) {
                LOGE("[mchook] install bound nativeWrite but not OnRequestCompleted; not retrying");
                return;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
        LOGE("[mchook] install gave up after 5 minutes");
    }).detach();
    return JNI_VERSION_1_6;
}
